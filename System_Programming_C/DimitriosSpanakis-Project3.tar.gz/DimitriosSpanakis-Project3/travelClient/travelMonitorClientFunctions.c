#include "./travelMonitorClientHeader.h"

extern int numMonitors;
extern int numThreads;
extern int socketBufferSize;
extern int cyclicBufferSize;
extern int bloomFilterByteSize;
extern char hostname[128];
extern char* inputDir;

extern monitorInfo** monitorInfoArray;

extern int acceptedTravelRequests;
extern int rejectedTravelRequests;

int checkDirectoryExists(char* path) {

	DIR* dir = opendir(path);
	if (dir) {
    	closedir(dir);
		return 1;
	} else if (ENOENT == errno) {
    	return 0;
	}
	else return -1;
}

void initialiseTravelMonitorClient(int argc, char* argv[]) {

	gethostname(hostname, 128);

	if (argc != 13) {
		printf("\nERROR AT THE EXECUTION OF TRAVEL MONITOR CLIENT\n");
		printf("./travelMonitorClient –m numMonitors -b socketBufferSize -c cyclicBufferSize -s sizeOfBloom -i input_dir -t numThreads\n");
		exit(1);
	}

	int checkSet = 0;

	// Set numMonitors value
	for (int i = 0; i < argc ; i++) {
		if (strcmp(argv[i], "-m") == 0) {

			numMonitors = atoi(argv[i+1]);
			if (numMonitors <= 0) {
				printf("ERROR: NUM_MONITORS MUST BE GREATER THAN 0\n");
				exit(1);
			}
			checkSet = 1;

		}
	}
	if (!checkSet) {
		printf("ERROR: NO -m FLAG FOUND\n");
		exit(1);
	}
	else 
		checkSet = 0;

	// Set numThreads value
	for (int i = 0; i < argc ; i++) {
		if (strcmp(argv[i], "-t") == 0) {

			numThreads = atoi(argv[i+1]);
			if (numThreads <= 0) {
				printf("ERROR: NUM_THREADS MUST BE GREATER THAN 0\n");
				exit(1);
			}
			checkSet = 1;

		}
	}
	if (!checkSet) {
		printf("ERROR: NO -t FLAG FOUND\n");
		exit(1);
	}
	else 
		checkSet = 0;

	// Set socketBufferSize value
	for (int i = 0; i < argc ; i++) {
		if (strcmp(argv[i], "-b") == 0) {

			socketBufferSize = atoi(argv[i+1]);
			if (socketBufferSize <= 0) {
				printf("ERROR: SOCKET_BUFFER_SIZE MUST BE GREATER THAN 0 BYTES\n");
				exit(1);
			}
			checkSet = 1;
		}
	}
	if (!checkSet) {
		printf("ERROR: NO -b FLAG FOUND\n");
		exit(1);
	}
	else 
		checkSet = 0;

	// Set bloomFilterByteSize value
	for (int i = 0; i < argc ; i++) {
		if (strcmp(argv[i], "-s") == 0) {

			bloomFilterByteSize = atoi(argv[i+1]);
			if (bloomFilterByteSize < 1) {
				printf("ERROR: bloomFilterByteSize MUST BE GREATER THAN 0 BYTES\n");
				exit(1);
			}
			checkSet = 1;
		}
	}
	if (!checkSet) {
		printf("ERROR: NO -s FLAG FOUND\n");
		exit(1);
	}
	else 
		checkSet = 0;

	// Set cyclicBufferSize value
	for (int i = 0; i < argc ; i++) {
		if (strcmp(argv[i], "-c") == 0) {

			cyclicBufferSize = atoi(argv[i+1]);
			if (cyclicBufferSize < 1) {
				printf("ERROR: cyclicBufferSize MUST BE GREATER THAN 0 BYTES\n");
				exit(1);
			}
			checkSet = 1;
		}
	}
	if (!checkSet) {
		printf("ERROR: NO -c FLAG FOUND\n");
		exit(1);
	}
	else 
		checkSet = 0;

	// Set inputDir Value
	for (int i = 0; i < argc ; i++) {
		if (strcmp(argv[i], "-i") == 0) {

			int checkExists = checkDirectoryExists(argv[i+1]);
			if (!checkExists) {
				printf("ERROR: DIRECTORY |%s| DOES NOT EXIST\n", argv[i+1]);
				exit(1);
			}

			inputDir = malloc((strlen(argv[i+1]) +1) * sizeof(char));
			inputDir[0] = 0;
			strcat(inputDir, argv[i+1]);
			// printf("%s\n", inputDir);
			checkSet = 1;
			break;
		}
	}

	if (!checkSet) {
		printf("ERROR: NO -i FLAG FOUND\n");
		exit(1);
	}
	else 
		checkSet = 0;

}

void initialiseMonitorArray() {
	// Initialise MonitorInfoArray
	int port = 10000;
	monitorInfoArray = malloc(numMonitors*sizeof(monitorInfo*));
	for (int i = 0 ; i < numMonitors ; i++) {
		monitorInfoArray[i] = calloc(1, sizeof(monitorInfo));
		monitorInfoArray[i]->buffer = calloc(1,socketBufferSize*sizeof(char));
		monitorInfoArray[i]->port = port;
		port++;
	}

}


// Sent Monitor Request send msg to a specific monitor via indexing and buffering
void sentMonitorRequest(int monitorIdx, char* msg) {
	
	monitorInfoArray[monitorIdx]->bufferIdx = 0;

	char* tempBuffer = calloc(1, (strlen(msg)+ 3)*sizeof(char));
	strcpy(tempBuffer, msg);
	removeChar(tempBuffer, '\n');
	strcat(tempBuffer, " ~");

	// +1 to copy '\0' 
	int msgSize = strlen(tempBuffer);
	sendStringBuffer(monitorIdx, tempBuffer, msgSize);
	sendStringBufferRemainings(monitorIdx);

	free(tempBuffer);
}

// Recive monitor string receives an unknown sized message from specific monitor via indexing
char* receiveMonitorString(int monitorIdx) {

	monitorInfoArray[monitorIdx]->bufferIdx = 0;
	monitorInfoArray[monitorIdx]->buffer[0] = 0;
	char* messageString = calloc(1, socketBufferSize*sizeof(char));
	long int messageTotalSize = socketBufferSize;
	long int messageIdx = 0;

	struct pollfd fds[1];
	int timeout_msecs = 500;
	int ret;

	fds[0].fd = monitorInfoArray[monitorIdx]->sock;
	fds[0].events = POLLIN;
	while (1)
	{
		ret = poll(fds, 1, timeout_msecs);
	
		if((fds[0].revents&POLLIN) == POLLIN) {
			int bytesRead = read(monitorInfoArray[monitorIdx]->sock, monitorInfoArray[monitorIdx]->buffer, socketBufferSize*sizeof(char));
			// printf("Bytes Read %d\n", bytesRead);
			if (bytesRead == -1 || bytesRead == 0)
				continue;

           	if (messageIdx + bytesRead >= messageTotalSize) {

           		messageString = (char *) realloc(messageString, 2*messageTotalSize);
           		messageTotalSize*=2;

           	}

			memcpy(messageString + messageIdx, monitorInfoArray[monitorIdx]->buffer, bytesRead*sizeof(char));

			messageIdx+=bytesRead;

			int termCharFlag = 0;
			for (int i = 0; i < messageIdx ; i++) {
				if (messageString[i] == '~') {
					messageString[i] = 0;
					termCharFlag = 1;
					break;
				}
			}

			if (termCharFlag)
				break;

		}
	}

	return messageString;
}



void sendStringBuffer(int monitorIdx, char* charBuffer, int charBufferSize) {

	int fdWrite = monitorInfoArray[monitorIdx]->sock;
	char* buffer = monitorInfoArray[monitorIdx]->buffer;

	int charBufferIdx = 0;

	// foreach char in buffer
	while (charBufferIdx < charBufferSize) {

		// if char buffer > internal transmission buffer
		if (socketBufferSize - monitorInfoArray[monitorIdx]->bufferIdx > charBufferSize - charBufferIdx) {
			// copy to internal transmission buffer
			int charsToCopy = charBufferSize - charBufferIdx; 
			memcpy(buffer + monitorInfoArray[monitorIdx]->bufferIdx, charBuffer + charBufferIdx, charsToCopy * sizeof(char));
			// charBufferIdx += charsToCopy; -- not needed due to return (function complered and exits)
			monitorInfoArray[monitorIdx]->bufferIdx += charsToCopy;
			return;

		}
		else {
			// copy to internal transmission buffer
			int charsToCopy = socketBufferSize - monitorInfoArray[monitorIdx]->bufferIdx; 
			memcpy(buffer + monitorInfoArray[monitorIdx]->bufferIdx, charBuffer + charBufferIdx, charsToCopy * sizeof(char));
			// send internal transmission buffer
			int bytesWritten = 0;
			while (bytesWritten < socketBufferSize) {
				int n = write(fdWrite, buffer + bytesWritten, (socketBufferSize-bytesWritten) * sizeof(char));
				if (n != -1)
					bytesWritten += n;
				
				// printf("Written %d\n", bytesWritten);
				// sleep(1);
			}
			// printf("Bytes written %d\n", bytesWritten);
			charBufferIdx += charsToCopy;
			if (bytesWritten != socketBufferSize) {
				printf("WRITTEN LESS THAN EXPECTED!!\n");
			}
			// reset (reuse) internal transmission buffer
			monitorInfoArray[monitorIdx]->bufferIdx = 0;
		}
	}
}

void sendStringBufferRemainings(int monitorIdx) {

	int fdWrite = monitorInfoArray[monitorIdx]->sock;
	char* buffer = monitorInfoArray[monitorIdx]->buffer;
	int bufferIdx = monitorInfoArray[monitorIdx]->bufferIdx;

	if (monitorInfoArray[monitorIdx]->bufferIdx) {
		int bytesWritten = 0;
		while (bytesWritten < monitorInfoArray[monitorIdx]->bufferIdx) {
			int n = write(fdWrite, buffer + bytesWritten, (monitorInfoArray[monitorIdx]->bufferIdx-bytesWritten) * sizeof(char));
			if (n != -1)
				bytesWritten+=n;
			// printf("Written %d\n", bytesWritten);

		}
		// printf("Bytes written %d\n", bytesWritten);
	}
}


void collectWorkLoadAndEcexMonitors() {

	char* execStr = "./monitorServer";

	char* pArg = "-p";
	char pStr[16];

	char* tArg = "-t";
	char tStr[16];
	sprintf(tStr, "%d", numThreads);

	char* bArg = "-b";
	char bStr[16];
	sprintf(bStr, "%d", socketBufferSize);

	char* cArg = "-c";
	char cStr[16];
	sprintf(cStr, "%d", cyclicBufferSize);

	char* sArg = "-s";
	char sStr[16];
	sprintf(sStr, "%d", bloomFilterByteSize);

	// printf("All same %s\n", allSameString);
	char** pathStrArray = calloc(numMonitors, sizeof(char*));
	int* pathStringSize = calloc(numMonitors, sizeof(int));
	int* pathStringIdx = calloc(numMonitors, sizeof(int));
	for (int monitorIdx = 0 ; monitorIdx < numMonitors ; monitorIdx++) {
		
		pathStringSize[monitorIdx] = 1024;
		pathStrArray[monitorIdx] = calloc(1024, sizeof(char));
	}

    //Open inputDir
	DIR *dp = NULL;
	struct dirent *dptr = NULL;
	if ((dp=opendir(inputDir))== NULL ) {
        perror("opendir");
        exit(1);
    }

    int roundRobinIndex = 0;
	while ((dptr = readdir(dp)) != NULL ) {

		if (strcmp(dptr->d_name, ".") == 0 || strcmp(dptr->d_name, "..") == 0)
			continue;

		char pathN[512];
		pathN[0] = 0;

		sprintf(pathN, "%s/%s ", inputDir, dptr->d_name);

		if (pathStringIdx[roundRobinIndex] + strlen(pathN) + 1 > pathStringSize[roundRobinIndex] ) {
			pathStringSize[roundRobinIndex] = 2 * pathStringSize[roundRobinIndex];
			pathStrArray[roundRobinIndex] = realloc(pathStrArray[roundRobinIndex], pathStringSize[roundRobinIndex]);
		}

		strcat(pathStrArray[roundRobinIndex], pathN);
		// memcpy(pathStrArray[roundRobinIndex] + pathStringIdx[roundRobinIndex] - 1, pathN, strlen(pathN) + 1);
		pathStringIdx[roundRobinIndex] = pathStringIdx[roundRobinIndex] + strlen(pathN);

		search_or_append_Country(monitorInfoArray[roundRobinIndex], dptr->d_name, 1);

		pathN[0] = 0;

		roundRobinIndex++;
		if (roundRobinIndex == numMonitors)
			roundRobinIndex = 0;

	}
	closedir(dp);

	char** argArray = malloc(13 * sizeof(char*));
	argArray[0] = execStr;
	argArray[1] = pArg;
	// argArray[2] gets filled based on port number of monitor.
	argArray[3] = tArg;
	argArray[4] = tStr;
	argArray[5] = bArg;
	argArray[6] = bStr;
	argArray[7] = cArg;
	argArray[8] = cStr;
	argArray[9] = sArg;
	argArray[10] = sStr;
	// argArray[11] gets filled with monitor workLoad paths
	argArray[12] = NULL;

	for (int monitorIdx = 0 ; monitorIdx < numMonitors ; monitorIdx++) {
		
		pStr[0] = 0;
		sprintf(pStr, "%d", monitorInfoArray[monitorIdx]->port);

		argArray[2] = pStr;
		argArray[11] = pathStrArray[monitorIdx];

		if (!pathStrArray[monitorIdx][0])
			pathStrArray[monitorIdx][0] = '~';

		monitorInfoArray[monitorIdx]->pid = fork();
		if (monitorInfoArray[monitorIdx]->pid == -1)
			perror("Fork");

		if (!monitorInfoArray[monitorIdx]->pid) {
			execv(argArray[0], argArray);
			perror("Error with exec:");
		}
		else {
			printf("FORKED MONITOR_SERVER_%d WITH PID %d\n",monitorIdx, monitorInfoArray[monitorIdx]->pid);
		}

	}

	for (int i = 0 ; i < numMonitors ; i++) {
		free(pathStrArray[i]);
	}

	free(pathStringSize);
	free(pathStringIdx);
	free(pathStrArray);
	free(argArray);
}

void connectToServers() {

	for (int monitorIdx = 0 ; monitorIdx < numMonitors; monitorIdx++) {

		struct sockaddr_in server;
		struct sockaddr* serverptr = (struct sockaddr*) &server;
		struct hostent* rem;

		if ((monitorInfoArray[monitorIdx]->sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
			perror("Socket");

		if ((rem = gethostbyname(hostname)) == NULL) {
			herror("GetHostByName");
			exit(1);
		}

		server.sin_family = AF_INET;
		memcpy(&server.sin_addr, rem->h_addr, rem->h_length);
		server.sin_port = htons(monitorInfoArray[monitorIdx]->port);

		int connectRes;
		do {

			connectRes = connect(monitorInfoArray[monitorIdx]->sock, serverptr, sizeof(server));

		} while(connectRes < 0);

		printf("CONNECTED TO MONITOR_SERVER_%d AT PORT %d\n", monitorIdx, monitorInfoArray[monitorIdx]->port);


	}


}


monitorInfo* search_or_append_Country(monitorInfo* curMonitor, char* country, int appendFlag) {
	countryStatNode* prevNode = NULL;
	countryStatNode* curNode = curMonitor->countryListHead;

	while (curNode != NULL) {

		if (strcmp(curNode->countryName, country) == 0) {
			// printf("%s already exists\n", virusName);
			return curMonitor;
		}

		prevNode = curNode;
		curNode = curNode->nextCountry;

	}

	if (appendFlag == 0) {
		return NULL;
	}

	countryStatNode* newCountry = calloc(1, sizeof(countryStatNode));

	newCountry->countryName = malloc(((int)strlen(country) + 1) * sizeof(char));
	strcpy(newCountry->countryName, country);
	
	newCountry->nextCountry = NULL;


	if (prevNode == NULL) {

		curMonitor->countryListHead = newCountry;
	
	} 

	else {

		prevNode->nextCountry = newCountry;

	}

	return curMonitor;
}

void readBloomFilters () {

	bloomFilterReadState** bloomReadStates = calloc(1, numMonitors*sizeof(bloomFilterReadState*));
	for (int i = 0; i < numMonitors ;i++) {
		bloomReadStates[i] = calloc(1, sizeof(bloomFilterReadState));
		bloomReadStates[i]->state = Virus;
	}

	fd_set fds;
	struct timeval tv;
	tv.tv_sec = 0;
    tv.tv_usec = 500;
    while (1) {

    	int completedCount = 0;
    	for (int monitorIdx = 0; monitorIdx < numMonitors ; monitorIdx++) {
    		if (bloomReadStates[monitorIdx]->state == Completed)
    			completedCount++;
    			
    	}

    	if (completedCount == numMonitors)
    		break;

    
    	for (int monitorIdx = 0; monitorIdx < numMonitors ; monitorIdx++) {
    		// printf("curMonitor idx is %d\n", monitorIdx);
    		FD_ZERO(&fds);
			FD_SET(monitorInfoArray[monitorIdx]->sock, &fds);
			int selectRes = select (monitorInfoArray[monitorIdx]->sock + 1, &fds, NULL, NULL, &tv);
			// printf("Select res returned %d\n", selectRes);
			if (selectRes) {

				if (FD_ISSET(monitorInfoArray[monitorIdx]->sock, &fds)) {

					int bytesRead = read(monitorInfoArray[monitorIdx]->sock, monitorInfoArray[monitorIdx]->buffer, socketBufferSize);

					// printf("Bytes read is %d\n", bytesRead);
					char* bufferPtr = monitorInfoArray[monitorIdx]->buffer;
					int bytesConsumed = 0;
					while (bytesConsumed < bytesRead) {

						char c = *bufferPtr;
						if (bloomReadStates[monitorIdx]->state == Virus) {

							// printf("State is Virus - char: %c ascii: %d\n", c, c);
							bloomReadStates[monitorIdx]->virusName[bloomReadStates[monitorIdx]->index] = c;							
							// if virus string terminated
							if (c == 0) {
								// printf("End of Virus String\n");
								// printf("Next State is Bloom\n");
								bloomReadStates[monitorIdx]->state = Bloom;
								bloomReadStates[monitorIdx]->index = 0;

								if (!monitorInfoArray[monitorIdx]->bloomFilterHead) {
									monitorInfoArray[monitorIdx]->bloomFilterHead = search_or_append_BloomFilter_specific(monitorInfoArray[monitorIdx]->bloomFilterHead, bloomReadStates[monitorIdx]->virusName, 1);
									bloomReadStates[monitorIdx]->curBloomFilter = monitorInfoArray[monitorIdx]->bloomFilterHead;
								}
								else {
									bloomReadStates[monitorIdx]->curBloomFilter = search_or_append_BloomFilter_specific(monitorInfoArray[monitorIdx]->bloomFilterHead, bloomReadStates[monitorIdx]->virusName, 1);
								}
							}
							else if (c == '~') {
								// printf("End of Bloom Filter -> Completed\n");
								bloomReadStates[monitorIdx]->state = Completed;
								bloomReadStates[monitorIdx]->index++;
							}
							else {
								bloomReadStates[monitorIdx]->index++;
							}
						}
						else if (bloomReadStates[monitorIdx]->state == Bloom) {
							bloomReadStates[monitorIdx]->curBloomFilter->bitArray[bloomReadStates[monitorIdx]->index] = c;
							
							if (bloomReadStates[monitorIdx]->index == bloomFilterByteSize - 1) {
								// printf("End of Bloom Bytes - bytes read: %d\n", bloomReadStates[monitorIdx]->index + 1);
								// printf("Reset State to Virus\n");
								bloomReadStates[monitorIdx]->state = Virus;
								bloomReadStates[monitorIdx]->index = 0;
							}
							else {
								bloomReadStates[monitorIdx]->index++;
							}
						}
						bytesConsumed++;
						bufferPtr++;
					}
				}
			}
    	}
    }
    for (int i = 0; i < numMonitors ;i++) {
		free(bloomReadStates[i]);
	}
	free(bloomReadStates);

}

void readBloomFilter(int monitorIdx) {
	
	bloomFilterReadState* bloomReadState = calloc(1, sizeof(bloomFilterReadState));

	fd_set fds;
	struct timeval tv;
	tv.tv_sec = 0;
    tv.tv_usec = 500;
    while (1) {

    	int completedCount = 0;
    	if (bloomReadState->state == Completed)
    		break;
    	
		// printf("curMonitor idx is %d\n", monitorIdx);
		FD_ZERO(&fds);
		FD_SET(monitorInfoArray[monitorIdx]->sock, &fds);
		int selectRes = select (monitorInfoArray[monitorIdx]->sock + 1, &fds, NULL, NULL, &tv);
		// printf("Select res returned %d\n", selectRes);
		if (selectRes) {

			if (FD_ISSET(monitorInfoArray[monitorIdx]->sock, &fds)) {

				int bytesRead = read(monitorInfoArray[monitorIdx]->sock, monitorInfoArray[monitorIdx]->buffer, socketBufferSize);

				// printf("Bytes read is %d\n", bytesRead);
				char* bufferPtr = monitorInfoArray[monitorIdx]->buffer;
				int bytesConsumed = 0;
				while (bytesConsumed < bytesRead) {

					char c = *bufferPtr;
					if (bloomReadState->state == Virus) {

						// printf("State is Virus - char: %c ascii: %d\n", c, c);
						bloomReadState->virusName[bloomReadState->index] = c;							
						// if virus string terminated
						if (c == 0) {
							// printf("End of Virus String\n");
							// printf("Next State is Bloom\n");
							bloomReadState->state = Bloom;
							bloomReadState->index = 0;

							if (!monitorInfoArray[monitorIdx]->bloomFilterHead) {
								monitorInfoArray[monitorIdx]->bloomFilterHead = search_or_append_BloomFilter_specific(monitorInfoArray[monitorIdx]->bloomFilterHead, bloomReadState->virusName, 1);
								bloomReadState->curBloomFilter = monitorInfoArray[monitorIdx]->bloomFilterHead;
							}
							else {
								bloomReadState->curBloomFilter = search_or_append_BloomFilter_specific(monitorInfoArray[monitorIdx]->bloomFilterHead, bloomReadState->virusName, 1);
							}
						}
						else if (c == '~') {
							// printf("End of Bloom Filter -> Completed\n");
							bloomReadState->state = Completed;
							bloomReadState->index++;
						}
						else {
							bloomReadState->index++;
						}
					}
					else if (bloomReadState->state == Bloom) {
						bloomReadState->curBloomFilter->bitArray[bloomReadState->index] = c;
						
						if (bloomReadState->index == bloomFilterByteSize - 1) {
							// printf("End of Bloom Bytes - bytes read: %d\n", bloomReadState->index + 1);
							// printf("Reset State to Virus\n");
							bloomReadState->state = Virus;
							bloomReadState->index = 0;
						}
						else {
							bloomReadState->index++;
						}
					}
					bytesConsumed++;
					bufferPtr++;
				}
			}
		}
    	
    }

    free(bloomReadState);

}

void travelRequest(char* citizenID, char* date1, char* countryFrom, char* countryTo,char* vaccineType, char* msg) {

	char buf[256];
	countryStatNode* curCountryNode;
	int found = 0;

	int accepted = 0;

	int monitorIdx = checkCountryExists(countryFrom);
	if (monitorIdx == -1) {
		printf("INVALID COUNTRY_FROM\n");
		return;
	}

	int countryToExists = checkCountryExists(countryTo);
	if (countryToExists == -1) {
		printf("INVALID COUNTRY_TO\n");
		return;
	}

	int travelRes = vaccineStatusBloom_specific(monitorInfoArray[monitorIdx]->bloomFilterHead, citizenID, vaccineType);

	if (travelRes == -1) {
		printf("VIRUS |%s| RECORD NOT FOUND FOR COUNTRY |%s|\n",vaccineType, countryFrom);
		return ;
	}

	if (travelRes) {
		char monitorRequest[256];
		monitorRequest[0] = 0;
		strcpy(monitorRequest, "trvlRq ");
		strcat(monitorRequest, citizenID);
		strcat(monitorRequest, " ");
		strcat(monitorRequest, date1);
		strcat(monitorRequest, " ");
		strcat(monitorRequest, vaccineType);

		sentMonitorRequest(monitorIdx, monitorRequest);
		char* res = receiveMonitorString(monitorIdx);

		printf("MONITOR_%d ANSWER: %s\n\n",monitorIdx, res);

		if (strcmp(res, "NO ") == 0) {
			printf("REQUEST REJECTED – YOU ARE NOT VACCINATED\n");
			append_TravelStats(countryTo, vaccineType, date1, accepted);
			rejectedTravelRequests += 1;
		}
		else {

			sscanf(res, "%*s %s", buf);

			if(compareDate(date1 , buf) == 1) {
				printf("TRAVEL DATE IS BEFORE VACCINATION DATE...MAYBE U LIVE IN THE PAST...\n");
				return;
			}

			myDate* travelDate = calloc(1,sizeof(myDate));
			getDate(travelDate, date1);

			myDate* vacDate = calloc(1,sizeof(myDate));
			
			getDate(vacDate, buf);

			if (vacDate->year < travelDate->year ) {

				if(12*(travelDate->year - vacDate->year) + travelDate->month - vacDate->month <= 6) {

					if (travelDate->day > vacDate->day) {
						printf("REQUEST REJECTED – YOU WILL NEED ANOTHER VACCINATION BEFORE TRAVEL DATE\n");
						append_TravelStats(countryTo, vaccineType, date1, accepted);
						rejectedTravelRequests += 1;
					}
					else {
						printf("REQUEST ACCEPTED – HAPPY TRAVELS\n");
						accepted = 1;
						append_TravelStats(countryTo, vaccineType, date1, accepted);
						acceptedTravelRequests += 1;
					}

				}
				else {
					printf("REQUEST REJECTED – YOU WILL NEED ANOTHER VACCINATION BEFORE TRAVEL DATE\n");
					append_TravelStats(countryTo, vaccineType, date1, accepted);
					rejectedTravelRequests += 1;

				}


			}
			else if ( abs(vacDate->month - travelDate->month ) <= 6) {
				if (vacDate->day <= travelDate->day) {
					printf("REQUEST ACCEPTED – HAPPY TRAVELS\n");
					accepted = 1;
					append_TravelStats(countryTo, vaccineType, date1, accepted);
					acceptedTravelRequests += 1;
				}
				else {
					printf("REQUEST REJECTED – YOU WILL NEED ANOTHER VACCINATION BEFORE TRAVEL DATE\n");
					append_TravelStats(countryTo, vaccineType, date1, accepted);
					rejectedTravelRequests += 1;
				}
					
				
			}
			else {

				printf("REQUEST REJECTED – YOU WILL NEED ANOTHER VACCINATION BEFORE TRAVEL DATE\n");
				append_TravelStats(countryTo, vaccineType, date1, accepted);
				rejectedTravelRequests += 1;
			}

			free(travelDate);
			free(vacDate);

		}

		free(res); 
		return;
	}
	else {
		printf("REQUEST REJECTED – YOU ARE NOT VACCINATED\n");
		append_TravelStats(countryTo, vaccineType, date1, accepted);
		rejectedTravelRequests += 1;
		return;
	}

}

void travelStats(char* countryTo, char* vaccineType, char* date1, char* date2) {


	if (!countryTo) {

		countryStatNode* curCountryNode;
		for (int i = 0 ; i < numMonitors ; i++) {
			countryStatNode* curCountryNode = monitorInfoArray[i]->countryListHead;
			while(curCountryNode) {
				travelStats(curCountryNode->countryName, vaccineType, date1, date2);	
				curCountryNode = curCountryNode->nextCountry;
			}
		}

	}
	else {
		int found = 0;
		countryStatNode* curCountryNode;
		int monitorIdx;
		for (monitorIdx = 0 ; monitorIdx < numMonitors; monitorIdx++) {

			curCountryNode = monitorInfoArray[monitorIdx]->countryListHead;

			while(curCountryNode != NULL) {
				if (strcmp(countryTo, curCountryNode->countryName) == 0) {
					found = 1;
					break;
				}
				curCountryNode = curCountryNode->nextCountry;
			}

			if (found)
				break;

		}

		if (!found) {
			printf("COUNTRY %s NOT FOUND\n\n", countryTo);
			return;
		}

		travelVirusNode* curVirusNode = curCountryNode->travelVirusHead;
		found = 0;
		while(curVirusNode) {
			if (strcmp(vaccineType, curVirusNode->virusName) == 0) {
				found = 1;
				break;
			}
			curVirusNode = curVirusNode->nextNode;
		}

		if (!found) {
			printf("NO TRAVEL REQUESTS FOR VIRUS %s AND COUNTRY_TO %s\n\n",vaccineType, countryTo);
			return;
		}

		travelRequestNode* curRequestNode = curVirusNode->requestHead;
		if(!curRequestNode)
			printf("THERE ARE NO AVAILABLE REQUESTS FOR VIRUS %s AND COUNTRY %s\n",vaccineType, countryTo);

		int accepted = 0;
		int rejected = 0;
		while (curRequestNode) {

			if (date1 == NULL && date2 == NULL) {
				if (curRequestNode->accepted)
					accepted+=1;
				else
					rejected+=1;
			}
			else {

				// printf("Date 1 : %s Date 2: %s \n", date1, curRequestNode->date);
				// printf("Date 1 : %s Date 2: %s \n", curRequestNode->date, date2);

				if (compareDate(date1,curRequestNode->date) >= 0 && compareDate(curRequestNode->date, date2) >= 0) {
					if (curRequestNode->accepted)
						accepted+=1;
					else
						rejected+=1;
				}

			}

			curRequestNode = curRequestNode->nextRequest;
		}
		printf("%s\n", countryTo);
		printf("==============\n");
		printf("TOTAL REQUESTS %d\n", accepted + rejected);
		printf("ACCEPTED %d\n", accepted);
		printf("REJECTED %d\n\n", rejected);
	}

}

void append_TravelRequest(travelVirusNode* curTravelVirus, char* date, int accepted) {

	if (!curTravelVirus->requestHead) {

		curTravelVirus->requestHead = calloc(1,sizeof(travelRequestNode));
		curTravelVirus->requestHead->date = malloc((strlen(date)+1)*sizeof(char));
		strcpy(curTravelVirus->requestHead->date, date);
		curTravelVirus->requestHead->accepted = accepted;

	}
	else {

		travelRequestNode* newRequestNode = calloc(1, sizeof(travelRequestNode));
		newRequestNode->date =  malloc((strlen(date)+1)*sizeof(char));
		strcpy(newRequestNode->date, date);
		newRequestNode->accepted = accepted;

		newRequestNode->nextRequest = curTravelVirus->requestHead;
		curTravelVirus->requestHead = newRequestNode;

	}

}

void append_TravelStats(char* countryTo, char* virusName, char* date, int accepted) {

	// printf("Travel Stats\n");
	// printf("===============\n");
	// printf("CountryTo %s\n", countryTo);
	// printf("VaccineType %s\n", virusName);
	// printf("Date %s\n", date);
	// printf("Accepted %d\n", accepted);


	countryStatNode* countryNode = NULL;
	int found = 0;
	int i;
	for (i = 0 ; i < numMonitors ; i++) {
		countryNode = monitorInfoArray[i]->countryListHead;
		while(countryNode) {
			if (strcmp(countryNode->countryName, countryTo) == 0) {
				found = 1;
				break;
			}
			countryNode = countryNode->nextCountry;
		}
		if (found)
			break;
	}
	if (!found) {
		printf("\n(COUNTRY_TO |%s| NOT INSERTED IN STRUCTS, SKIPPING APPEND TO TRAVEL STATS...)\n",countryTo);
		return;
	}


	if (!countryNode->travelVirusHead) {

		countryNode->travelVirusHead = calloc(1, sizeof(travelVirusNode));
		countryNode->travelVirusHead->virusName = malloc((strlen(virusName) +1)*sizeof(char));
		strcpy(countryNode->travelVirusHead->virusName, virusName);
		append_TravelRequest(countryNode->travelVirusHead, date, accepted);
	}
	else {

		travelVirusNode* curVirusNode =  countryNode->travelVirusHead;

		while(curVirusNode) {

			if (strcmp(curVirusNode->virusName, virusName) == 0)
				break;

			curVirusNode = curVirusNode->nextNode;
		}

		if (curVirusNode) {
			append_TravelRequest(curVirusNode, date, accepted);
		}
		else {

			travelVirusNode* newVirusNode = calloc(1, sizeof(travelVirusNode));
			newVirusNode->virusName =  malloc((strlen(virusName) +1)*sizeof(char));
			strcpy(newVirusNode->virusName, virusName);
			newVirusNode->nextNode = countryNode->travelVirusHead;
			countryNode->travelVirusHead = newVirusNode;
			append_TravelRequest(newVirusNode, date, accepted);

		}
	}

}

void pollVaccinationStatusResults() {

	for (int k = 0 ; k < numMonitors; k++)
	for ( int i = 0; i < socketBufferSize; i++) {
		monitorInfoArray[k]->buffer[i] = 0;
	}
	
	bloomFilterReadState** readState = malloc(numMonitors*sizeof(bloomFilterReadState*));
    for (int i = 0 ; i < numMonitors ; i++) {
    	readState[i] = calloc(1, sizeof(bloomFilterReadState));
    	readState[i]->state = Results;
    }

    char** monitorAnswers = malloc(numMonitors* sizeof(char*));
    int* monitorAnswersCurSize = malloc(numMonitors * sizeof(int));
	for(int i = 0; i < numMonitors ; i++) {
		monitorAnswers[i] = malloc(socketBufferSize*sizeof(char));
		monitorAnswers[i][0] = 0;
		monitorAnswersCurSize[i] = socketBufferSize;
	}

	fd_set fds;
	struct timeval tv;
	tv.tv_sec = 0;
    tv.tv_usec = 500;
    while (1) {

    	int completedCount = 0;
    	for (int monitorIdx = 0; monitorIdx < numMonitors ; monitorIdx++) {
    		if (readState[monitorIdx]->state == Completed)
    			completedCount++;
    			
    	}

    	if (completedCount == numMonitors)
    		break;

    
    	for (int monitorIdx = 0; monitorIdx < numMonitors ; monitorIdx++) {
    		// printf("curMonitor idx is %d\n", monitorIdx);
    		FD_ZERO(&fds);
			FD_SET(monitorInfoArray[monitorIdx]->sock, &fds);
			int selectRes = select (monitorInfoArray[monitorIdx]->sock + 1, &fds, NULL, NULL, &tv);
			// printf("Select res returned %d\n", selectRes);
			if (selectRes) {

				if (FD_ISSET(monitorInfoArray[monitorIdx]->sock, &fds)) {

					int bytesRead = read(monitorInfoArray[monitorIdx]->sock, monitorInfoArray[monitorIdx]->buffer, socketBufferSize);\
					// printf("BytesRead %d\n", bytesRead);
					if (bytesRead == 0 || bytesRead == -1)
						continue;

					if (readState[monitorIdx]->index + bytesRead > monitorAnswersCurSize[monitorIdx]) {

	           			monitorAnswers[monitorIdx] = realloc(monitorAnswers[monitorIdx], 2*monitorAnswersCurSize[monitorIdx]);
	           			monitorAnswersCurSize[monitorIdx]*=2;

	         	  	}

	         	  	char* bufferPtr = monitorInfoArray[monitorIdx]->buffer;

					int bytesConsumed = 0;
					while (bytesConsumed < bytesRead) {

						monitorAnswers[monitorIdx][readState[monitorIdx]->index] = (*bufferPtr);
						if (*bufferPtr == '~') {
							monitorAnswers[monitorIdx][readState[monitorIdx]->index] = 0;
							readState[monitorIdx]->state = Completed;
						}


						readState[monitorIdx]->index++;
						bytesConsumed++;
						bufferPtr++;
					}
				}
			}
		}
	}

	for (int i = 0 ; i < numMonitors ; i++) {
		printf("MONITOR's %d ANSWEAR\n", i);
		printf("=========================\n");
		if (monitorAnswers[i][0] == 0) {
			printf("NO DATA TO PRINT\n\n");
			free(readState[i]);
			free(monitorAnswers[i]);
			continue;
		}
		printf("%s\n", monitorAnswers[i]);
		free(readState[i]);
		free(monitorAnswers[i]);
	}
	free(monitorAnswersCurSize);
	free(monitorAnswers);
	free(readState);

}

void searchVaccinationStatus(char* functionCallbuf,char* citizenID) {

	char monitorRequest[256];
	monitorRequest[0] = 0;

	strcpy(monitorRequest, "sVacSt ");
	strcat(monitorRequest, citizenID);

	int monitorIdx = 0;
	for (monitorIdx = 0 ; monitorIdx < numMonitors ; monitorIdx++) {
		sentMonitorRequest(monitorIdx, monitorRequest);
	}
	pollVaccinationStatusResults();

}

void addVaccinationRecords(char* country) {

	monitorInfo* curMonitor = NULL;

	int monitorIdx;
	for (monitorIdx = 0 ; monitorIdx < numMonitors ; monitorIdx++) {
		curMonitor = search_or_append_Country(monitorInfoArray[monitorIdx], country, 0);

		if (curMonitor)
			break;
	}

	if (!curMonitor) {
		printf("GIVEN COUNTRY DOES NOT EXIST IN SAVED STRUCTS\n");
		return;
	}

	printf("\n==========ADD VACCINATION RECORDS==========\n\n");
	monitorInfoArray[monitorIdx]->bufferIdx = 0;

	char monitorRequest[256];
	monitorRequest[0] = 0;
	strcpy(monitorRequest, "addVcRe ");

	sentMonitorRequest(monitorIdx, monitorRequest);

	bloomFilter* bloomToFree = monitorInfoArray[monitorIdx]->bloomFilterHead;
	monitorInfoArray[monitorIdx]->bloomFilterHead = NULL;
	readBloomFilter(monitorIdx);
	// Case blooms remained unchanged
	if (!monitorInfoArray[monitorIdx]->bloomFilterHead) {
		monitorInfoArray[monitorIdx]->bloomFilterHead = bloomToFree;
		printf("NO CHANGES WERE FOUND, KEEPING EXISTING BLOOMS\n\n");
	}
	else {
		printf("\nMONITOR_%d's BLOOMFILTERS UPDATED\n\n", monitorIdx);
		freeBloomFilter_specific(bloomToFree);
	}

	printf("=====================END=====================\n");

}

// ================= Death handlers ==================== //
void fatherDeathHandler () {

	printf("\nEXITING THE APPLICATION...\n\n");

	char* monitorRequest = "ext ";

	if (monitorInfoArray)
	for (int i = 0 ; i < numMonitors ; i++) {
		sentMonitorRequest(i, monitorRequest);
	}

	printf("\nCREATING |father_log.%d| LOG FILE\n", getpid());
	logFatherStats();
	printf("DONE\n\n");

	printf("FREEING ALL ALLOCATED MEMORY...\n");
	if (monitorInfoArray)
	for (int i = 0; i < numMonitors ; i++) {
		freeBloomFilter_specific(monitorInfoArray[i]->bloomFilterHead);
		freeCountryStatNode_specific(monitorInfoArray[i]->countryListHead);

		close(monitorInfoArray[i]->sock);

		free(monitorInfoArray[i]->buffer);
		free(monitorInfoArray[i]);

	}

	if (inputDir)
	free(inputDir);

	if (monitorInfoArray)
	free(monitorInfoArray);

	printf("DONE\n\n");
	printf("See you soon!\n");

	exit(1);
}

void logFatherStats() {

	char pidStr[128];
	pidStr[0] = 0;

	int pid = getpid();

	sprintf(pidStr, "./logFiles/father_log.%d", pid);

	if (!checkDirectoryExists(pidStr))
		mkdir("./logFiles", 0666);

	FILE* fp = fopen(pidStr, "a");

	for (int i = 0; i < numMonitors ; i++) {

		countryStatNode* curCountryNode = monitorInfoArray[i]->countryListHead;

		while (curCountryNode) {
			fprintf(fp, "%s\n", curCountryNode->countryName);
			curCountryNode = curCountryNode->nextCountry;
		}


	}

	fprintf(fp, "TOTAL TRAVEL REQUESTS %d\n", acceptedTravelRequests + rejectedTravelRequests);
	fprintf(fp, "ACCEPTED %d\n", acceptedTravelRequests);
	fprintf(fp, "REJECTED %d\n", rejectedTravelRequests);

	fclose(fp);

}

int checkCountryExists(char* countryName) {

	for (int i = 0 ; i < numMonitors ; i++) {

		monitorInfo* res = search_or_append_Country(monitorInfoArray[i], countryName, 0);
		if (res)
			return i;

	}
	return -1;
}

void freeTravelRequestNode(travelRequestNode* requestNode) {

	if (!requestNode)
		return;

	travelRequestNode* prevNode = NULL;

	while (requestNode) {

		prevNode = requestNode;
		requestNode = requestNode->nextRequest;

		free (prevNode->date);
		free(prevNode);

	}

}

void freeTravelVirusNode(travelVirusNode* curTravelVirus) {

	if (!curTravelVirus)
		return;

	travelVirusNode* prevNode = NULL;

	while (curTravelVirus) {
		prevNode = curTravelVirus;
		curTravelVirus = curTravelVirus->nextNode;

		free (prevNode->virusName);
		freeTravelRequestNode(prevNode->requestHead);
		free(prevNode);

	}

}

void freeCountryStatNode_specific(countryStatNode* curCountry) {

	if (!curCountry)
		return;

	countryStatNode* prevCountry = NULL;

	while (curCountry) {

		prevCountry = curCountry;
		curCountry = curCountry->nextCountry;

		if (!prevCountry->countryName)
			printf("EROORRRR U GOT NULL COUNTRY NAME!!!\n");

		free(prevCountry->countryName);
		freeTravelVirusNode(prevCountry->travelVirusHead);
		free(prevCountry);

	}

}

int pollStdin() {
	char input[16] = "\n|Input|: ";

	write(0, input, 16*sizeof(char));

	char buffer[512];
	buffer[0] = 0;

	struct pollfd fds[1];
	int timeout_msecs = 1000;
	int ret;

	fds[0].fd = 1;
	fds[0].events = POLLIN;
	while (1)
	{
		ret = poll(fds, 1, timeout_msecs);

		if (ret == -1 || ret == 0) {
			continue;
		}


		if((fds[0].revents&POLLIN) == POLLIN) {
			return 1;
		}
	}
}

int userInputReader() {
	int numberOfParamsRead;
	char functionCallbuf[256];
	char command[64];

	char citizenID[32];
	char firstName[32];
	char lastName[32];
	char countryFrom[32];
	char countryTo[32];
	char age[32];
	char vaccineType[32];
	char vaccinated[32];

	char date1[32];
	date1[0] = 0;
	char date2[32];
	date2[0] = 0;
	

	fflush(stdin);
	// printf("\n|Input|: ");
	// fgets(functionCallbuf, sizeof(functionCallbuf), stdin);

	// PollStdinAndSignals polls for user input, and if it fails to read, then executes polled signals!
	if (pollStdin())
		fgets(functionCallbuf, 256, stdin);

	printf("\n");

	if (functionCallbuf[0] == '\n') {
		printf("NO COMMAND GIVEN\n");
		return 1;
	}

	sscanf(functionCallbuf, "%s", command);


	if (strcmp(command, "/exit") == 0) {
		fatherDeathHandler();
	}

	else if(strcmp(command,"/travelRequest") == 0)
	{
		numberOfParamsRead = sscanf(functionCallbuf,"%*s %s %s %s %s %s %s", citizenID, date1 , countryFrom, countryTo, vaccineType, command);
		if(numberOfParamsRead != 5)
		{
			printf("|ERROR|: COMMAND /travelRequest (SHOULD BE /travelRequest citizenID date countryFrom countryTo vaccineType\n");
			return 1;
		}

		if (!validateDate(date1, 1))
			return 1;
		
		travelRequest(citizenID, date1, countryFrom, countryTo, vaccineType, functionCallbuf);

		return 1;

	}

	else if(strcmp(command,"/travelStats") == 0)
	{
		numberOfParamsRead = sscanf(functionCallbuf,"%*s %s %s %s %s %s", vaccineType, date1 , date2, countryTo, command);
		if(numberOfParamsRead != 4 && numberOfParamsRead != 3 && numberOfParamsRead != 2 && numberOfParamsRead != 1)
		{
			printf("|ERROR|: COMMAND /travelStats (SHOULD BE /travelStats virusName date1 date2 [country]\n");
			return 1;
		}

		if (numberOfParamsRead == 1) {

			travelStats(NULL, vaccineType, NULL, NULL);

		}
		else if (numberOfParamsRead == 2) {
			// Date1 contains countryTo
			
			travelStats(date1, vaccineType, NULL, NULL);
		}
		else if (numberOfParamsRead == 3  || numberOfParamsRead == 4) {

			if (!validateDate(date1, 1))
				return 1;

			if (!validateDate(date2, 1))
				return 1;

			int res = compareDate(date1,date2);
			if (res <= 0) {

				printf("|ERROR|: DATE2 IS NOT GREATER THAN DATE1  \n");
				return 1;
			}


			if (numberOfParamsRead == 3)
				travelStats(NULL, vaccineType, date1, date2);
			else {

				travelStats(countryTo, vaccineType, date1, date2);
			}

			return 1;

		}


		return 1;

	}

	else if(strcmp(command,"/addVaccinationRecords") == 0)
	{
		numberOfParamsRead = sscanf(functionCallbuf,"%*s %s %s", countryTo, command);
		if(numberOfParamsRead != 1)
		{
			printf("|ERROR|: COMMAND /addVaccinationRecords (SHOULD BE /addVaccinationRecords country\n");
			return 1;
		}

		addVaccinationRecords(countryTo);

		return 1;

	}

	else if(strcmp(command,"/searchVaccinationStatus") == 0)
	{
		numberOfParamsRead = sscanf(functionCallbuf,"%*s %s %s", citizenID, command);
		if(numberOfParamsRead != 1)
		{
			printf("|ERROR|: COMMAND /searchVaccinationStatus (SHOULD BE /searchVaccinationStatus citizenID\n");
			return 1;
		}
	
		searchVaccinationStatus(functionCallbuf, citizenID);
		return 1;

	}
	else {
		printf("DIDN'T RECOGNISE ANY COMMAND\n");
		return 1;
	}

	return 1;
}


