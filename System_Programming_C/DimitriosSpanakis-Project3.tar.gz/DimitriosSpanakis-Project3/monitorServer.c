#include "./monitorProcessServer/monitorServerHeader.h"
#include <errno.h>
// extern vars for citizen record hashTable
extern citizenHashTableNode** citizenHashTable;

// extern vars from BloomFiltering
extern int bloomFilterByteSize;
extern bloomFilter* bloomFilterList;
extern int bloomFilterCount; 
 
//extern vars from SkipList
extern doubleSkipList* skipListHead;

// All important structs asked to be used like blooms and skip list, are located in:
//	skipList folder
//	bloomFilterring folder
//	
// Functions that you may take a look, are located at:
//  mainStructs.h and mainFunctions.c
// All important functions of monitor process, newly implemented are located in monitorProcess folder
extern char hostname[128];
extern int serverPort;
extern int sock;
extern int numThreads;
extern int socketBufferSize;
extern int socketBufferIdx;
extern char* socketBuffer;
extern int cyclicBufferSize;
extern char* inputDir;

extern int newsock;
extern cyclicBuffer* cyclicBuff;
extern int countriesToConsume;

extern int pid;

extern int rejectedTravelRequests;
extern int acceptedTravelRequests;

extern directoryReadNode* directoriesReadListHead;

extern pthread_mutex_t mtx;
extern pthread_cond_t cond_nonempty;
extern pthread_cond_t cond_nonfull;
extern pthread_cond_t cond_exit;
extern pthread_mutex_t broadcastMtx;

extern pthread_mutex_t bloomMtx;
extern pthread_mutex_t hashTableMtx;
extern pthread_mutex_t skipListMtx;

extern pthread_mutex_t workDirMtx;

extern int termFlag;


void createAndHostServer() {

	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1)
		perror("Socket create failed");

	if (setsockopt(sock, SOL_SOCKET, SO_REUSEPORT , &(int){1}, sizeof(int)) < 0)
    	perror("setsockopt(SO_REUSEADDR) failed");

	struct sockaddr_in server;
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = htonl(INADDR_ANY);
	server.sin_port = htons(serverPort);
	int bindAddr;
	do {
		bindAddr = bind(sock,(struct sockaddr *) &server, sizeof(server));
	} while(bindAddr == -1);

	if (listen(sock, 5) < 0)
		perror("listen");



}

int acceptConnection() {

	struct sockaddr_in client = {0};
	socklen_t clientlen = {0};

	int newsock = 0;
	if ((newsock = accept(sock,(struct sockaddr*) &client, &clientlen)) < 0) {
		perror("Accept");
	}
	return newsock;

}

void destroyMutexesAndConds() {
	pthread_mutex_destroy(&mtx);
	pthread_cond_destroy(&cond_nonempty);
	pthread_cond_destroy(&cond_nonfull);
	pthread_cond_destroy(&cond_exit);
	pthread_mutex_destroy(&broadcastMtx);

	pthread_mutex_destroy(&hashTableMtx);
	pthread_mutex_destroy(&skipListMtx);
	pthread_mutex_destroy(&bloomMtx);

	pthread_mutex_destroy(&workDirMtx);
}

void initialiseMutexesAndConds() {

	pthread_mutex_init(&mtx, 0);
	pthread_cond_init(&cond_nonempty, 0);
	pthread_cond_init(&cond_nonfull, 0);
	pthread_cond_init(&cond_exit, 0);
	pthread_mutex_init(&broadcastMtx, 0);

	pthread_mutex_init(&hashTableMtx, 0);
	pthread_mutex_init(&skipListMtx, 0);
	pthread_mutex_init(&bloomMtx, 0);

	pthread_mutex_init(&workDirMtx, 0);

}

void initialise_and_execute(int argc, char* argv[]) {

	// Used by skiplist (flipCoin etc.)
	srand(time(NULL));

	// Used for saving unique citizen info
	hashTableInit();

	// Initialise variables based on command line
	char** countryPathBufferArray = initialiseMonitorServer(argc, argv);

	initialiseMutexesAndConds();

	// CountryPathBuffer array is NULL when we have 0 Directory paths for this process
	if (countryPathBufferArray) {

		pthread_t* threadArray = malloc(numThreads * sizeof(pthread_t));
		for (int i = 0; i < numThreads ; i++) {

			pthread_create(&threadArray[i], 0, consumeDirPaths, 0);
		}

		fillUpCyclicBufferWithFilePaths(countryPathBufferArray);

		termFlag = 1;

		pthread_cond_broadcast(&cond_nonempty);

		for (int i = 0 ; i < numThreads ; i++) {

			if (pthread_join(threadArray[i], NULL)!=0)
				fprintf(stderr, "error in thread join\n");
		}

		free(threadArray);
		free(countryPathBufferArray);

	}

	destroyMutexesAndConds();
	// print_vaccineStatusBloom("6786", "H1N1");

	// Create server based on command line variables
	createAndHostServer();
	// Socket fd
	newsock = acceptConnection();

	sendBloomFilters();

	while(1) {
		parent_Command_Reader_Server();
	}

}


int main(int argc, char* argv[]) {
	
	pid = getpid();
	initialise_and_execute(argc, argv);
}


// YOU MAY FIND USEFUL

	//-> Prints bitmap 
	// insert_to_BloomFilter("776", "Covid-19");
	// for (int i = 0; i < bloomFilterByteSize * 8; i++) {

	// 	printf("%d", get_BloomFilter_Bit(search_or_append_BloomFilter("Covid-19", 0)->bitArray, i));

	// }
	// printf("\n");
	// print_vaccineStatusBloom("776", "Covid-19");

//PRINTS SKIP LIST (INCLUDING DUMMY NODES)
	//printSkipList("Rotavirus");
