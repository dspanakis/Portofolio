#include "./travelClient/travelMonitorClientHeader.h"
// For shockaddr_in
#include <netinet/in.h>
// Fort hton
#include <arpa/inet.h>

#include <sys/types.h>
#include <ctype.h>
#include <sys/socket.h>

char hostname[128];
int numMonitors = 0;
int numThreads = 0;
int socketBufferSize = 0;
int cyclicBufferSize = 0;
extern int bloomFilterByteSize;
char* inputDir = NULL;

monitorInfo** monitorInfoArray = NULL;

int acceptedTravelRequests = 0;
int rejectedTravelRequests = 0;

int main(int argc, char* argv[]) {

	printf("PARENT OF ALL PID |%d|\n", getpid());

	initialiseTravelMonitorClient(argc, argv);

	printf("\nGIVEN INPUT\n");
	printf("===============\n");
	printf("Hostname %s\n", hostname);
	printf("numMonitors |%d|\n", numMonitors);
	printf("numThreads |%d|\n", numThreads);
	printf("socketBufferSize |%d|\n", socketBufferSize);
	printf("cyclicBufferSize |%d|\n", cyclicBufferSize);
	printf("bloomFilterByteSize |%d|\n", bloomFilterByteSize);
	printf("InputDir |%s|\n\n", inputDir);

	// Initialise monitorInfo struct with named pipes names etc.
	initialiseMonitorArray();
	
	// Save country dirs
	printf("SPLITTING WORK LOAD AND FORKING MONITOR SERVERS\n");
	collectWorkLoadAndEcexMonitors();
	printf("DONE\n\n");

	// Connect to all Servers
	printf("CONNECTING TO ALL SERVERS\n");
	connectToServers();
	printf("DONE\n\n");

    printf("READING BLOOMFILTERS FORM ALL MONITOR SERVERS...\n");
    readBloomFilters();
    printf("DONE\n\n");

	// for (int i = 0 ; i < numMonitors ; i++)
	// 	print_vaccineStatusBloom_specific(monitorInfoArray[i]->bloomFilterHead,"6786", "H1N1");

 	printf("STARTING INPUT READER....\n");
	while(userInputReader()){}
		

}

// The below code wasn't used because we need our sig handlers to be small
// in size. However, i found a smart way to block incoming signals in a semaphore like way
// with the below 2 functions. I left it here just for you to take a brief look, nothing more.

// struct sigaction act;
// struct sigaction childAct;
// sigset_t block_all_sigs_mask;
// sigset_t block_int_quit;
// sigset_t emptyMask;
// Set up signal Handlers
// sigemptyset(&block_all_sigs_mask);
// sigaddset(&block_all_sigs_mask, SIGINT);
// sigaddset(&block_all_sigs_mask, SIGQUIT);
// sigaddset(&block_all_sigs_mask, SIGCHLD);

// sigfillset (&(act.sa_mask));
// act.sa_flags = SA_RESTART;
// act.sa_handler = sigFatherDeathHandler;
// sigaction ( SIGINT , &act , NULL );
// sigaction ( SIGQUIT , &act , NULL );

// sigemptyset (&block_int_quit);
// sigaddset (&block_int_quit, SIGINT);
// sigaddset (&block_int_quit, SIGQUIT);

// sigfillset (&( childAct . sa_mask ));
// childAct.sa_flags = SA_RESTART;
// childAct.sa_handler = sigChildDeathHandler;
// childAct.sa_mask = block_int_quit;
// sigaction ( SIGCHLD , &childAct , NULL );

// sigset_t emptyMask;
// sigemptyset (&emptyMask);

// void queueUpcomingSignals() {

// 	int res = sigprocmask(SIG_BLOCK, &block_int_quit, NULL);
// 	while (res == -1)
// 		res = sigprocmask(SIG_BLOCK, &block_int_quit, NULL);
// }

// void unblockSignals() {
// 	int res = sigprocmask(SIG_SETMASK, &emptyMask, NULL);
// 	while (res == -1)
// 		res = sigprocmask(SIG_SETMASK, &emptyMask, NULL);

// }

