#include "mainStructs.h"

citizenHashTableNode** citizenHashTable = NULL;
countryNode* countryList = NULL;
int countryCount = 0;

void hashTableInit() {

	citizenHashTable = calloc(HASH_BUCKET_SIZE, sizeof(citizenHashTableNode));
 
}

// HashFunction used by hashTable
unsigned long djb2_HT(char* str, int bucketCount)
{
    unsigned long hash = 5381;
    int c;

    while(c = *str++) {
        hash = ((hash << 5) + hash) + c; /* hash * 33 + c */
    }
    return hash % bucketCount;
}

citizenRecord* insert_citizen_hashTable(citizenRecord* citRecord) {

	int hashKey = djb2_HT(citRecord->citizenId, HASH_BUCKET_SIZE);

	if (citizenHashTable[hashKey] == NULL) {

		citizenHashTable[hashKey] = malloc(sizeof(citizenHashTableNode));
		citizenHashTable[hashKey]->nextNode = NULL;

		citizenHashTable[hashKey]->citRecord = citRecord;

		return citRecord;
	}

	citizenHashTableNode* prevNode = NULL;
	citizenHashTableNode* curNode = citizenHashTable[hashKey];

	while (curNode != NULL) {

		if (strcmp(citRecord->citizenId, curNode->citRecord->citizenId) == 0) {

			if (strcmp(citRecord->firstName, curNode->citRecord->firstName) != 0) 
				return NULL;

			if (strcmp(citRecord->lastName, curNode->citRecord->lastName) != 0) 
				return NULL;

			if (strcmp(citRecord->country, curNode->citRecord->country) != 0) 
				return NULL;

			if (citRecord->age != curNode->citRecord->age)
				return NULL;

			return citRecord;
		}

		prevNode = curNode;
		curNode = curNode->nextNode;

	}

	prevNode->nextNode = malloc(sizeof(citizenHashTableNode));
	prevNode->nextNode->nextNode = NULL;
	prevNode->nextNode->citRecord = citRecord;

	return citRecord;

}

citizenRecord* find_citizen_hashTable(char* citID) {

	int hashKey = djb2_HT(citID, HASH_BUCKET_SIZE);

	citizenHashTableNode* curNode = citizenHashTable[hashKey];

	while (curNode != NULL) {

		if (strcmp(citID, curNode->citRecord->citizenId) == 0) {
			return curNode->citRecord;
		}

		curNode = curNode->nextNode;
	}

	return NULL;

}

void printHT() {

	printf("HashTable size is %d\n", HASH_BUCKET_SIZE);
	for (int i = 0 ; i < HASH_BUCKET_SIZE ; i++) {
		citizenHashTableNode* curNode = citizenHashTable[i];
		printf("HashTable[%d]:", i);
		while(curNode != NULL) {

			printf("-> %s", curNode->citRecord->citizenId);
			curNode = curNode->nextNode;
		}
		printf("\n");
	}
	

}

void freeCitizenRecord(citizenRecord* citRec) {

	free(citRec->citizenId);
	free(citRec->firstName);
	free(citRec->lastName);
	free(citRec);

}

void freeHT() {

	for (int i = 0 ; i < HASH_BUCKET_SIZE ; i++) {

	citizenHashTableNode* prevNode = NULL;
	citizenHashTableNode* curNode = citizenHashTable[i];

		while(curNode != NULL) {

			prevNode = curNode;
			curNode = curNode->nextNode;

			freeCitizenRecord(prevNode->citRecord);

			free(prevNode);
		}
	}

	
	free(citizenHashTable);

}

void getDate(myDate* date, char* dateStr) {

	// char parser[64];
	char* parser = calloc(128, sizeof(char));
	for(int i = 0 ; i < 11 ; i ++) {
		parser[i] = dateStr[i];
	}

	parser[12] = 0;
	sscanf(parser,"%d-%d-%d", &date->day,&date->month, &date->year);
	free(parser);
	return;


}

int validateDate(char* date, int printBool) {

	int res = 1;

	if (strlen(date) != 10) {
		if (printBool)
			printf("ERROR IN DATE FORMAT |%s| (SOULD BE |DD-MM-YYYY|)\n", date);
		return 0;
	}

	char parser[512];
	strcpy(parser, date);

	myDate tempDate;
	sscanf(parser, "%d-%d-%d", &tempDate.day, &tempDate.month, &tempDate.year);

	if (tempDate.day > 30 || tempDate.day < 0) {
		res = 0;
	}
	else if (tempDate.month > 12 || tempDate.month < 0) {
		res = 0;
	}
	else if (tempDate.year < 1000 || tempDate.year > 9999) {
		res = 0;
	}

	if (!res && printBool)
		printf("|ERROR|: DATE FORMAT |%s| (SOULD BE |DD/MM/YYYY|)\n", date);

	return res;

}

void removeChar(char* s, char c)
{
 
    int j, n = strlen(s);
    for (int i = j = 0; i < n; i++)
        if (s[i] != c)
            s[j++] = s[i];
 
    s[j] = '\0';
}

int compareDate(char* date1, char* date2) {

	myDate tempDate1 = {0};
	myDate tempDate2 = {0};

	if (strcmp(date1,date2) == 0) {
		return 0;
	}

	getDate(&tempDate1, date1);
	getDate(&tempDate2, date2);

	if (tempDate2.year > tempDate1.year)
		return 1;
	if (tempDate2.year < tempDate1.year)
		return -1;

	if (tempDate2.month > tempDate1.month)
		return 1;
	if (tempDate2.month < tempDate1.month)
		return -1;

	if (tempDate2.day > tempDate1.day)
		return 1;
	if (tempDate2.day < tempDate1.day)
		return -1;


	return -1;
}

citizenRecord* createCitRecord(char* citizenID, char* firstName, char* lastName, char* country, char* age) {

	citizenRecord* newCitRec = malloc(sizeof(citizenRecord));

	newCitRec->citizenId = malloc(((int) strlen(citizenID)+1) * sizeof(char));
	strcpy(newCitRec->citizenId, citizenID);

	newCitRec->firstName = malloc(((int) strlen(firstName)+1) * sizeof(char));
	strcpy(newCitRec->firstName, firstName);

	newCitRec->lastName = malloc(((int) strlen(lastName)+1) * sizeof(char));
	strcpy(newCitRec->lastName, lastName);

	newCitRec->country = search_insert_Country(country, 1);

	newCitRec->age = atoi(age);

	return newCitRec;

}

vaccineRecord* createVacRecord(char* virusName, int vaccinated, char* vaccineDate) {

	vaccineRecord* newVacRec = malloc(sizeof(vaccineRecord));

	newVacRec->vaccineName = malloc(((int) strlen(virusName)+1) * sizeof(char));
	strcpy(newVacRec->vaccineName, virusName);

	newVacRec->citRecord = NULL;

	newVacRec->vaccineDate = NULL;

	if (!vaccinated) {

		newVacRec->vaccinated = 0;

	}
	else {

		newVacRec->vaccinated = 1;

		if (vaccineDate) {
			newVacRec->vaccinated = 1;
			newVacRec->vaccineDate = malloc(((int) strlen(vaccineDate)+1) * sizeof(char));
			strcpy(newVacRec->vaccineDate, vaccineDate);
		}
		else {

			newVacRec->vaccineDate = malloc(12 * sizeof(char));
			time_t now;
			time(&now);

			struct tm* local = localtime(&now);
			if (local->tm_mday<10 &&  local->tm_mon<10)
				sprintf(newVacRec->vaccineDate,"0%d-0%d-%d", local->tm_mday, local->tm_mon + 1, local->tm_year+ 1900);
			else if (local->tm_mday<10)
				sprintf(newVacRec->vaccineDate,"0%d-%d-%d", local->tm_mday, local->tm_mon + 1, local->tm_year+ 1900);
			else if (local->tm_mon<10)
				sprintf(newVacRec->vaccineDate,"%d-0%d-%d", local->tm_mday, local->tm_mon + 1, local->tm_year+ 1900);
			else
				sprintf(newVacRec->vaccineDate,"%d-%d-%d", local->tm_mday, local->tm_mon + 1, local->tm_year+ 1900);
		}

	}

	return newVacRec;

}

int validateCitizen(citizenRecord* findCit,char* citizenID, char* firstName, char* lastName, char* country, char* age)
{
	int res = 1;

	if (strcmp(citizenID, findCit->citizenId) != 0){
		res = 0;
	}
	else if (strcmp(firstName, findCit->firstName) != 0){
		res = 0;
	}
	else if (strcmp(lastName, findCit->lastName) != 0){
		res = 0;
	}
	else if (strcmp(country, findCit->country) != 0){
		res = 0;
	}
	else if (atoi(age) != findCit->age){
		res = 0;
	}

	if(!res)
		printf("ERROR: IVALID INPUT CITIZEN %s ALREADY EXISTS WITH OTHER INFO: %s %s %s %d\n", findCit->citizenId, findCit->firstName, findCit->lastName, findCit->country,findCit->age);

	return res;

}

char* search_insert_Country(char* countryName, int mode) {

	if (!countryList) {

		countryCount++;

		countryList = malloc(sizeof(countryNode));

		countryList->countryName = malloc(((int) strlen(countryName)+1) * sizeof(char));
		strcpy(countryList->countryName, countryName);

		countryList->nextCountry = NULL;

		return countryList->countryName;
	}

	countryNode* prevNode = NULL;
	countryNode* curNode = countryList;

	while (curNode) {

		if (strcmp(curNode->countryName, countryName) == 0) {
			return curNode->countryName;
		}

		prevNode = curNode;
		curNode = curNode->nextCountry;

	}

	if (!mode)
		return NULL;

	prevNode->nextCountry = malloc(sizeof(countryNode));
	prevNode->nextCountry->countryName = malloc(((int) strlen(countryName)+1) * sizeof(char));
	strcpy(prevNode->nextCountry->countryName, countryName);
	prevNode->nextCountry->nextCountry = NULL;

	countryCount++;

	return prevNode->nextCountry->countryName;

}

void freeCountryList() {

	if (!countryList)
		return;

	countryNode* prevNode = NULL;
	countryNode* curNode = countryList;

	while(curNode) {

		prevNode = curNode;
		curNode = curNode->nextCountry;

		free(prevNode->countryName);
		free(prevNode);

	}



}