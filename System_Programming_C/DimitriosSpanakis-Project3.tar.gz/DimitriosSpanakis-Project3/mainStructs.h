#ifndef MAIN_STRUCTS
#define MAIN_STRUCTS

#define HASH_BUCKET_SIZE 1000

#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <time.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <dirent.h>


// This struct will be used for citizen vaccination records
typedef struct citizenRecord {

	char* citizenId;
	char* firstName;
	char* lastName;
	char* country;
	int age;

} citizenRecord;

typedef struct vaccineRecord {

	citizenRecord* citRecord;

	char* vaccineName;
	int vaccinated;
	char* vaccineDate; 

} vaccineRecord;

typedef struct citizenHashTableNode {

	citizenRecord* citRecord;
	struct citizenHashTableNode* nextNode;

} citizenHashTableNode;

typedef struct virusAgeStats {

	int stat_0_20;
	int stat_20_40;
	int stat_40_60;
	int stat_60plus;

} virusAgeStats;


typedef struct virusPopulationStats {

	int vaccinatedCount;
	int non_vaccinatedCount;

} virusPopulationStats;

// This struct will be used for countries and vaccine types.
typedef struct myDate {

	int day;
	int month;
	int year;

} myDate;

typedef struct countryNode {

	char* countryName;
	struct countryNode* nextCountry;

} countryNode;

void getDate(myDate* , char* );
int validateDate(char* , int);
int compareDate(char* , char* );

void hashTableInit(); 
citizenRecord* insert_citizen_hashTable(citizenRecord*);

citizenRecord* find_citizen_hashTable(char*);

char* search_insert_Country(char* , int);

void printHT();
void freeHT();
void freeCountryList(); 

void removeChar(char* , char );
#endif /* !MAIN_STRUCTS */
