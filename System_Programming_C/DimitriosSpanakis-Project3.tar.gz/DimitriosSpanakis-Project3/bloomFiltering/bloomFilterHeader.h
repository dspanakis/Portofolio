#include "../mainStructs.h"
#ifndef BLOOM_H
#define BLOOM_H

typedef unsigned long (*hash_function)(char *str);

//Bloom filter structure
typedef struct bloomFilter {
	// Array to store all bits
	char* vaccineName;
	char* bitArray;
	struct bloomFilter* nextBloomFilter;

} bloomFilter;

bloomFilter* search_or_append_BloomFilter(char* , int);
bloomFilter* search_or_append_BloomFilter_specific(bloomFilter* , char*, int);

int get_BloomFilter_Bit(char* , int);
void toggle_BloomFilter_Bit(char* , int);
void set_BloomFilter_Bit(char*, int, int);

unsigned long djb2(char* );
unsigned long sdbm(char* );
unsigned long hash_i(char *, int i);

void insert_to_BloomFilter(char* , char* );
void insert_to_specific_BloomFilter(bloomFilter* , char* , char* );

int vaccineStatusBloom(char* , char* );
void print_vaccineStatusBloom(char* , char* );

int vaccineStatusBloom_specific(bloomFilter*, char* , char* );
void print_vaccineStatusBloom_specific(bloomFilter*, char* , char* );

void freeBloomFilter_specific(bloomFilter*);
void freeBloomFilters();

#endif /* !BLOOM_H */
