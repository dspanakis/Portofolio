#include "../bloomFiltering/bloomFilterHeader.h"
#include "../skipList/skipListHeader.h"
#include <poll.h>
#include "../mainStructs.h"
#include <netinet/in.h>
// Fort hton
#include <arpa/inet.h>

#include <sys/types.h>
#include <ctype.h>
#include <sys/socket.h>
// For gethostbyaddress
#include <netdb.h>
#include <pthread.h>

typedef struct cyclicBuffer{

	char** data;
	int start;
	int end;
	int count;

} cyclicBuffer;

typedef struct fileReadNode {

	char* path;

	struct fileReadNode* nextFile;

} fileReadNode;

typedef struct directoryReadNode {

	char* path;

	struct fileReadNode* fileReadNodeHead;
	struct directoryReadNode* nextDirectory;

} directoryReadNode;

void rmSubstr(char* , const char* );

char** initialiseMonitorServer(int , char** );
void createAndHostServer();
int acceptConnection();


int file_exists (char* );
int isDirectory(char* );
void insertFile(fileReadNode** , char* );
directoryReadNode* findWorkingDir(char* );
directoryReadNode* appendWorkingDir(char* );
void appendWorkingFile(directoryReadNode* , char* );
void appendFileToStructs (char* );

void appendWorkingDirToStructs(char* ); 

void placeToCyclicBuffer(char* );
char* getDirFromCyclicBuffer();
char* getFileFromCyclicBuffer();
void* consumeFilePaths(void* );
void* consumeDirPaths(void* );
void fillUpCyclicBufferWithFilePaths(char** );
void destroyMutexesAndConds();
void initialiseMutexesAndConds();

fileReadNode* findFile(directoryReadNode* , char* );
int checkForDirFilesChanges(directoryReadNode*, fileReadNode** );
int checkAllDirsForChanges(fileReadNode**);

void sendBloomFilterBuffer(char* , int );
void sendBloomFilterBufferRemainings();
void sendBloomFilterBuffered(bloomFilter* );
void sendBloomFilters();

// char* receiveMonitorString();
// Extended functions polls in command reader-server and exececutes queued signals
char* receiveMonitorString_Extended();

void travelRequestServer(char* ,char* , char* , int );
void searchVaccinationStatusServer(char* );

void parent_Command_Reader_Server();

void initialise_and_execute(int , char** );