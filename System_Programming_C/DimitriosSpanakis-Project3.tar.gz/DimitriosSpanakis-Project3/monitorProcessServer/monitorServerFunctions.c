#include "./monitorServerHeader.h"

// extern vars for citizen record hashTable
extern citizenHashTableNode** citizenHashTable;

// extern vars from BloomFiltering
extern int bloomFilterByteSize;
extern bloomFilter* bloomFilterList;
extern int bloomFilterCount; 
 
//extern vars from SkipList
extern doubleSkipList* skipListHead;

char hostname[128];
int serverPort = 0;
int sock;
int numThreads;
int socketBufferSize;
char* socketBuffer = NULL;
int socketBufferIdx;
int cyclicBufferSize;
char* inputDir = NULL;

int newsock;
cyclicBuffer* cyclicBuff = NULL;
int countriesToConsume = 0;

int pid;

int rejectedTravelRequests = 0;
int acceptedTravelRequests = 0;

directoryReadNode* directoriesReadListHead = NULL;

pthread_mutex_t mtx;
pthread_cond_t cond_nonempty;
pthread_cond_t cond_nonfull;
pthread_cond_t cond_exit;
pthread_mutex_t broadcastMtx;

pthread_mutex_t bloomMtx;
pthread_mutex_t hashTableMtx;
pthread_mutex_t skipListMtx;

pthread_mutex_t workDirMtx;

int termFlag = 0;

int file_exists (char *filename) {
  struct stat  buffer;   
  return (stat (filename, &buffer) == 0);
}

int isDirectory(char *path) {
   struct stat statbuf;
   if (stat(path, &statbuf) != 0)
       return 0;
   return S_ISDIR(statbuf.st_mode);
}


fileReadNode* findFile(directoryReadNode* curCountryDir, char* d_name) {

	if (!curCountryDir->fileReadNodeHead) {
		return NULL;
	}

	fileReadNode* curFile = curCountryDir->fileReadNodeHead;
	while(curFile) {

		if (strcmp(curFile->path, d_name) == 0) {
			return curFile;
		}

		curFile = curFile->nextFile;
	}

	return NULL;
}

directoryReadNode* findWorkingDir(char* dirName) {

	directoryReadNode* curNode = directoriesReadListHead;
	while (curNode) {
		if (strcmp(curNode->path, dirName) == 0)
			return curNode;

		curNode = curNode->nextDirectory;
	}

	return NULL;


}

directoryReadNode* appendWorkingDir(char* path) {

	if (!directoriesReadListHead) {
		directoriesReadListHead = malloc(sizeof(directoryReadNode));
		directoriesReadListHead->fileReadNodeHead = NULL;
		directoriesReadListHead->nextDirectory = NULL;

		directoriesReadListHead->path = malloc((strlen(path) + 1) * sizeof(char));
		directoriesReadListHead->path[0] = 0;

		strcpy(directoriesReadListHead->path, path);

		return directoriesReadListHead;
	}

	directoryReadNode* newNode = calloc(1,sizeof(directoryReadNode));
	newNode->fileReadNodeHead = NULL;
	newNode->nextDirectory = NULL;

	newNode->path = malloc((strlen(path) + 1) * sizeof(char));
	newNode->path[0] = 0;
	strcpy(newNode->path, path);

	newNode->nextDirectory = directoriesReadListHead;
	directoriesReadListHead = newNode;

	return directoriesReadListHead;

}

void appendWorkingFile(directoryReadNode* curDir, char* path) {

	if (!curDir->fileReadNodeHead) {
		curDir->fileReadNodeHead = malloc(sizeof(fileReadNode));
		curDir->fileReadNodeHead->nextFile = NULL;

		curDir->fileReadNodeHead->path = malloc((strlen(path) + 1) * sizeof(char));
		curDir->fileReadNodeHead->path[0] = 0;

		strcpy(curDir->fileReadNodeHead->path, path);

		return;
	}

	fileReadNode* newNode = malloc(sizeof(fileReadNode));
	newNode->nextFile = NULL;
	newNode->path = malloc((strlen(path) + 1) * sizeof(char));
	newNode->path[0] = 0;
	strcpy(newNode->path, path);

	newNode->nextFile = curDir->fileReadNodeHead;

	curDir->fileReadNodeHead = newNode;

	return;

}
int concurrencyCount = 0;
void appendFileToStructs (char* fileName) {

	citizenRecord* newCitRec;
    vaccineRecord* newVacRec;

	int validRecords = 0;
	FILE *fp;
	fp = fopen(fileName,"r");

	if(fp == NULL)
	{
		printf("ERROR OPENING FILE: %s\n", fileName); //If we give not existing txt for read
		exit(1);
	}

	char line[512];
	char checkBuf[52];

	char citizenID[32];
	char firstName[32];
	char lastName[32];
	char country[32];
	char age[32];
	char vaccineType[32];
	char vaccinatedStr[32];
	int vaccinated;
	char vaccineDate[32];
	vaccineDate[0] = '\0';
	int argCount = 0;

	while (fgets(line, sizeof(line), fp)) {
        

        if (strcmp(line, "\n") == 0)
        	continue;

		
		argCount = sscanf(line,"%s %s %s %s %s %s %s %s %s", citizenID, firstName, lastName, country, age, vaccineType, vaccinatedStr, vaccineDate, checkBuf);
		// readRecords++;

		// VALIDATION TAKES PLACE
		if (argCount < 7 || argCount > 8) {
			printf("ERROR IN RECORD %s", line);
			continue;
		}

		if (strcmp(vaccinatedStr, "YES") != 0 && strcmp(vaccinatedStr, "NO") != 0) {
			printf("ERROR IN RECORD %s", line);
			continue;
		}

	    if (strcmp(vaccinatedStr, "YES") == 0)
			vaccinated = 1;
		else if (strcmp(vaccinatedStr, "NO") == 0) {
			vaccinated = 0;
		}
		else
			vaccinated = 3;

		if (argCount > 7 && vaccinated == 0) {
			printf("ERROR IN RECORD %s", line);
			continue;
		}
		else if (vaccinated == 1) {

			if (!validateDate(vaccineDate,0)) {
				printf("ERROR IN RECORD %s", line);
				continue;
			}

		}

		if (atoi(age) > 120) {
			printf("ERROR IN RECORD %s", line);
			continue;
		}

				// SEARCH IF WE HAVE ALREADY RECORED THIS CITIZEN
		pthread_mutex_lock(&hashTableMtx);
		citizenRecord* findCit = find_citizen_hashTable(citizenID);
		pthread_mutex_unlock(&hashTableMtx);
		if (findCit) {

			// Validate citizen ("mainFunctions.c")
			int valRes = validateCitizen(findCit,citizenID,firstName,lastName,country,age);
			
			// If citizen info is changed, print error and continue
			if (!valRes) {
				printf("GIVEN RECORD WAS %s\n", line);
				continue;
			}

			// Check if we already inserted this citizen, in the vaccine list specified
			pthread_mutex_lock(&skipListMtx);
			if(find_from_SkipList(vaccineType,citizenID, 1) != NULL || find_from_SkipList(vaccineType,citizenID, 0) != NULL) {
				line[strlen(line) - 1] = '\0';
				printf("ERROR IN RECORD %s : ALREADY EXISTS IN %s SKIPLIST\n", line, vaccineType);
				pthread_mutex_unlock(&skipListMtx);
				continue;
			}
			else {
				// Else create new vac record, keeping the same citizen info pointer (save some space)
				newVacRec = createVacRecord(vaccineType, vaccinated, vaccineDate);
				newVacRec->citRecord = findCit;

				insert_to_SkipList(newVacRec);
				validRecords++;
				pthread_mutex_unlock(&skipListMtx);

				if (vaccinated)	 {// APPEND TO BLOOM FILTER
					pthread_mutex_lock(&bloomMtx);
					insert_to_BloomFilter(citizenID,vaccineType);
					pthread_mutex_unlock(&bloomMtx);
				}

				continue;

			}

		}
		else {

			// Else create new vac and new cit record and insert to list
			newCitRec = createCitRecord(citizenID, firstName, lastName, country,  age);
			pthread_mutex_lock(&hashTableMtx);
			insert_citizen_hashTable(newCitRec);
			pthread_mutex_unlock(&hashTableMtx);

			newVacRec = createVacRecord(vaccineType, vaccinated, vaccineDate);

			newVacRec->citRecord = newCitRec;
			pthread_mutex_lock(&skipListMtx);
			insert_to_SkipList(newVacRec);
			pthread_mutex_unlock(&skipListMtx);
			validRecords++;

			if (vaccinated)	 { // APPEND TO BLOOM FILTER
				pthread_mutex_lock(&bloomMtx);
				insert_to_BloomFilter(citizenID,vaccineType);
				pthread_mutex_unlock(&bloomMtx);
			}

		}

	    
    }

    fclose(fp);

	return;
}

int checkForDirFilesChanges(directoryReadNode* curCountryDir, fileReadNode** fileListHead) {

	char tempPath[512];
	tempPath[0] = 0;
	strcpy(tempPath, inputDir);
	if (tempPath[strlen(tempPath) - 1] != '/');
		strcat(tempPath, "/");
	strcat(tempPath, curCountryDir->path);

    DIR *dp;
    struct dirent* countryDir;
    struct stat dirCheck;

    if ((dp=opendir(tempPath))== NULL ) {
        perror("opendir"); return -1;
    }
    int newFiles = 0;

    while ((countryDir = readdir(dp)) != NULL ) {

		if (strcmp(countryDir->d_name, ".") == 0 || strcmp(countryDir->d_name, "..") == 0)
			continue;

        // if (strcmp(dirSrc->d_name, countryDir->d_name) == 0) {

        // 	continue;

        // }

        fileReadNode* curFile = findFile(curCountryDir, countryDir->d_name);
       

        if (curFile)
        	continue;

        char filePath[512];
        filePath[0] = 0;

        strcpy(filePath, tempPath);
		strcat(filePath, "/");
		strcat(filePath, countryDir->d_name);

		printf("NEW FILE FOUND |%s|\n\n", filePath);


        appendWorkingFile(curCountryDir , countryDir->d_name);
        // appendFileToStructs(filePath);
        insertFile(fileListHead, filePath);

        newFiles += 1;

    }
    
    closedir(dp);
    return newFiles;

}

int checkAllDirsForChanges(fileReadNode** fileListHead) {
	directoryReadNode* curDir = directoriesReadListHead;
	int newRecordsBool = 0;
	int newChanges = 0;
	while(curDir) {
		newChanges = checkForDirFilesChanges(curDir, fileListHead);
		if (!newRecordsBool)
			if(newChanges)
				newRecordsBool += newChanges;

		curDir = curDir->nextDirectory;
	}

	return newRecordsBool;
}

// --- Send Bloom Filter Functions Start ---
// The below two buffering functions are used to buffer any char stream!!
void sendBloomFilterBuffer(char* charBuffer, int charBufferSize) {

	int charBufferIdx = 0;

	// foreach char in buffer
	while (charBufferIdx < charBufferSize) {

		// if char buffer > internal transmission buffer
		if (socketBufferSize - socketBufferIdx > charBufferSize - charBufferIdx) {
			// copy to internal transmission buffer
			int charsToCopy = charBufferSize - charBufferIdx; 
			memcpy(socketBuffer + socketBufferIdx, charBuffer + charBufferIdx, charsToCopy * sizeof(char));
			// charBufferIdx += charsToCopy; -- not needed due to return (function complered and exits)
			socketBufferIdx += charsToCopy;
			return;

		}
		else {
			// copy to internal transmission buffer
			int charsToCopy = socketBufferSize - socketBufferIdx; 
			memcpy(socketBuffer + socketBufferIdx, charBuffer + charBufferIdx, charsToCopy * sizeof(char));
			// send internal transmission buffer
			int bytesWritten = 0;
			while (bytesWritten < socketBufferSize) {
				int n = write(newsock, socketBuffer + bytesWritten, (socketBufferSize-bytesWritten) * sizeof(char));
				if(n != -1)
					bytesWritten += n;
			}
			// printf("Bytes written %d\n", bytesWritten);
			charBufferIdx += charsToCopy;
			if (bytesWritten != socketBufferSize) {
				printf("WRITTEN LESS THAN EXPECTED!!\n");
			}
			// reset (reuse) internal transmission buffer
			socketBufferIdx = 0;
		}
	}
}

void sendBloomFilterBufferRemainings() {
	if (socketBufferIdx) {
		int bytesWritten = 0;
		while (bytesWritten < socketBufferIdx) {
			int n = write(newsock, socketBuffer + bytesWritten, (socketBufferIdx-bytesWritten) * sizeof(char));
			if(n != -1)
				bytesWritten += n;
		}
	}
}

//
void sendBloomFilterBuffered(bloomFilter* curBloom) {


	// bloomFilterSendSize the total bytes (characters) to be send
	int bloomFilterSendSize = (strlen(curBloom->vaccineName) + 1) + bloomFilterByteSize;

	// bloomFilterSendBuffer contains all bloom filter data to be send
	char* bloomFilterSendBuffer = calloc(bloomFilterSendSize, sizeof(char));
	
	// copy in bloomFilterSendBuffer Vaccine Name
	strcpy(bloomFilterSendBuffer, curBloom->vaccineName);

	// append in bloomFilterSendBuffer Bit Array
	memcpy(bloomFilterSendBuffer + strlen(curBloom->vaccineName) + 1, curBloom->bitArray, bloomFilterByteSize*sizeof(char));

	// sends bloom filter data in smaller pieces
	sendBloomFilterBuffer(bloomFilterSendBuffer, bloomFilterSendSize);

	// free message sent
	free(bloomFilterSendBuffer);
}

void sendBloomFilters() {

	socketBufferIdx = 0;
	socketBuffer[0] = 0;
	bloomFilter* curBloom = bloomFilterList;

	// foreach bloom filter (linked list)
	while (curBloom) {
		// printf("SENDING %s BLOOM\n",curBloom->vaccineName);
		sendBloomFilterBuffered(curBloom);
		curBloom = curBloom->nextBloomFilter;
	}
	char* ending = "~";
	sendBloomFilterBuffer(ending, 1);
	sendBloomFilterBufferRemainings();


}
// --- Send Bloom Filter Functions End ---


char* receiveMonitorString_Extended() {

	socketBuffer[0] = 0;
	char* messageString = malloc(socketBufferSize*sizeof(char));
	long int messageTotalSize = socketBufferSize;
	long int messageIdx = 0;

	struct pollfd fds[1];
	int timeout_msecs = 1000;
	int ret;

	fds[0].fd = newsock;
	fds[0].events = POLLIN;
	while (1)
	{
		ret = poll(fds, 1, timeout_msecs);
	
		if (ret == -1 || ret == 0) {
			continue;
		}

		if((fds[0].revents&POLLIN) == POLLIN) {
			int bytesRead = read(newsock, socketBuffer, socketBufferSize*sizeof(char));

			if (bytesRead == -1 || bytesRead == 0)
				continue;

           	if (messageIdx + bytesRead > messageTotalSize) {

           		messageString = realloc(messageString, 2*messageTotalSize);
           		messageTotalSize*=2;

           	}

			memcpy(messageString + messageIdx, socketBuffer, bytesRead*sizeof(char));

			messageIdx+=bytesRead;

			int termCharFlag = 0;
			for (int i = 0; i < messageIdx ; i++) {
				if (messageString[i] == '~') {
					messageString[i] = 0;
					termCharFlag = 1;
					break;
				}
			}

			if (termCharFlag)
				break;

		}
	}

	return messageString;

}

// An optimal function to remove substring of string, used from threads
void rmSubstr(char *str, const char *toRemove)
{
    size_t length = strlen(toRemove);
    char *found,
         *next = strstr(str, toRemove);

    for (size_t bytesRemoved = 0; (found = next); bytesRemoved += length)
    {
        char *rest = found + length;
        next = strstr(rest, toRemove);
        memmove(found - bytesRemoved,rest, next ? next - rest: strlen(rest) + 1);
    }
}

void travelRequestServer(char* citizenID,char* virusName, char* date1, int fdWrite) {

	skipNode* res;
	res = find_from_SkipList(virusName, citizenID, 1);

	char resString[64];
	resString[0] = 0;
	if (res)
	{
		sprintf(resString ,"YES %s ~", res->vacRecord->vaccineDate);

		myDate* travelDate = malloc(sizeof(myDate));
		getDate(travelDate, date1);

		myDate* vacDate = malloc(sizeof(myDate));
		
		getDate(vacDate, res->vacRecord->vaccineDate);

		if(compareDate(date1 , res->vacRecord->vaccineDate) == 1) {
			
			// printf("TRAVEL DATE IS BEFORE VACCINATION DATE...MAYBE U LIVE IN THE PAST...\n");
			rejectedTravelRequests += 1;
			
		}
		else if (vacDate->year < travelDate->year ) {

			if(12*(travelDate->year - vacDate->year) + travelDate->month - vacDate->month <= 6) {

				if (travelDate->day > vacDate->day) {
					rejectedTravelRequests += 1;
				}
				else {
					acceptedTravelRequests += 1;
				}

			}
			else {
				rejectedTravelRequests += 1;
			}


		}
		else if ( abs(vacDate->month - travelDate->month ) <= 6) {
			if (vacDate->day <= travelDate->day) {
				acceptedTravelRequests += 1;
			}
			else {
				printf("REQUEST REJECTED – YOU WILL NEED ANOTHER VACCINATION BEFORE TRAVEL DATE\n");
				rejectedTravelRequests += 1;
			}
				
			
		}
		else {

			rejectedTravelRequests += 1;
		}

		free(travelDate);
		free(vacDate);
	}
	else {
		strcpy(resString, "NO ~");
		rejectedTravelRequests += 1;
	}
	socketBufferIdx = 0;
	sendBloomFilterBuffer(resString, (strlen(resString)));
	sendBloomFilterBufferRemainings();	
	socketBufferIdx = 0;

}
// -- Travel Request Server End --

void searchVaccinationStatusServer(char* citizenID) {

	// sleep(1);
	socketBufferIdx = 0;
	citizenRecord* curCitizen = find_citizen_hashTable(citizenID);
	if (!curCitizen) {
		char* ending = "~";		
		sendBloomFilterBuffer(ending, 1);
		sendBloomFilterBufferRemainings();
		socketBufferIdx = 0;
		return;
	}

	doubleSkipList* curList = skipListHead;

	char citInfoStr[128];
	citInfoStr[0] = 0;

	sprintf(citInfoStr, "%s %s %s %s\nAGE %d\n", curCitizen->citizenId, curCitizen->firstName, curCitizen->lastName, curCitizen->country, curCitizen->age);
	sendBloomFilterBuffer(citInfoStr, strlen(citInfoStr));

	skipNode* curNode = NULL;
	char vacInfoRow[128];
	vacInfoRow[0] = 0;

	while (curList) {

		vacInfoRow[0] = 0;
		curNode = find_from_SkipList(curList->vaccineName, citizenID, 1);
		if (curNode) {

			sprintf(vacInfoRow, "%s VACCINATED ON %s\n", curList->vaccineName, curNode->vacRecord->vaccineDate);
			sendBloomFilterBuffer(vacInfoRow, strlen(vacInfoRow));

		}
		else {

			sprintf(vacInfoRow, "%s NOT YET VACCINATED\n", curList->vaccineName);
			sendBloomFilterBuffer(vacInfoRow, strlen(vacInfoRow));

		}

		curList = curList->nextList;

	}
	char* ending = "~";
	sendBloomFilterBuffer(ending, 1);
	sendBloomFilterBufferRemainings();

}

void insertFile(fileReadNode** fileListHead, char* path) {

	if (!(*fileListHead)->path) {
		(*fileListHead)->path = calloc(strlen(path) + 1, sizeof(char));
		strcpy((*fileListHead)->path, path);
		return;
	}

	fileReadNode* newFile = calloc(1, sizeof(fileReadNode));
	newFile->path = calloc(strlen(path) + 1, sizeof(char));
	strcpy(newFile->path, path);
	fileReadNode* curFile = *fileListHead;

	newFile->nextFile = *fileListHead;
	(*fileListHead) = newFile;

	return;
}

char* replace_char(char* str, char find, char replace){
    char *current_pos = strchr(str,find);
    while (current_pos) {
        *current_pos = replace;
        current_pos = strchr(current_pos,find);
    }
    return str;
}
 
void* consumeFilePaths(void* ptr) {

	while (countriesToConsume > 0 || cyclicBuff->count > 0) {

		char* filePathPtr = getFileFromCyclicBuffer();

		pthread_cond_signal(&cond_nonfull);

		if (filePathPtr) {

			char tempStr[512];
			strcpy(tempStr,filePathPtr);

			rmSubstr(tempStr, inputDir);

			char countryName[64];
			char fileName[256];
			int slashCount = 0;

			char* strPtr = countryName;
			for (int i = 0 ; i < strlen(tempStr) + 1 ; i++) {

				if (tempStr[i] == '/') {
					slashCount+=1;
					continue;
				}

				if (slashCount == 2)
				{
					slashCount = 0;
					*strPtr = 0;
					strPtr =  fileName;
				}

				*strPtr = tempStr[i];
				strPtr++;

			}

			directoryReadNode* curDir = findWorkingDir(countryName);

			pthread_mutex_lock(&workDirMtx);
			appendWorkingFile(curDir, fileName);
			pthread_mutex_unlock(&workDirMtx);
		
			appendFileToStructs(filePathPtr);

		}

	}

	return NULL;
}

void addVaccinationRecords() {


	fileReadNode* fileList = calloc(1, sizeof(fileReadNode));

	int newRecordsCount = checkAllDirsForChanges(&fileList);

	if (!newRecordsCount) {
		char* skipSendBloomMsg = "~";
		int n = -1;
		while (n == -1)
			n = write(newsock, skipSendBloomMsg, 1);

		free(fileList);
		return;
	}

	printf("NEW FILES COUNT %d\n", newRecordsCount);
	countriesToConsume = newRecordsCount;
	free(cyclicBuff->data);
	cyclicBuff->data = calloc(cyclicBufferSize, sizeof(char*));
	cyclicBuff->end = -1;
	cyclicBuff->count = 0;
	cyclicBuff->start = 0;
	
	initialiseMutexesAndConds();

	fileReadNode* curNode = fileList;
	char** parser = calloc(newRecordsCount + 1, sizeof(char*));
	for (int i = 0 ; i < newRecordsCount + 1 ;i++) {

		if (!curNode) {
			parser[i] = NULL;
			break;
		}
		else {
			parser[i] = curNode->path;
		}
		curNode = curNode->nextFile;
	}

	termFlag = 0;

	pthread_t* threadArray = calloc(numThreads, sizeof(pthread_t));
	for (int i = 0; i < numThreads ; i++) {
		pthread_create(&threadArray[i], 0, consumeFilePaths, 0);
	}

	fillUpCyclicBufferWithFilePaths(parser);
	
	termFlag = 1;

	pthread_cond_broadcast(&cond_nonempty);

	for (int i = 0 ; i < numThreads ; i++) {
		pthread_join(threadArray[i], 0);
	}

	free(threadArray);
	free(parser);

	destroyMutexesAndConds();


	curNode = fileList;
	fileReadNode* prevNode = NULL;
	while(curNode) {
		prevNode = curNode;
		curNode = curNode->nextFile;

		if (prevNode->path)
			free(prevNode->path);
		free(prevNode);

		
	}

	sendBloomFilters();

}



char** initialiseMonitorServer(int argc, char* argv[]) {

	serverPort = atoi(argv[2]);
	numThreads = atoi(argv[4]);
	socketBufferSize = atoi(argv[6]);
	cyclicBufferSize = atoi(argv[8]);
	bloomFilterByteSize = atoi(argv[10]);

	socketBufferIdx = 0;
	socketBuffer = calloc(socketBufferSize, sizeof(char));

	//Initialise cyclicBuffer;
	cyclicBuff = malloc(1*sizeof(cyclicBuffer));
	cyclicBuff->data = calloc(cyclicBufferSize, sizeof(char*));
	cyclicBuff->end = -1;
	cyclicBuff->count = 0;
	cyclicBuff->start = 0;

	char* countriesFilePathsStr = argv[11];
	if (countriesFilePathsStr[0] == '~')
		return NULL;
	inputDir = calloc(128,sizeof(char));
	int inputDirIdx = 0;
	int slashCount = 0;
	char* lastSlashPtr;
	while (1) {
		if (countriesFilePathsStr[inputDirIdx] == '/') {
			slashCount++;
			lastSlashPtr = inputDir + inputDirIdx;
		}
		if (countriesFilePathsStr[inputDirIdx] == ' ')
			break;

		inputDir[inputDirIdx] = countriesFilePathsStr[inputDirIdx];
		inputDirIdx++;
	}

	if (slashCount > 1)
		*lastSlashPtr = 0;

	int spaceOccurCount = 0;
	for (spaceOccurCount=0; countriesFilePathsStr[spaceOccurCount]; countriesFilePathsStr[spaceOccurCount]==' ' ? spaceOccurCount++ : *countriesFilePathsStr++);
	char** countryPathBuffer = calloc(1,(spaceOccurCount + 1)*sizeof(char*));
	int ptrIdx = 0;
	countriesFilePathsStr = argv[11];
	int bufferIdx = 0;
	for (int i = 0 ; i < strlen(argv[11]) ; i++) {

		if (!ptrIdx)
			countryPathBuffer[bufferIdx++] = countriesFilePathsStr + i;

		if (countriesFilePathsStr[i] == ' ')
			ptrIdx = 0;
		else
			ptrIdx++;

	}
	countriesToConsume = spaceOccurCount;
	
	return countryPathBuffer;

}

void freeSavedFiles(directoryReadNode* curDir) {

	fileReadNode* prevFile = NULL;
	fileReadNode* curFile = curDir->fileReadNodeHead;

	while(curFile) {
		prevFile = curFile;
		curFile = curFile->nextFile;
	
		free(prevFile->path);
		free(prevFile);

	}

}

void freeSavedDirsAndFiles() {

	directoryReadNode* prevDir = NULL;
	directoryReadNode* curDir = directoriesReadListHead;

	while(curDir) {

		prevDir = curDir;
		curDir = curDir->nextDirectory;

		freeSavedFiles(prevDir);
		if (prevDir->path)
			free(prevDir->path);
		free(prevDir);

	}


}

void createLogs() {

	int pid = getpid();

	char pidStr[10];
	pidStr[0] = 0;

	sprintf(pidStr, "%d", pid);

	char logFileName[64];
	logFileName[0] = 0;
	strcat(logFileName, "./logFiles/log_file.");
	strcat(logFileName, pidStr);

	FILE* fp = fopen(logFileName, "a");
	directoryReadNode* curDir = directoriesReadListHead;
	while (curDir) {

		fprintf(fp, "%s\n", curDir->path);
		curDir= curDir->nextDirectory;

	}
	fprintf(fp, "TOTAL TRAVEL REQUESTS %d\n", rejectedTravelRequests + acceptedTravelRequests);
	fprintf(fp, "ACCEPTED %d\n", acceptedTravelRequests);
	fprintf(fp, "REJECTED %d\n\n", rejectedTravelRequests);

	fclose(fp);


}

void exitMonitorServer() {

	createLogs();	

	freeBloomFilters();
	freeHT();
	freeCountryList();
	freeDoubleSkipList();

	if (inputDir)
		free(inputDir);
	free(socketBuffer);
	free(cyclicBuff->data);
	free(cyclicBuff);

	freeSavedDirsAndFiles();

	close(sock);
	close(newsock);

	exit(1);
}

void parent_Command_Reader_Server() {

	char* resString = receiveMonitorString_Extended();
	// printf("resString %s\n", resString);
	char command[64];
	char citizenID[32];
	char countryFrom[32];
	char countryTo[32];
	char vaccineType[32];
	char date1[32];
	char date2[32];

	sscanf(resString, "%s", command);
	if (strcmp(command, "trvlRq") == 0) {

		sscanf(resString, "%*s %s %s %s", citizenID, date1, vaccineType);

		travelRequestServer(citizenID, vaccineType, date1, newsock);

	}
	else if (strcmp(command, "sVacSt") == 0) {
		sscanf(resString, "%*s %s", citizenID);

		searchVaccinationStatusServer(citizenID);
	}

	else if (strcmp(command, "addVcRe") == 0){

		addVaccinationRecords();	

	}
	else if (strcmp(command, "ext") == 0) {

		free(resString);
		exitMonitorServer();

	}

	free(resString);

	return;

}

void placeToCyclicBuffer(char* data) {
	pthread_mutex_lock(&mtx);
	while (cyclicBuff->count >= cyclicBufferSize) {
		// printf("BufferFull!!\n");
		pthread_cond_wait(&cond_nonfull, &mtx);

	}
	cyclicBuff->end = (cyclicBuff->end + 1) % cyclicBufferSize;
	cyclicBuff->data[cyclicBuff->end] = data;
	cyclicBuff->count++;
	pthread_mutex_unlock(&mtx);

}

void fillUpCyclicBufferWithFilePaths(char** countryPathBufferArray) {

	char** parser = countryPathBufferArray;
	int i = 0;
	while(parser[i]) {
		
		placeToCyclicBuffer(parser[i]);
		countriesToConsume--;
		pthread_cond_signal(&cond_nonempty);
		i++;
	}

}

char* getDirFromCyclicBuffer() {
	char* data = NULL;
	pthread_mutex_lock(&mtx);
	while (cyclicBuff->count <= 0 && termFlag == 0) {

		pthread_cond_wait(&cond_nonempty, &mtx);

	}

	char* dataCopy = NULL;

	if (cyclicBuff->count > 0 || termFlag == 0) {
		char* data = cyclicBuff->data[cyclicBuff->start];

		dataCopy = calloc(256, 1);

		int idx = 0;
		while (1) {
				// printf("%c\n", data[idx]);
			if (data[idx] == ' ' || data[idx] == 0) {
				dataCopy[idx] = 0;
				break;
			}

			dataCopy[idx] = data[idx];
			idx+=1;
		}

		cyclicBuff->start = (cyclicBuff->start + 1) % cyclicBufferSize;
		cyclicBuff->count--;

	}

	pthread_mutex_unlock(&mtx);
	return dataCopy;
}

char* getFileFromCyclicBuffer() {
	char* data = NULL;
	pthread_mutex_lock(&mtx);
	while (cyclicBuff->count <= 0 && termFlag == 0) {

		pthread_cond_wait(&cond_nonempty, &mtx);

	}

	if (cyclicBuff->count > 0 || termFlag == 0) {
		data = cyclicBuff->data[cyclicBuff->start];

		cyclicBuff->start = (cyclicBuff->start + 1) % cyclicBufferSize;
		cyclicBuff->count--;
	}

	pthread_mutex_unlock(&mtx);
	return data;
}

void* consumeDirPaths(void* ptr) {

	while (countriesToConsume > 0 || cyclicBuff->count > 0) {

		char* dirPathPtr = getDirFromCyclicBuffer();
		if (dirPathPtr == NULL)
		{
			pthread_cond_signal(&cond_nonfull);
			return NULL;
		}


		pthread_cond_signal(&cond_nonfull);

		appendWorkingDirToStructs(dirPathPtr);

		free(dirPathPtr);
	}

	return NULL;

}

void appendWorkingDirToStructs(char* dirPath) {
	char dirName[128];
	strcpy(dirName, dirPath);
	rmSubstr(dirName, inputDir);
	rmSubstr(dirName, "/");

	pthread_mutex_lock(&workDirMtx);
	directoryReadNode* curDir = appendWorkingDir(dirName);
	pthread_mutex_unlock(&workDirMtx);

	char curWorkFile[256];
	DIR *dp = NULL;
	struct dirent *dptr = NULL;
	if (isDirectory(dirPath)) {

		if ((dp = opendir(dirPath))) {

			while((dptr = readdir(dp)) != NULL) {

				if (strcmp(dptr->d_name, ".") == 0 || strcmp(dptr->d_name, "..") == 0)
					continue;

				appendWorkingFile(curDir, dptr->d_name);

				strcpy(curWorkFile, dirPath);
				strcat(curWorkFile, "/");
				strcat(curWorkFile, dptr->d_name);

				appendFileToStructs(curWorkFile);
			}
		}
	}
	closedir(dp);
}


