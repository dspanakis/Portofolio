#!/bin/bash

INPUTFILE=${1?ERROR: NO INPUT FILE}
INPUTDIR=${2?ERROR: NO INPUT DIR}
NUMFILESPERDIRECTORY=${3?ERROR: NO numFilesPerDirectory GIVEN}

re='^[0-9]+$'
if ! [[ "$NUMFILESPERDIRECTORY" =~ $re ]] ; then
	echo "numFilesPerDirectory is not a positive number! Exiting..."
	exit 1
else
	if [ $NUMFILESPERDIRECTORY -eq 0 ] ; then
		echo "numFilesPerDirectory is not a positive number! Exiting..."
		exit 1
	fi
fi

if ! [ -f "$INPUTFILE" ]; then
    echo "Input file |$INPUTFILE| does not exist! Exiting..."
    exit 1
fi

if [ -d "$INPUTDIR" ]; then
	echo "Directory |$INPUTDIR| already exists! Exiting..."
	exit 1
else
	mkdir "$INPUTDIR"
fi

echo "Generating sub-directories and infiles..."
while IFS= read -r line
do
	curCountry=$(echo "$line" | awk '{print $4}')
	curDirectory="$INPUTDIR/$curCountry"
	# echo "$curCountry + $line"


	if ! [ -d $curDirectory ]; then
		mkdir $curDirectory
		for (( i=1; i<=$NUMFILESPERDIRECTORY; i++ ))
		do  
		   touch "$curDirectory/$curCountry-$i.txt"
		done
	fi

	fileWithLeastRecords="$curDirectory/$curCountry-1.txt"
	lowestLines=$(wc -l "$curDirectory/$curCountry-1.txt" | awk '{ print $1 }')
	for (( i=2; i<=$NUMFILESPERDIRECTORY; i++ ))
		do  
			curLines=$(wc -l "$curDirectory/$curCountry-$i.txt" | awk '{ print $1 }')
			if [ $curLines -lt $lowestLines ] ; then

				lowestLines=$(($curLines))
				fileWithLeastRecords="$curDirectory/$curCountry-$i.txt"
			fi
	done

	echo $line >> $fileWithLeastRecords

done < "$INPUTFILE"

echo "Done"