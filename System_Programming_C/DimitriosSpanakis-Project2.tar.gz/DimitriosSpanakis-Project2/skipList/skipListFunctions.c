#include "skipListHeader.h"

doubleSkipList* skipListHead = NULL;
vaccineRecord* dummyVacRecord = NULL;

extern int countryCount;
extern countryNode* countryList;

void vaccineStatus(char* citID, char* virusName) {

	skipNode* res;

	if (virusName) {

		res = find_from_SkipList(virusName, citID, 1);

		if (res)
		{
			printf("VACCINATED ON %s\n", res->vacRecord->vaccineDate);
		}
		else {
			printf("NOT VACCINATED\n");
		}


	}
	else {

		doubleSkipList* curList = skipListHead;

		while (curList) {

			res = find_from_SkipList(curList->vaccineName, citID, 1);

			if (res)
			{
				printf("%s YES %s\n",curList->vaccineName, res->vacRecord->vaccineDate);
			}
			else {
				printf("%s NO\n",curList->vaccineName);
			}

			curList = curList->nextList;

		}

	}

	return;

}


int insertCitizenRecord(char* citizenID, char* firstName, char* lastName, char* country, char* age, char* virusName, char* vaccinated, char* vaccineDate) {

	if (strcmp(vaccinated, "YES") != 0 && strcmp(vaccinated, "NO") != 0) {
		printf("ERROR IN GIVEN VACCINATED STATUS\n");
		return 0;
	}

	if (atoi(age) > 120) {
		printf("ERROR IN GIVEN CITIZEN AGE |%d| (SHOULD BE AGE<=120)\n", atoi(age));
		return 0;
	}

	if (strcmp(vaccinated, "YES") == 0 && !validateDate(vaccineDate,1)) {
		return 0;
	}


	citizenRecord* findCit = find_citizen_hashTable(citizenID);

	if (findCit) {

		int valRes = validateCitizen(findCit,citizenID,firstName,lastName,country,age);
		
		if (!valRes)
			return 0;

		skipNode* curNode = find_from_SkipList(virusName, citizenID, 1);

		if (curNode)
		{
			printf("ERROR: CITIZEN %s ALREADY VACCINATED ON %s\n", curNode->vacRecord->citRecord->citizenId, curNode->vacRecord->vaccineDate);
			return 0;
		}

		curNode = find_from_SkipList(virusName, citizenID, 0);

		if (curNode != NULL && strcmp(vaccinated, "NO") == 0) {
			printf("ERROR: CITIZEN %s IS ALREADY INSERTED ON NON_VAC_LIST\n", curNode->vacRecord->citRecord->citizenId);
			return 0;
		}

		if (strcmp(vaccinated, "YES") == 0) 
		{

			if (curNode)
			{
				remove_from_skipList(virusName, citizenID, 0);
			}

			vaccineRecord* newVacRec = createVacRecord(virusName, 1, vaccineDate);
			newVacRec->citRecord = findCit;

			insert_to_SkipList(newVacRec);


			// APPEND TO BLOOM FILTER
			insert_to_BloomFilter(citizenID,virusName);

		}

	}
	else {

		citizenRecord* newCitRec = createCitRecord(citizenID, firstName, lastName, country, age);
		newCitRec = insert_citizen_hashTable(newCitRec);
		vaccineRecord* newVacRec;

		if(strcmp(vaccinated, "YES") == 0) {
			newVacRec = createVacRecord(virusName, 1, vaccineDate);

			// APPEND TO BLOOM FILTER
			insert_to_BloomFilter(citizenID,virusName);
		}
		else {
			newVacRec = createVacRecord(virusName, 0, NULL);
		}
		newVacRec->citRecord = newCitRec;

		insert_to_SkipList(newVacRec);
	}

	return 1;

}

int vaccinateNow(char* citizenID, char* firstName, char* lastName, char* country, char* age, char* virusName ) {

	if (atoi(age) > 120) {
		printf("ERROR IN GIVEN CITIZEN AGE |%d| (SHOULD BE AGE<=120)\n", atoi(age));
		return -1;
	}

	citizenRecord* findCit = find_citizen_hashTable(citizenID);

	if (findCit) {

		int valRes = validateCitizen(findCit,citizenID,firstName,lastName,country,age);
		
		if (!valRes)
			return -1;

		skipNode* curNode = find_from_SkipList(virusName, citizenID, 1);

		if (curNode)
		{
			printf("ERROR: CITIZEN %s ALREADY VACCINATED ON %s\n", curNode->vacRecord->citRecord->citizenId, curNode->vacRecord->vaccineDate);
			return -1;
		}

		curNode = find_from_SkipList(virusName, citizenID, 0);

		if (curNode)
		{
			remove_from_skipList(virusName, citizenID, 0);
		}

		vaccineRecord* newVacRec = createVacRecord(virusName, 1, NULL);
		newVacRec->citRecord = findCit;

		insert_to_SkipList(newVacRec);

		// APPEND TO BLOOM FILTER
		insert_to_BloomFilter(citizenID,virusName);

		return 0;

	}
	else {

		citizenRecord* newCitRec = createCitRecord(citizenID, firstName, lastName, country, age);
		newCitRec = insert_citizen_hashTable(newCitRec);

		vaccineRecord* newVacRec = createVacRecord(virusName, 1, NULL);
		newVacRec->citRecord = newCitRec;

		insert_to_SkipList(newVacRec);

		
		// APPEND TO BLOOM FILTER
		insert_to_BloomFilter(citizenID,virusName);

		return 1;
	}

	return -1;
}

void incrementStat(virusAgeStats* ageStruct, vaccineRecord* vacRec) {

	if (vacRec->citRecord->age < 20)
		ageStruct->stat_0_20++;
	else if (vacRec->citRecord->age < 40)
		ageStruct->stat_20_40++;
	else if (vacRec->citRecord->age < 60)
		ageStruct->stat_40_60++;
	else 
		ageStruct->stat_60plus++;

	return;
}

void popStatusByAge(char* country, char* vaccineName, char* date1, char* date2) {

	doubleSkipList* res = find_vaccineSkipList(vaccineName);

	if (!res)  {
		printf("NO RECORDS FOR VIRUS |%s|\n", vaccineName);
		return;
	}

	if (!country) {

		countryNode* curNode = countryList;

		while(curNode) {

			popStatusByAge(curNode->countryName,vaccineName,date1,date2);
			curNode = curNode->nextCountry;

			printf("\n");

		}

	}

	else {

		printf("%s\n", country);

		char* findCountry = search_insert_Country(country, 0);
		if (!findCountry)
		{
			printf("NO RECORDS FOR COUNTRY %s\n", country);
			return;
		}

		virusAgeStats vacStats;
		vacStats.stat_0_20 = 0;
		vacStats.stat_20_40 = 0;
		vacStats.stat_40_60 = 0;
		vacStats.stat_60plus = 0;

		virusAgeStats non_vacStats;
		non_vacStats.stat_0_20 = 0;
		non_vacStats.stat_20_40 = 0;
		non_vacStats.stat_40_60 = 0;
		non_vacStats.stat_60plus = 0;

		skipNode* curRec;
		if (!res->vaccinatedSkipList->head)
		{
			printf("(NOTE: VACCINATED SKIP LIST HAS NO ENTRIES)\n");
			curRec = NULL;
		}
		else 
			curRec = res->vaccinatedSkipList->head->nextNode;

		while (curRec) {

			if (strcmp(curRec->vacRecord->citRecord->country, country) == 0) {

				if (date1 == NULL && date2 == NULL) {
					incrementStat(&vacStats, curRec->vacRecord);

				}
				else {
					if (compareDate(date1, curRec->vacRecord->vaccineDate) > 0 && compareDate(curRec->vacRecord->vaccineDate, date2) > 0)
						incrementStat(&vacStats, curRec->vacRecord);
					else
						incrementStat(&non_vacStats, curRec->vacRecord);
				}
					
			}

			curRec = curRec->nextNode;
		}

		if (!res->non_vaccinatedSkipList->head)
		{
			printf("(NOTE: NON_VACCINATED SKIP LIST HAS NO ENTRIES)\n");
			curRec = NULL;
		}
		else
			curRec = res->non_vaccinatedSkipList->head->nextNode;

		while (curRec) {

			if (strcmp(curRec->vacRecord->citRecord->country, country) == 0) {
				incrementStat(&non_vacStats, curRec->vacRecord);
			}

			curRec = curRec->nextNode;
		}

		int cit0_20Count =  vacStats.stat_0_20 + non_vacStats.stat_0_20;
		int cit20_40Count  = vacStats.stat_20_40 + non_vacStats.stat_20_40;
		int cit40_60Count =  vacStats.stat_40_60 + non_vacStats.stat_40_60;
		int cit60PlusCount  = vacStats.stat_60plus + non_vacStats.stat_60plus;

		char rate = '%';

		double rateVal = 0.0;

		if (!cit0_20Count)
			rateVal = 0;
		else
			rateVal = (double) vacStats.stat_0_20*100 / (double) cit0_20Count;
		printf("0-20 %d %.2f %c (%d OUT OF %d)\n", vacStats.stat_0_20 , rateVal, rate, vacStats.stat_0_20, cit0_20Count);
		
		if (!cit20_40Count)
			rateVal = 0;
		else
			rateVal = (double) vacStats.stat_20_40*100 / (double) cit20_40Count;
		printf("20-40 %d %.2f %c (%d OUT OF %d)\n", vacStats.stat_20_40 , rateVal, rate, vacStats.stat_20_40, cit20_40Count);
		

		if (!cit40_60Count)
			rateVal = 0;
		else
			rateVal = (double) vacStats.stat_40_60*100 / (double) cit40_60Count;
		printf("40-60 %d %.2f %c (%d OUT OF %d)\n", vacStats.stat_40_60 , rateVal, rate, vacStats.stat_40_60, cit40_60Count);
		
		
		if (!cit60PlusCount)
			rateVal = 0;
		else
			rateVal = (double) vacStats.stat_60plus*100 / (double) cit60PlusCount;
		printf("60+ %d %.2f %c (%d OUT OF %d)\n", vacStats.stat_60plus , rateVal, rate, vacStats.stat_60plus, cit60PlusCount);
	}



}

void populationStatus(char* country, char* vaccineName, char* date1, char* date2) {

	doubleSkipList* res = find_vaccineSkipList(vaccineName);

	if (!res) {
		printf("NO RECORDS FOR VIRUS |%s|\n", vaccineName);
		return;
	}

	if (!country) {

		countryNode* curNode = countryList;

		while(curNode) {

			populationStatus(curNode->countryName,vaccineName,date1,date2);
			curNode = curNode->nextCountry;
			printf("\n");
		}

	}

	else {

		char* findCountry = search_insert_Country(country, 0);
		if (!findCountry)
		{
			printf("NO RECORDS FOR COUNTRY %s\n", country);
			return;
		}

		virusPopulationStats curStats;
		curStats.vaccinatedCount = 0;
		curStats.non_vaccinatedCount = 0;

		skipNode* curRec;
		if (!res->vaccinatedSkipList->head)
		{
			printf("(NOTE: VACCINATED SKIP LIST FOR |%s| HAS NO ENTRIES)\n", country);
			curRec = NULL;
		}
		else
			curRec = res->vaccinatedSkipList->head->nextNode;

		while (curRec) {

			if (strcmp(curRec->vacRecord->citRecord->country, country) == 0) {

				if (date1 == NULL && date2 == NULL) {
					
					curStats.vaccinatedCount++;

				}
				else {
					if (compareDate(date1, curRec->vacRecord->vaccineDate) > 0 && compareDate(curRec->vacRecord->vaccineDate, date2) > 0)
						curStats.vaccinatedCount++;
					else
						// Use non vac to increment population
						curStats.non_vaccinatedCount++;
				}
					
			}

			curRec = curRec->nextNode;
		}

		if (!res->non_vaccinatedSkipList->head)
		{
			printf("(NOTE: NON_VACCINATED SKIP LIST FOR |%s| HAS NO ENTRIES)\n", country);
			curRec = NULL;
		}
		else
			curRec = res->non_vaccinatedSkipList->head->nextNode;

		while (curRec) {

			if (strcmp(curRec->vacRecord->citRecord->country, country) == 0) {
				curStats.non_vaccinatedCount++;
			}

			curRec = curRec->nextNode;
		}

		int population = curStats.vaccinatedCount + curStats.non_vaccinatedCount;
		
		double rateVal = 0.0;
		if (!population)
			rateVal = 0;
		else
			rateVal = (double)(curStats.vaccinatedCount*100)/population;

		char rate = '%';
		printf("%s %d %.2f%c (%d OUT OF %d)\n", country ,curStats.vaccinatedCount,  rateVal,rate, curStats.vaccinatedCount, population);

	}

}

void list_nonVaccinated_Persons(char* virusName) {

	doubleSkipList* res = find_vaccineSkipList(virusName);

	if (!res) {
		printf("|ERROR|: VIRUSNAME DOES NOT EXIST IN RECORDS\n");
		return;
	}

	skipNode* curNode = res->non_vaccinatedSkipList->head;

	if (!curNode) {
		printf("|ERROR|: NON VACCINATED LIST FOR VIRUS NOT INITIALISED\n");
		return;
	}

	curNode = curNode->nextNode;
	citizenRecord* curRec;

	if (!curNode) {
		printf("NON VACCINATED SKIP LIST IS EMPTY\n");
		return;
	}

	while(curNode) {

		curRec = curNode->vacRecord->citRecord;
		printf("%s %s %s %s %d\n", curRec->citizenId, curRec->firstName, curRec->lastName, curRec->country, curRec->age);

		curNode = curNode->nextNode;
	}

	return;

}

int flipCoin() {

	return rand() % 2;

}


void double_skipListInit(char* vaccineName, doubleSkipList* curDoubleList) {

	curDoubleList->vaccineName = malloc((strlen(vaccineName) + 1) * sizeof(char));
	strcpy(curDoubleList->vaccineName, vaccineName);

	curDoubleList->vaccinatedSkipList = malloc(sizeof(skipList));
	curDoubleList->vaccinatedSkipList->head = NULL;

	curDoubleList->non_vaccinatedSkipList = malloc(sizeof(skipList));
	curDoubleList->non_vaccinatedSkipList->head = NULL;

	curDoubleList->nextList = NULL;

}

doubleSkipList* insert_vaccineSkipList(char* vaccineName) {

	if (skipListHead == NULL) {

		skipListHead = malloc(sizeof(doubleSkipList));
		double_skipListInit(vaccineName, skipListHead);

		return skipListHead;

	}

	doubleSkipList* prevSkipList = NULL;
	doubleSkipList* curSkipList = skipListHead;

	while (curSkipList != NULL) {

		if (strcmp(curSkipList->vaccineName, vaccineName) == 0) {

			return curSkipList;

		}
		prevSkipList = curSkipList;
		curSkipList = curSkipList->nextList;

	}

	prevSkipList->nextList = malloc(sizeof(doubleSkipList));
	double_skipListInit(vaccineName, prevSkipList->nextList);

	return prevSkipList->nextList;
}

doubleSkipList* find_vaccineSkipList(char* vaccineName) {

	doubleSkipList* curSkipList = skipListHead;

	while (curSkipList != NULL) {

		if (strcmp(curSkipList->vaccineName, vaccineName) == 0) {

			return curSkipList;

		}
		curSkipList = curSkipList->nextList;

	}

	return NULL;
}

skipNode* createDummyNode() {

	skipNode* dummyNode = malloc(sizeof(skipNode));
	dummyNode->prevLevel = NULL;
	dummyNode->nextLevel = NULL;
	dummyNode->nextNode = NULL;

	if (dummyVacRecord == NULL) {

		dummyVacRecord = malloc(sizeof(vaccineRecord));

		dummyVacRecord->vaccineName=NULL;
		dummyVacRecord->citRecord = calloc(1,sizeof(citizenRecord));
		dummyVacRecord->citRecord->citizenId = malloc(4*sizeof(char));

		strcpy(dummyVacRecord->citRecord->citizenId, "000");

	}

	dummyNode->vacRecord = dummyVacRecord;

	return dummyNode;
}

//int maxLevel = 2;
void addToNextLevel(skipList* list, skipNode* curLevel, skipNode* newNode,  vaccineRecord* vacRecord) {

	if (flipCoin())
		return;
	// maxLevel--;

	// if (maxLevel == 0)
	// {
	// 	maxLevel = 2;
	// 	return;
	// }

	if (curLevel->nextLevel == NULL) {

		list->levels++;

		curLevel->nextLevel = createDummyNode(); 
		
		curLevel->nextLevel->prevLevel = curLevel;

	}

	skipNode* nextLevelPrevNode = curLevel->nextLevel;
	skipNode* nextLevelCurNode = curLevel->nextLevel->nextNode;

	skipNode* newLevelNode = malloc(sizeof(skipNode));
	newLevelNode->nextLevel = NULL;
	newLevelNode->vacRecord = vacRecord;

	newNode->nextLevel = newLevelNode;
	newLevelNode->prevLevel = newNode;
	
	while (nextLevelCurNode != NULL) {

		if (atoi(nextLevelCurNode->vacRecord->citRecord->citizenId) > atoi(vacRecord->citRecord->citizenId)) {
			break;
		}
		nextLevelPrevNode = nextLevelCurNode;
		nextLevelCurNode = nextLevelCurNode->nextNode;
	}


	nextLevelPrevNode->nextNode = newLevelNode;
	newLevelNode->nextNode = nextLevelCurNode;

	newNode->nextLevel = newLevelNode;
	newLevelNode->prevLevel = newNode;
	

	addToNextLevel(list, curLevel->nextLevel, newLevelNode, vacRecord);



}

int insert_to_SkipList(vaccineRecord* vacRecord) {


	int mode;
	if (vacRecord->vaccinated) {
		mode = 1;
	}
	else {
		mode = 0;
	}

	doubleSkipList* vacSkipList = insert_vaccineSkipList(vacRecord->vaccineName);

	skipList* curList;

	if (mode) {
		curList = vacSkipList->vaccinatedSkipList;
	}
	else {
		curList = vacSkipList->non_vaccinatedSkipList;
	}

	if (curList->head == NULL) {

		curList->head = createDummyNode();

	}

	skipNode* prevNode = curList->head;
	skipNode* curNode = curList->head->nextNode;

	while (curNode) {

		if (atoi(curNode->vacRecord->citRecord->citizenId) == atoi(vacRecord->citRecord->citizenId))
			return 1;

		if (atoi(curNode->vacRecord->citRecord->citizenId) > atoi(vacRecord->citRecord->citizenId))
			break;

		prevNode = curNode;
		curNode = curNode->nextNode;
	}

	skipNode* newNode = malloc(sizeof(skipNode));
	newNode->vacRecord = vacRecord;

	newNode->prevLevel = NULL;
	newNode->nextLevel = NULL;
	newNode->nextNode = NULL;

	
	prevNode->nextNode = newNode;
	newNode->nextNode = curNode;

	addToNextLevel(curList,  curList->head, newNode, vacRecord);

	return 1;

}

// Finds if a record exists for id, mode = 1 -> vaccinatedList, mode = 2 -> non_vaccinatedList
skipNode* find_from_SkipList(char* vaccineName,char* citID, int mode) {

	doubleSkipList* vacSkipList = find_vaccineSkipList(vaccineName);

	skipList* curList;

	if (vacSkipList == NULL)
		return NULL;

	if (mode) {
		curList = vacSkipList->vaccinatedSkipList;
	}
	else {
		curList = vacSkipList->non_vaccinatedSkipList;
	}

	if (curList->head == NULL)
		return NULL;

	skipNode* prevLevel = NULL;
	skipNode* curLevel = curList->head;

	while (curLevel) {

		prevLevel = curLevel;
		curLevel = curLevel->nextLevel;

	}

	curLevel = prevLevel;

	skipNode* prevNode;
	skipNode* curNode;

	int flag = 0;
	while(curLevel) {

		flag = 0;
		prevNode = curLevel;
		curNode = curLevel->nextNode;

		while(curNode) {

			if (strcmp(curNode->vacRecord->citRecord->citizenId, citID) == 0) {
				return curNode;
			}

			if (atoi(curNode->vacRecord->citRecord->citizenId) > atoi(citID)) {

				if (strcmp(curNode->vacRecord->citRecord->citizenId, citID)) {

					flag = 1;
					break;

				}

			}


			prevNode = curNode;
			curNode = curNode->nextNode;

		}

		if (flag) {

			curLevel = prevNode->prevLevel;
			continue;
			
		}

		curLevel = curLevel->prevLevel;

	}


	return NULL;

}

// This function removes from a skipList, used by VaccinateNow
int remove_from_skipList(char* vaccineName,char* citID, int mode) {

	doubleSkipList* vacSkipList = find_vaccineSkipList(vaccineName);

	skipList* curList;

	if (vacSkipList == NULL)
		return 0;

	if (mode) {
		curList = vacSkipList->vaccinatedSkipList;
	}
	else {
		curList = vacSkipList->non_vaccinatedSkipList;
	}

	skipNode* prevLevel = NULL;
	skipNode* curLevel = curList->head;

	while (curLevel) {

		prevLevel = curLevel;
		curLevel = curLevel->nextLevel;

	}

	curLevel = prevLevel;

	skipNode* prevNode;
	skipNode* curNode;

	int flag;
	while (curLevel != NULL) {

		prevNode = curLevel;
		curNode = curLevel->nextNode;

		flag = 0;
		while (curNode != NULL) {

			if (atoi(curNode->vacRecord->citRecord->citizenId) > atoi(citID)) {
				if (strcmp(curNode->vacRecord->citRecord->citizenId, citID)) {

					flag = 1;
					break;


				}
			}
				

			if (strcmp(curNode->vacRecord->citRecord->citizenId,citID) == 0) {

				prevNode->nextNode = curNode->nextNode;

				if (curNode->prevLevel == NULL) {
						free(curNode->vacRecord->vaccineName);
						free(curNode->vacRecord->vaccineDate);
						free(curNode->vacRecord);
						free(curNode);
						return 1;
				}

				free(curNode);
				
				break;

			}

			prevNode = curNode;
			curNode = curNode->nextNode;
		}

		if (flag) {
			if (prevNode) {

				prevLevel = prevNode;
				curLevel = prevNode->prevLevel;
				continue;
			}

		}


		prevLevel = curLevel;
		curLevel = curLevel->prevLevel;


	}
	

	return 0;
}

// Prints skipList, used for debugging
void printSkipList(char* vacName) {

	doubleSkipList* curlist = find_vaccineSkipList(vacName);

	if (curlist == NULL) {
		printf("NOTHING TO PRINT\n");
		return;
	}


	skipNode* curLevel = curlist->vaccinatedSkipList->head;
	skipNode* curNode = NULL;
	while (curLevel) {

		curNode = curLevel;
		while(curNode) {

			printf("%s->",curNode->vacRecord->citRecord->citizenId);
			curNode = curNode->nextNode;

		}
		printf("\n");

		curLevel = curLevel->nextLevel;
	}

}

void freeSkipNode(skipNode* curSkipNode) {

	if (curSkipNode->nextLevel == NULL) {


			free(curSkipNode->vacRecord->vaccineName);

			free(curSkipNode->vacRecord->vaccineDate);
		
			free(curSkipNode->vacRecord);

	}
	free(curSkipNode);

	return;
}

void freeSkipList(skipList* list) {

	skipNode* prevLevel = NULL;
	skipNode* curLevel = list->head;
	
	skipNode* prevNode = NULL;
	skipNode* curNode = NULL;

	while (curLevel) {

		curNode = curLevel->nextNode;

		while (curNode)
		{
			prevNode = curNode;
			curNode = curNode->nextNode;

			freeSkipNode(prevNode);

		}

		prevLevel = curLevel;
		curLevel = curLevel->nextLevel;

		//freeSkipNode(prevLevel);
		//printf("=>%s\n", prevLevel->vacRecord->citRecord->citizenId);
		if (prevLevel)
			free(prevLevel);

	}


}

void freeDoubleSkipList() {

	doubleSkipList* prevDoubleList = NULL;
	doubleSkipList* curDoubleList = skipListHead;

	while (curDoubleList) {

		prevDoubleList = curDoubleList;
		curDoubleList = curDoubleList->nextList;

		
		freeSkipList(prevDoubleList->vaccinatedSkipList);
		freeSkipList(prevDoubleList->non_vaccinatedSkipList);
		

		free(prevDoubleList->vaccineName);
		free(prevDoubleList->vaccinatedSkipList);
		free(prevDoubleList->non_vaccinatedSkipList);

		free(prevDoubleList);

	}

	if (!dummyVacRecord)
		return;

	if (dummyVacRecord->citRecord->citizenId)
		free(dummyVacRecord->citRecord->citizenId);
	if (dummyVacRecord->citRecord)
		free(dummyVacRecord->citRecord);
	if (dummyVacRecord)
		free(dummyVacRecord);


	return;


}