#include "../mainStructs.h"
#include "../bloomFiltering/bloomFilterHeader.h"
#define SKIPLIST_MAX_LEVEL 10

typedef struct skipNode {

	int id;
	vaccineRecord* vacRecord;

	struct skipNode* prevLevel;
	struct skipNode* nextLevel;
	
	struct skipNode* nextNode;

} skipNode;

typedef struct skipList {

	struct skipNode* head;
	int levels;
	int size;
	
} skipList;

typedef struct doubleSkipList {

	char* vaccineName;

	skipList* vaccinatedSkipList;
	skipList* non_vaccinatedSkipList;

	struct doubleSkipList* nextList;

} doubleSkipList;


int flipCoin();

void vaccineStatus(char* , char* );
int vaccinateNow(char* , char* , char* , char* , char* , char*  );
int insertCitizenRecord(char* , char* , char* , char* , char* , char* , char* , char* );
void populationStatus(char* , char* , char* , char* );
void popStatusByAge(char* , char* , char* , char* );
void list_nonVaccinated_Persons(char* );

doubleSkipList* insert_vaccineSkipList(char* );
doubleSkipList* find_vaccineSkipList(char* );

int insert_to_SkipList(vaccineRecord* vacRecord);
skipNode* find_from_SkipList(char* ,char*  , int);
int remove_from_skipList(char* ,char* , int );

void printSkipList(char* );
void freeDoubleSkipList();
void freeSkipNode(skipNode* );

citizenRecord* createCitRecord(char* , char* , char* , char* , char* );
vaccineRecord* createVacRecord(char* , int , char* );
int validateCitizen(citizenRecord* ,char* , char* , char* , char* , char* );