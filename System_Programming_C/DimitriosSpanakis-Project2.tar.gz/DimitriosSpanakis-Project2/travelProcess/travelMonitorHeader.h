#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/wait.h>
#include <errno.h>
#include <poll.h>
#include <signal.h>
#include "../bloomFiltering/bloomFilterHeader.h"
#include "../mainStructs.h"

enum bloomReadState{Virus, Zero, Bloom, Completed, Results};

// BloomReadState struct holds states of reading of bloomFilters by monitors
typedef struct bloomFilterReadState {

	enum bloomReadState state; // 0 -> Read Virus , 1 ->Read \0, 2->Read Bloom, 3->Completed
	int index;
	bloomFilter* curBloomFilter;
	char virusName[64]; // Max 63 Chars

} bloomFilterReadState;

// Keeps travel request "screenshot"
typedef struct travelRequestNode {

	char* date;
	int accepted;
	struct travelRequestNode* nextRequest;

}travelRequestNode;

// Holds travel requests by virus
typedef struct travelVirusNode {

	char* virusName;
	travelRequestNode* requestHead;
	struct travelVirusNode* nextNode;

} travelVirusNode;

// Holds travel requests by country
typedef struct countryStatNode {

	char* countryName;
	struct countryStatNode* nextCountry;

	travelVirusNode* travelVirusHead;

} countryStatNode;

// Keeps all info needed and hosts a buffer for each monitor
typedef struct monitorInfo {

	int pid;
	char* readPipeName;
	int fdRead;
	char* writePipeName;
	int fdWrite;

	char* buffer;
	int bufferIdx;

	countryStatNode* countryListHead;
	bloomFilter* bloomFilterHead;

} monitorInfo;


int checkDirectoryExists(char* );

void initialiseTravelMonitor(int , char** );
void initialiseMonitorArray();
void forkExecMonitors();
void openAllNamedPipes();

void sendStringBuffer(int , char* , int );
void sendStringBufferRemainings(int );

void sentMonitorRequest(int, char*);
char* receiveMonitorString(int );

void sendInputData();
void sendInputData_specific(int );

void sendWorkLoad();

void readBloomFilters();
void readBloomFilter(int );

// Functions that handle countries
int checkCountryExists(char* );
monitorInfo* search_or_append_Country(monitorInfo* , char* , int );

int userInputReader();

void travelRequest(char* , char* , char* , char* ,char* , char* );

void travelStats(char* , char* , char* , char* );
void append_TravelStats(char* , char* , char* , int );
void append_TravelRequest (travelVirusNode*, char*, int);

void searchVaccinationStatus(char* , char* );
void pollVaccinationStatusResults();

void addVaccinationRecords(char* );

void sigFatherDeathHandler(int );

// Below are the functions that help with handling child's death
void sigChildDeathHandler(int );
void resurrect_Child(int );
void resurrect_reBufferCountries_andReceiveBlooms(int );

void logFatherStats();
void freeTravelRequestNode(travelRequestNode* );
void freeTravelVirusNode(travelVirusNode* );
void freeCountryStatNode_specific(countryStatNode* );

// Rest of frees happen on sigFatherDeathHandler function

void queueUpcomingSignals();
void unblockSignals();

// Can be found in travelMonitor.c
void executeSignalsCaught();