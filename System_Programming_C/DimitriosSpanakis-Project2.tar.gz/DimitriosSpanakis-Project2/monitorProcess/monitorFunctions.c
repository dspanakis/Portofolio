#include "./monitorHeader.h"

// extern vars for citizen record hashTable
extern citizenHashTableNode** citizenHashTable;

// extern vars from BloomFiltering
extern int bloomFilterByteSize;
extern bloomFilter* bloomFilterList;
extern int bloomFilterCount; 
 
//extern vars from SkipList
extern doubleSkipList* skipListHead;

char* inputDir = NULL;
int bufferSize = 0;
char* buffer = NULL;
int bufferIdx = 0;

int fdRead;
int fdWrite;

int pid;

int totalTravelRequests = 0;
int acceptedTravelRequests = 0;

directoryReadNode* directoriesReadListHead = NULL;
int sigIntQuitCaught = 0;
int sigUSR1Count = 0;


int file_exists (char *filename) {
  struct stat  buffer;   
  return (stat (filename, &buffer) == 0);
}

int isDirectory(char *path) {
   struct stat statbuf;
   if (stat(path, &statbuf) != 0)
       return 0;
   return S_ISDIR(statbuf.st_mode);
}


fileReadNode* findFile(directoryReadNode* curCountryDir, char* d_name) {

	if (!curCountryDir->fileReadNodeHead) {
		return NULL;
	}

	fileReadNode* curFile = curCountryDir->fileReadNodeHead;
	while(curFile) {

		if (strcmp(curFile->path, d_name) == 0) {
			return curFile;
		}

		curFile = curFile->nextFile;
	}

	return NULL;
}

void appendWorkingDir(char* path) {

	if (!directoriesReadListHead) {
		directoriesReadListHead = malloc(sizeof(directoryReadNode));
		directoriesReadListHead->fileReadNodeHead = NULL;
		directoriesReadListHead->nextDirectory = NULL;

		directoriesReadListHead->path = malloc((strlen(path) + 1) * sizeof(char));
		directoriesReadListHead->path[0] = 0;

		strcpy(directoriesReadListHead->path, path);

		return;
	}

	directoryReadNode* newNode = calloc(1,sizeof(directoryReadNode));
	newNode->fileReadNodeHead = NULL;
	newNode->nextDirectory = NULL;

	newNode->path = malloc((strlen(path) + 1) * sizeof(char));
	newNode->path[0] = 0;
	strcpy(newNode->path, path);

	newNode->nextDirectory = directoriesReadListHead;
	directoriesReadListHead = newNode;

}

void appendWorkingFile(directoryReadNode* curDir, char* path) {

	if (!curDir->fileReadNodeHead) {
		curDir->fileReadNodeHead = malloc(sizeof(fileReadNode));
		curDir->fileReadNodeHead->nextFile = NULL;

		curDir->fileReadNodeHead->path = malloc((strlen(path) + 1) * sizeof(char));
		curDir->fileReadNodeHead->path[0] = 0;

		strcpy(curDir->fileReadNodeHead->path, path);

		return;
	}

	fileReadNode* newNode = malloc(sizeof(fileReadNode));
	newNode->nextFile = NULL;
	newNode->path = malloc((strlen(path) + 1) * sizeof(char));
	newNode->path[0] = 0;
	strcpy(newNode->path, path);

	newNode->nextFile = curDir->fileReadNodeHead;

	curDir->fileReadNodeHead = newNode;

	return;

}

void appendFileToStructs (char* fileName) {

	citizenRecord* newCitRec;
    vaccineRecord* newVacRec;

	int validRecords = 0;
	FILE *fp;
	fp = fopen(fileName,"r");

	if(fp == NULL)
	{
		printf("ERROR OPENING FILE: %s\n", fileName); //If we give not existing txt for read
		exit(1);
	}

	char line[512];
	char checkBuf[52];

	char citizenID[32];
	char firstName[32];
	char lastName[32];
	char country[32];
	char age[32];
	char vaccineType[32];
	char vaccinatedStr[32];
	int vaccinated;
	char vaccineDate[32];
	vaccineDate[0] = '\0';
	int argCount = 0;

	while (fgets(line, sizeof(line), fp)) {
        

        if (strcmp(line, "\n") == 0)
        	continue;

		
		argCount = sscanf(line,"%s %s %s %s %s %s %s %s %s", citizenID, firstName, lastName, country, age, vaccineType, vaccinatedStr, vaccineDate, checkBuf);
		// readRecords++;

		// VALIDATION TAKES PLACE
		if (argCount < 7 || argCount > 8) {
			printf("ERROR IN RECORD %s", line);
			continue;
		}

		if (strcmp(vaccinatedStr, "YES") != 0 && strcmp(vaccinatedStr, "NO") != 0) {
			printf("ERROR IN RECORD %s", line);
			continue;
		}

	    if (strcmp(vaccinatedStr, "YES") == 0)
			vaccinated = 1;
		else if (strcmp(vaccinatedStr, "NO") == 0) {
			vaccinated = 0;
		}
		else
			vaccinated = 3;

		if (argCount > 7 && vaccinated == 0) {
			printf("ERROR IN RECORD %s", line);
			continue;
		}
		else if (vaccinated == 1) {

			if (!validateDate(vaccineDate,0)) {
				printf("ERROR IN RECORD %s", line);
				continue;
			}

		}

		if (atoi(age) > 120) {
			printf("ERROR IN RECORD %s", line);
			continue;
		}

				// SEARCH IF WE HAVE ALREADY RECORED THIS CITIZEN
		citizenRecord* findCit = find_citizen_hashTable(citizenID);
		if (findCit) {

			// Validate citizen ("mainFunctions.c")
			int valRes = validateCitizen(findCit,citizenID,firstName,lastName,country,age);
			
			// If citizen info is changed, print error and continue
			if (!valRes) {
				printf("GIVEN RECORD WAS %s\n", line);
				continue;
			}

			// Check if we already inserted this citizen, in the vaccine list specified
			if(find_from_SkipList(vaccineType,citizenID, 1) != NULL || find_from_SkipList(vaccineType,citizenID, 0) != NULL) {
				line[strlen(line) - 1] = '\0';
				printf("ERROR IN RECORD %s : ALREADY EXISTS IN %s SKIPLIST\n", line, vaccineType);
				continue;
			}
			else {

				// Else create new vac record, keeping the same citizen info pointer (save some space)
				newVacRec = createVacRecord(vaccineType, vaccinated, vaccineDate);
				newVacRec->citRecord = findCit;
				insert_to_SkipList(newVacRec);
				validRecords++;

				if (vaccinated)	// APPEND TO BLOOM FILTER
					insert_to_BloomFilter(citizenID,vaccineType);

				continue;

			}

		}
		else {

			// Else create new vac and new cit record and insert to list
			newCitRec = createCitRecord(citizenID, firstName, lastName, country,  age);
			insert_citizen_hashTable(newCitRec);

			newVacRec = createVacRecord(vaccineType, vaccinated, vaccineDate);

			newVacRec->citRecord = newCitRec;
			insert_to_SkipList(newVacRec);
			validRecords++;

	    	if (vaccinated)	// APPEND TO BLOOM FILTER
				insert_to_BloomFilter(citizenID,vaccineType);

		}

	    
    }

    fclose(fp);

	return;
}

int checkForDirFilesChanges(directoryReadNode* curCountryDir) {

	char tempPath[512];
	tempPath[0] = 0;
	strcpy(tempPath, inputDir);
	if (tempPath[strlen(tempPath) - 1] != '/');
		strcat(tempPath, "/");
	strcat(tempPath, curCountryDir->path);

    DIR *dp;
    struct dirent* countryDir;
    struct stat dirCheck;

    if ((dp=opendir(tempPath))== NULL ) {
        perror("opendir"); return -1;
    }
    int checkFlag = 0;

    while ((countryDir = readdir(dp)) != NULL ) {

		if (strcmp(countryDir->d_name, ".") == 0 || strcmp(countryDir->d_name, "..") == 0)
			continue;

        // if (strcmp(dirSrc->d_name, countryDir->d_name) == 0) {

        // 	continue;

        // }

        fileReadNode* curFile = findFile(curCountryDir, countryDir->d_name);
       

        if (curFile)
        	continue;

        char filePath[512];
        filePath[0] = 0;

        strcpy(filePath, tempPath);
		strcat(filePath, "/");
		strcat(filePath, countryDir->d_name);

		printf("NEW FILE FOUND |%s|\n\n", filePath);

        appendWorkingFile(curCountryDir , countryDir->d_name);
        appendFileToStructs(filePath);

        checkFlag = 1;

    }
    
    closedir(dp);
    return checkFlag;

}

int checkAllDirsForChanges() {
	directoryReadNode* curDir = directoriesReadListHead;
	int newRecordsBool = 0;
	int newChanges = 0;
	while(curDir) {
		newChanges = checkForDirFilesChanges(curDir);
		if (!newRecordsBool)
			if(newChanges)
				newRecordsBool = 1;

		curDir = curDir->nextDirectory;
	}

	return newRecordsBool;
}

void read_save_country_directories_from_pipe() {

	// char* countryDirsStr = receiveMonitorString();

	buffer[0] = 0;

	struct pollfd fds[1];
	int timeout_msecs = 1000;
	int ret;

	char countryDir[64];
	int countryDirIdx = 0;
	fds[0].fd = fdRead;
	fds[0].events = POLLIN;
	int termFlag = 0;
	while (1)
	{
		ret = poll(fds, 1, timeout_msecs);
		// printf("ret is %d\n", ret);
		if (ret == -1 || ret == 0) {
			continue;
		}

		if((fds[0].revents&POLLIN) == POLLIN) {
			int bytesRead = read(fdRead, buffer, bufferSize*sizeof(char));
			// printf("BytesRead = %d \n", bytesRead);
			if (bytesRead == -1 || bytesRead == 0)
				continue;

			char* bufferPtr = buffer;

			int bytesConsumed = 0;
			while (bytesConsumed < bytesRead) {

				// printf("Char - %c ASCII - %d\n", *bufferPtr, *bufferPtr);
				if (*bufferPtr == '~')
				{
					termFlag = 1;
					break;
				}

				else if (*bufferPtr == ' ')
				{

					countryDir[countryDirIdx] = 0;
					appendWorkingDir(countryDir);
					countryDirIdx = -1;

				}
				else {

					countryDir[countryDirIdx] = *bufferPtr;

				}


				countryDirIdx++;
				bufferPtr++;
				bytesConsumed++;
			}

			if (termFlag)
				return;


		}
	}

	buffer[0] = 0;
	// printf("DONEEEEE\n");
	// char* token;

	// token = strtok(countryDirsStr, " ");
	// while (token != NULL) {

	// 	appendWorkingDir(token);

	// 	token = strtok(NULL, " ");
	// }


	// free(countryDirsStr);
 
}

void fill_data_structs_from_directories() {
	DIR *dp = NULL;
	struct dirent *dptr = NULL;

	char curWorkDir[256];
	char curWorkFile[256];
	curWorkDir[0] = 0;

	directoryReadNode* curDir = directoriesReadListHead;
	while (curDir) {

		strcpy(curWorkDir,inputDir);
		strcat(curWorkDir,"/");
		strcat(curWorkDir,curDir->path);

       	if (isDirectory(curWorkDir)) {

	   		if ((dp=opendir(curWorkDir))) {

	   			while ((dptr = readdir(dp)) != NULL ) {

					if (strcmp(dptr->d_name, ".") == 0 || strcmp(dptr->d_name, "..") == 0)
						continue;

					appendWorkingFile(curDir, dptr->d_name);

					strcpy(curWorkFile, curWorkDir);
					strcat(curWorkFile, "/");
					strcat(curWorkFile, dptr->d_name);

			       	appendFileToStructs(curWorkFile);

				}


	   		}   

       	}
		curDir = curDir->nextDirectory;
	}
}

// --- Send Bloom Filter Functions Start ---
// The below two buffering functions are used to buffer any char stream!!
void sendBloomFilterBuffer(char* charBuffer, int charBufferSize) {

	int charBufferIdx = 0;

	// foreach char in buffer
	while (charBufferIdx < charBufferSize) {

		// if char buffer > internal transmission buffer
		if (bufferSize - bufferIdx > charBufferSize - charBufferIdx) {
			// copy to internal transmission buffer
			int charsToCopy = charBufferSize - charBufferIdx; 
			memcpy(buffer + bufferIdx, charBuffer + charBufferIdx, charsToCopy * sizeof(char));
			// charBufferIdx += charsToCopy; -- not needed due to return (function complered and exits)
			bufferIdx += charsToCopy;
			return;

		}
		else {
			// copy to internal transmission buffer
			int charsToCopy = bufferSize - bufferIdx; 
			memcpy(buffer + bufferIdx, charBuffer + charBufferIdx, charsToCopy * sizeof(char));
			// send internal transmission buffer
			int bytesWritten = 0;
			while (bytesWritten < bufferSize) {
				int n = write(fdWrite, buffer + bytesWritten, (bufferSize-bytesWritten) * sizeof(char));
				if(n != -1)
					bytesWritten += n;
			}
			// printf("Bytes written %d\n", bytesWritten);
			charBufferIdx += charsToCopy;
			if (bytesWritten != bufferSize) {
				printf("WRITTEN LESS THAN EXPECTED!!\n");
			}
			// reset (reuse) internal transmission buffer
			bufferIdx = 0;
		}
	}
}

void sendBloomFilterBufferRemainings() {
	if (bufferIdx) {
		int bytesWritten = 0;
		while (bytesWritten < bufferIdx) {
			int n = write(fdWrite, buffer + bytesWritten, (bufferIdx-bytesWritten) * sizeof(char));
			if(n != -1)
				bytesWritten += n;
		}
		// printf("Bytes written %d\n", bytesWritten);
	}
}

//
void sendBloomFilterBuffered(bloomFilter* curBloom) {

	// bloomFilterSendSize the total bytes (characters) to be send
	int bloomFilterSendSize = (strlen(curBloom->vaccineName) + 1) + bloomFilterByteSize;

	// bloomFilterSendBuffer contains all bloom filter data to be send
	char* bloomFilterSendBuffer = calloc(bloomFilterSendSize, sizeof(char));
	
	// copy in bloomFilterSendBuffer Vaccine Name
	strcpy(bloomFilterSendBuffer, curBloom->vaccineName);

	// append in bloomFilterSendBuffer Bit Array
	memcpy(bloomFilterSendBuffer + strlen(curBloom->vaccineName) + 1, curBloom->bitArray, bloomFilterByteSize*sizeof(char));

	// sends bloom filter data in smaller pieces
	sendBloomFilterBuffer(bloomFilterSendBuffer, bloomFilterSendSize);

	// free message sent
	free(bloomFilterSendBuffer);
}

void sendBloomFilters() {

	bufferIdx = 0;
	buffer[0] = 0;
	bloomFilter* curBloom = bloomFilterList;

	// foreach bloom filter (linked list)
	while (curBloom) {
		// printf("SENDING %s BLOOM\n",curBloom->vaccineName);
		sendBloomFilterBuffered(curBloom);
		curBloom = curBloom->nextBloomFilter;
	}
	char* ending = "~";
	sendBloomFilterBuffer(ending, 1);
	sendBloomFilterBufferRemainings();


}
// --- Send Bloom Filter Functions End ---


char* receiveMonitorString_Extended() {

	buffer[0] = 0;
	char* messageString = malloc(bufferSize*sizeof(char));
	long int messageTotalSize = bufferSize;
	long int messageIdx = 0;

	struct pollfd fds[1];
	int timeout_msecs = 1000;
	int ret;

	fds[0].fd = fdRead;
	fds[0].events = POLLIN;
	while (1)
	{
		ret = poll(fds, 1, timeout_msecs);
	
		if (ret == -1 || ret == 0) {
			executeChildSignalHandlers();
			continue;
		}

		if((fds[0].revents&POLLIN) == POLLIN) {
			int bytesRead = read(fdRead, buffer, bufferSize*sizeof(char));

			if (bytesRead == -1 || bytesRead == 0)
				continue;

           	if (messageIdx + bytesRead > messageTotalSize) {

           		messageString = realloc(messageString, 2*messageTotalSize);
           		messageTotalSize*=2;

           	}

			memcpy(messageString + messageIdx, buffer, bytesRead*sizeof(char));

			messageIdx+=bytesRead;

			int termCharFlag = 0;
			for (int i = 0; i < messageIdx ; i++) {
				if (messageString[i] == '~') {
					messageString[i] = 0;
					termCharFlag = 1;
					break;
				}
			}

			if (termCharFlag)
				break;

		}
	}

	return messageString;

}

char* receiveMonitorString() {

	buffer[0] = 0;
	char* messageString = malloc(bufferSize*sizeof(char));
	long int messageTotalSize = bufferSize;
	long int messageIdx = 0;

	struct pollfd fds[1];
	int timeout_msecs = 500;
	int ret;

	fds[0].fd = fdRead;
	fds[0].events = POLLIN;
	while (1)
	{
		ret = poll(fds, 1, timeout_msecs);
	
		if (ret == -1 || ret == 0) {
			continue;
		}

		if((fds[0].revents&POLLIN) == POLLIN) {
			int bytesRead = read(fdRead, buffer, bufferSize*sizeof(char));
			if (bytesRead == -1 || bytesRead == 0)
				continue;

           	if (messageIdx + bytesRead > messageTotalSize) {

           		messageString = realloc(messageString, 2*messageTotalSize);
           		messageTotalSize*=2;

           	}

			memcpy(messageString + messageIdx, buffer, bytesRead*sizeof(char));

			messageIdx+=bytesRead;

			int termCharFlag = 0;
			for (int i = 0; i < messageIdx ; i++) {
				if (messageString[i] == '~') {
					messageString[i] = 0;
					termCharFlag = 1;
					break;
				}
			}

			if (termCharFlag)
				break;

		}
	}

	return messageString;

}

// -- Travel Request Server Start --
void travelRequestServer(char* citizenID,char* virusName, char* date1, int fdWrite) {

	skipNode* res;
	res = find_from_SkipList(virusName, citizenID, 1);

	totalTravelRequests+=1;
	char resString[64];
	resString[0] = 0;
	if (res)
	{
		sprintf(resString ,"YES %s ~", res->vacRecord->vaccineDate);

		myDate* travelDate = malloc(sizeof(myDate));
		getDate(travelDate, date1);

		myDate* vacDate = malloc(sizeof(myDate));
		
		getDate(vacDate, res->vacRecord->vaccineDate);

			
		if (vacDate->year < travelDate->year ) {

			if(12*(travelDate->year - vacDate->year) + travelDate->month - vacDate->month <= 6) {

				if (travelDate->day < vacDate->day) {
					acceptedTravelRequests += 1;
				}

			}

		}
		else if ( abs(vacDate->month - travelDate->month ) <= 6) {
			if (vacDate->day <= travelDate->day) {
				acceptedTravelRequests += 1;
			}
			
		}

		free(travelDate);
		free(vacDate);
	}
	else {
		strcpy(resString, "NO ~");
	}
	bufferIdx = 0;
	sendBloomFilterBuffer(resString, (strlen(resString)));
	sendBloomFilterBufferRemainings();	
	bufferIdx = 0;

}
// -- Travel Request Server End --

void searchVaccinationStatusServer(char* citizenID) {

	// sleep(1);
	bufferIdx = 0;
	citizenRecord* curCitizen = find_citizen_hashTable(citizenID);
	if (!curCitizen) {
		char* ending = "~";		
		sendBloomFilterBuffer(ending, 1);
		sendBloomFilterBufferRemainings();
		bufferIdx = 0;
		return;
	}

	doubleSkipList* curList = skipListHead;

	char citInfoStr[128];
	citInfoStr[0] = 0;

	sprintf(citInfoStr, "%s %s %s %s\nAGE %d\n", curCitizen->citizenId, curCitizen->firstName, curCitizen->lastName, curCitizen->country, curCitizen->age);
	sendBloomFilterBuffer(citInfoStr, strlen(citInfoStr));

	skipNode* curNode = NULL;
	char vacInfoRow[128];
	vacInfoRow[0] = 0;

	while (curList) {

		vacInfoRow[0] = 0;
		curNode = find_from_SkipList(curList->vaccineName, citizenID, 1);
		if (curNode) {

			sprintf(vacInfoRow, "%s VACCINATED ON %s\n", curList->vaccineName, curNode->vacRecord->vaccineDate);
			sendBloomFilterBuffer(vacInfoRow, strlen(vacInfoRow));

		}
		else {

			sprintf(vacInfoRow, "%s NOT YET VACCINATED\n", curList->vaccineName);
			sendBloomFilterBuffer(vacInfoRow, strlen(vacInfoRow));

		}

		curList = curList->nextList;

	}
	char* ending = "~";
	sendBloomFilterBuffer(ending, 1);
	sendBloomFilterBufferRemainings();

}

void sigUSR1_addVaccinationRecords() {

	int newRecordsBool = checkAllDirsForChanges();
	if (!newRecordsBool) {
		char* skipSendBloomMsg = "~";
		int n = -1;
		while (n == -1)
			n = write(fdWrite, skipSendBloomMsg, 1);
	}
	else
		sendBloomFilters();
	sigUSR1Count = 0;
}

void sigInt_sigQuit_handler(int signo) {

	char pidStr[10];
	pidStr[0] = 0;

	sprintf(pidStr, "%d", pid);

	char logFileName[64];
	logFileName[0] = 0;
	strcat(logFileName, "./logFiles/log_file.");
	strcat(logFileName, pidStr);

	FILE* fp = fopen(logFileName, "a");
	directoryReadNode* curDir = directoriesReadListHead;
	while (curDir) {

		fprintf(fp, "%s\n", curDir->path);
		curDir= curDir->nextDirectory;

	}
	fprintf(fp, "TOTAL TRAVEL REQUESTS %d\n", totalTravelRequests);
	fprintf(fp, "ACCEPTED %d\n", acceptedTravelRequests);
	fprintf(fp, "REJECTED %d\n\n", totalTravelRequests - acceptedTravelRequests);

	fclose(fp);

	sigIntQuitCaught--;

}

void read_parentInput_variables() {

	// char* inputData = receiveMonitorString();

	// First read is not buffered
	char* inputData = calloc(1,64*sizeof(char));
	int bytesRead = -1;
	while (bytesRead == -1) {
		bytesRead = read(fdRead, inputData, 128);
	}

	// printf("TEST IS %s\n", inputData);

	char* token;

	token = strtok(inputData, " ");
	int loopCount = 1;
	while (token != NULL) {
		
		if (strcmp(token, "~") == 0)
			break;
 
		if (loopCount == 1) {
			// buffer
			bufferSize = atoi(token);
			free(buffer);
			buffer = malloc(bufferSize*sizeof(char));

		}
		else if (loopCount == 2) {
			bloomFilterByteSize = atoi(token);
		}
		else if (loopCount == 3) {
			strcpy(inputDir, token);
		}

		token = strtok(NULL, " ");
		loopCount++;
	}

	free(inputData);
	// printf("DATA INIT %d %d %s\n", bufferSize, bloomFilterByteSize, inputDir);

}

void parent_Command_Reader_Server() {

	char* resString = receiveMonitorString_Extended();

	char command[64];
	char citizenID[32];
	char countryFrom[32];
	char countryTo[32];
	char vaccineType[32];
	char date1[32];
	char date2[32];

	sscanf(resString, "%s", command);
	if (strcmp(command, "trvlRq") == 0) {

		sscanf(resString, "%*s %s %s %s", citizenID, date1, vaccineType);

		travelRequestServer(citizenID, vaccineType, date1, fdWrite);

	}

	if (strcmp(command, "sVacSt") == 0) {
		sscanf(resString, "%*s %s", citizenID);

		searchVaccinationStatusServer(citizenID);
	}
	free(resString);

	return;

}
