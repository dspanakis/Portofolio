#include "../bloomFiltering/bloomFilterHeader.h"
#include "../skipList/skipListHeader.h"
#include <poll.h>
#include "../mainStructs.h"

typedef struct fileReadNode {

	char* path;

	struct fileReadNode* nextFile;

} fileReadNode;

typedef struct directoryReadNode {

	char* path;

	struct fileReadNode* fileReadNodeHead;
	struct directoryReadNode* nextDirectory;

} directoryReadNode;

int file_exists (char* );
int isDirectory(char* );
void appendWorkingDir(char* );
void appendWorkingFile(directoryReadNode* , char* );
void appendFileToStructs (char* );

fileReadNode* findFile(directoryReadNode* , char* );
int checkForDirFilesChanges(directoryReadNode* );
int checkAllDirsForChanges();

void read_save_country_directories_from_pipe();
void fill_data_structs_from_directories();

void sendBloomFilterBuffer(char* , int );
void sendBloomFilterBufferRemainings();
void sendBloomFilterBuffered(bloomFilter* );
void sendBloomFilters();

char* receiveMonitorString();
// Extended functions polls in command reader-server and exececutes queued signals
char* receiveMonitorString_Extended();

void travelRequestServer(char* ,char* , char* , int );
void searchVaccinationStatusServer(char* );

void sigInt_sigQuit_handler(int );
void sigInt_sigQuit_signal(int );

void sigUSR1_addVaccinationRecords();
void sigUSR1_handler(int );
void executeChildSignalHandlers();

void read_parentInput_variables();
void parent_Command_Reader_Server();

void initialise_and_execute(int , char** );