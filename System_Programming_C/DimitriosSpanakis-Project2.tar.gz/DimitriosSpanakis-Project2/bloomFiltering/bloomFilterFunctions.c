#include "bloomFilterHeader.h"
#include "../travelProcess/travelMonitorHeader.h"

int bloomFilterByteSize;
int bloomFilterCount = 0;
bloomFilter* bloomFilterList = NULL;

int hashFunctionCount = 0;

// Returns the ith's bit value from given char array
int get_BloomFilter_Bit(char* array, int index) {
    return 1 & (array[index / 8] >> (index % 8));
}

// Toggles bits 1->0
//				0->1
void toggle_BloomFilter_Bit(char *array, int index) {
    array[index / 8] ^= 1 << (index % 8);
}

// Sets ith bit to value
void set_BloomFilter_Bit(char* array, int index, int value) {

	int curValue = get_BloomFilter_Bit(array, index);

	if (curValue == value) 
		return;

	else 
		toggle_BloomFilter_Bit(array,index);

	return;

}

// Creates new bloom filter and appends it to single linked list if append flag is 1,
// else searches for bloomFilter
bloomFilter* search_or_append_BloomFilter(char* virusName, int appendFlag) {

	bloomFilter* prevFilter = NULL;
	bloomFilter* curFilter = bloomFilterList;

	while (curFilter != NULL) {

		if (strcmp(curFilter->vaccineName, virusName) == 0) {
			// printf("%s already exists\n", virusName);
			return curFilter;
		}

		prevFilter = curFilter;
		curFilter = curFilter->nextBloomFilter;

	}

	if (appendFlag == 0) {
		return NULL;
	}

	bloomFilter* newFilter = malloc(sizeof(bloomFilter));

	newFilter->vaccineName = malloc(((int)strlen(virusName) + 1) * sizeof(char));
	strcpy(newFilter->vaccineName, virusName);
	
	newFilter->bitArray = malloc(bloomFilterByteSize * sizeof(char));

	for (int i = 0; i < bloomFilterByteSize; i++) {

		newFilter->bitArray[i] = 0;

	}
	
	newFilter->nextBloomFilter = NULL;

	if (prevFilter == NULL) {

		bloomFilterList = newFilter;
	
	} 

	else {

		prevFilter->nextBloomFilter = newFilter;

	}

	return newFilter;

}

bloomFilter* search_or_append_BloomFilter_specific(bloomFilter* curBloom, char* virusName, int appendFlag) {

	bloomFilter* prevFilter = NULL;
	bloomFilter* curFilter = curBloom;

	while (curFilter != NULL) {

		if (strcmp(curFilter->vaccineName, virusName) == 0) {
			// printf("%s already exists\n", virusName);
			return curFilter;
		}

		prevFilter = curFilter;
		curFilter = curFilter->nextBloomFilter;

	}

	if (appendFlag == 0) {
		return NULL;
	}

	bloomFilter* newFilter = malloc(sizeof(bloomFilter));

	newFilter->vaccineName = malloc(((int)strlen(virusName) + 1) * sizeof(char));
	strcpy(newFilter->vaccineName, virusName);
	
	newFilter->bitArray = malloc(bloomFilterByteSize * sizeof(char));

	for (int i = 0; i < bloomFilterByteSize; i++) {

		newFilter->bitArray[i] = 0;

	}
	
	newFilter->nextBloomFilter = NULL;

	if (prevFilter == NULL) {

		curBloom = newFilter;
	
	} 

	else {

		prevFilter->nextBloomFilter = newFilter;

	}

	return newFilter;

}

// Inserts to corresponding bloom filter
void insert_to_BloomFilter(char* citizenID, char* virusName) {

	// Search for existing bloomFilter or create one
	bloomFilter* curFilter = search_or_append_BloomFilter(virusName, 1);

	int hashKey = 0;

	// Set all 16 bits given from hash_i
	for(int i = 0 ; i < 16 ; i++) {

		hashKey = hash_i(citizenID, i);

		set_BloomFilter_Bit(curFilter->bitArray, hashKey, 1);

	
	}

	return;

}

void insert_to_specific_BloomFilter(bloomFilter* curBloom, char* citizenID, char* virusName) {

	bloomFilter* curFilter = search_or_append_BloomFilter_specific(curBloom, virusName, 1);

	int hashKey = 0;

	// Set all 16 bits given from hash_i
	for(int i = 0 ; i < 16 ; i++) {

		hashKey = hash_i(citizenID, i);

		set_BloomFilter_Bit(curFilter->bitArray, hashKey, 1);

	
	}

	return;

}

// Check vaccineStatusBloom
int vaccineStatusBloom(char* citizenID, char* virusName) {

	bloomFilter* curFilter = search_or_append_BloomFilter(virusName, 0);

	if (curFilter == NULL)
		return -1;

	int hashKey = 0;

	for(int i = 0 ; i < 16 ; i++) {

		hashKey = hash_i(citizenID, i);
		//printf("hashKey %d\n", hashKey);

		if (get_BloomFilter_Bit(curFilter->bitArray, hashKey) == 0)
			return 0;
	
	}

	return 1;

}

void print_vaccineStatusBloom(char* citizenID, char* virusName) {

	int res = vaccineStatusBloom(citizenID, virusName);

	if (res == -1) {
		printf("INVALID VIRUS NAME\n");
		return;
	}

	if (res)
		printf("MAYBE\n");
	else
		printf("NOT VACCINATED\n");

	return;
}

int vaccineStatusBloom_specific(bloomFilter* curBloom, char* citizenID, char* virusName) {

	bloomFilter* curFilter = search_or_append_BloomFilter_specific(curBloom, virusName, 0);

	if (curFilter == NULL)
		return -1;

	int hashKey = 0;

	for(int i = 0 ; i < 16 ; i++) {

		hashKey = hash_i(citizenID, i);
		//printf("hashKey %d\n", hashKey);

		if (get_BloomFilter_Bit(curFilter->bitArray, hashKey) == 0)
			return 0;
	
	}

	return 1;

}

void print_vaccineStatusBloom_specific(bloomFilter* curBloom, char* citizenID, char* virusName) {

	int res = vaccineStatusBloom_specific(curBloom, citizenID, virusName);

	if (res == -1) {
		printf("INVALID VIRUS NAME\n");
		return;
	}

	if (res)
		printf("MAYBE\n");
	else
		printf("NOT VACCINATED\n");

	return;
}


void freeBloomFilters() {

	bloomFilter* prevBloom = NULL;
	bloomFilter* curBloom = bloomFilterList;

	while (curBloom) {

		prevBloom = curBloom;
		curBloom = curBloom->nextBloomFilter;

		free(prevBloom->vaccineName);
		free(prevBloom->bitArray);
		free(prevBloom);

	}


}

void freeBloomFilter_specific(bloomFilter* currentBloom) {

	bloomFilter* prevBloom = NULL;
	bloomFilter* curBloom = currentBloom;

	while (curBloom) {

	prevBloom = curBloom;
	curBloom = curBloom->nextBloomFilter;

	free(prevBloom->vaccineName);
	free(prevBloom->bitArray);
	free(prevBloom);

	}

}


// Hash functions given from piazza
unsigned long djb2(char* str)
{
    unsigned long hash = 5381;
    int c;

    while(c = *str++) {
        hash = ((hash << 5) + hash) + c; /* hash * 33 + c */
    }
    return hash;
}

unsigned long sdbm(char *str) {
	int c;
	unsigned long hash = 0;

	while ((c = *str++))
		hash = c + (hash << 6) + (hash << 16) - hash;

	return hash;
}

unsigned long hash_i(char *str, int i) {
	return (djb2(str) + i * sdbm(str) + i * i) % (8*bloomFilterByteSize);
}
