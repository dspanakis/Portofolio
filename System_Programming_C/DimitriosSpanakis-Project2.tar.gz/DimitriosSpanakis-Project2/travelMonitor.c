#include "./travelProcess/travelMonitorHeader.h"

extern int bloomFilterByteSize;

int numMonitors = 0;
int bufferSize = 0;
int bloomFilterByteSize = 0;

monitorInfo** monitorInfoArray = NULL;
char* inputDir = NULL;

int acceptedTravelRequests = 0;
int rejectedTravelRequests = 0;

struct sigaction singalHandling;

int sigIntFlag; // id: 3
int sigQuitFlag; // id: 2
int sigChildFlag; // id: 17


void signalsHandler(int signo) {

	if (signo == 2)
		sigIntFlag += 1;
	else if (signo == 3)
		sigQuitFlag += 1;
	else if (signo == 17)
		sigChildFlag +=1;

	printf("CAUGHT %d\n", signo);

	return;
}

void executeSignalsCaught() {

	if (sigIntFlag)
		sigFatherDeathHandler(2);
	if (sigQuitFlag)
		sigFatherDeathHandler(3);
	if (sigChildFlag) {
		sigChildDeathHandler(17);
		sigChildFlag = 0;
	}

}

int main(int argc, char* argv[]) {

	int i;
	printf("PARENT OF ALL PID |%d|\n", getpid());

	initialiseTravelMonitor(argc, argv);

	printf("\nGIVEN INPUT\n");
	printf("===============\n");
	printf("BufferSize |%d|\n", bufferSize);
	printf("bloomFilterByteSize |%d|\n", bloomFilterByteSize);
	printf("NumMonitors |%d|\n", numMonitors);
	printf("InputDir |%s|\n\n", inputDir);

	sigfillset (&(singalHandling.sa_mask));
	singalHandling.sa_flags = SA_RESTART;
	singalHandling.sa_handler = signalsHandler;
	sigaction ( SIGINT , &singalHandling , NULL );
	sigaction ( SIGQUIT , &singalHandling , NULL );
	sigaction ( SIGCHLD , &singalHandling , NULL );

	// Initialise monitorInfo struct with named pipes names etc.
	initialiseMonitorArray();
	
	// Fork and exec childs
	forkExecMonitors();

	// Open all pipes for reading and writing respectively
	printf("OPENING ALL NAMED PIPES...\n");
	openAllNamedPipes();
	printf("DONE\n\n");
   	
	// Send inputData to Monitors (bufferSize etc)
    printf("SENDING INPUT DATA TO MONITORS...\n");
    sendInputData();
    printf("DONE\n\n");

    // Send workLoad to child
    printf("ASSIGNING COUNTRY DIRS TO MONITORS...\n");
    sendWorkLoad();
    printf("DONE\n\n");

    printf("READING BLOOMFILTERS FORM ALL MONITORS...\n");
    printf("================ERRORS===================\n");	
    readBloomFilters();
    printf("=========================================\n");	
    printf("DONE\n\n");

	// for (int i = 0 ; i < numMonitors ; i++)
	// 	print_vaccineStatusBloom_specific(monitorInfoArray[i]->bloomFilterHead, "1109", "COVID-18");
 	printf("STARTING INPUT READER....\n");
	while(userInputReader()){
		executeSignalsCaught();
	}
		
	// wait(NULL);
}

// The below code wasn't used because we need our sig handlers to be small
// in size. However, i found a smart way to block incoming signals in a semaphore like way
// with the below 2 functions. I left it here just for you to take a brief look, nothing more.

// struct sigaction act;
// struct sigaction childAct;
// sigset_t block_all_sigs_mask;
// sigset_t block_int_quit;
// sigset_t emptyMask;
// Set up signal Handlers
// sigemptyset(&block_all_sigs_mask);
// sigaddset(&block_all_sigs_mask, SIGINT);
// sigaddset(&block_all_sigs_mask, SIGQUIT);
// sigaddset(&block_all_sigs_mask, SIGCHLD);

// sigfillset (&(act.sa_mask));
// act.sa_flags = SA_RESTART;
// act.sa_handler = sigFatherDeathHandler;
// sigaction ( SIGINT , &act , NULL );
// sigaction ( SIGQUIT , &act , NULL );

// sigemptyset (&block_int_quit);
// sigaddset (&block_int_quit, SIGINT);
// sigaddset (&block_int_quit, SIGQUIT);

// sigfillset (&( childAct . sa_mask ));
// childAct.sa_flags = SA_RESTART;
// childAct.sa_handler = sigChildDeathHandler;
// childAct.sa_mask = block_int_quit;
// sigaction ( SIGCHLD , &childAct , NULL );

// sigset_t emptyMask;
// sigemptyset (&emptyMask);

// void queueUpcomingSignals() {

// 	int res = sigprocmask(SIG_BLOCK, &block_int_quit, NULL);
// 	while (res == -1)
// 		res = sigprocmask(SIG_BLOCK, &block_int_quit, NULL);
// }

// void unblockSignals() {
// 	int res = sigprocmask(SIG_SETMASK, &emptyMask, NULL);
// 	while (res == -1)
// 		res = sigprocmask(SIG_SETMASK, &emptyMask, NULL);

// }

