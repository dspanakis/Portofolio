#include "./monitorProcess/monitorHeader.h"

// extern vars for citizen record hashTable
extern citizenHashTableNode** citizenHashTable;

// extern vars from BloomFiltering
extern int bloomFilterByteSize;
extern bloomFilter* bloomFilterList;
extern int bloomFilterCount; 
 
//extern vars from SkipList
extern doubleSkipList* skipListHead;

// All important structs asked to be used like blooms and skip list, are located in:
//	skipList folder
//	bloomFilterring folder
//	
// Functions that you may take a look, are located at:
//  mainStructs.h and mainFunctions.c
// All important functions of monitor process, newly implemented are located in monitorProcess folder

extern char* inputDir;
extern int bufferSize;
extern char* buffer;
extern int bufferIdx;

extern int fdRead;
extern int fdWrite;

extern int pid;

extern int totalTravelRequests;
extern int acceptedTravelRequests;

extern directoryReadNode* directoriesReadListHead;
extern int sigIntQuitCaught;
extern int sigUSR1Count;


void sigUSR1_handler(int signo) {
	sigUSR1Count = 1;
}

void sigInt_sigQuit_signal(int signo) {
	sigIntQuitCaught = 1;
}

void executeChildSignalHandlers() {
	if (sigUSR1Count) {
		sigUSR1_addVaccinationRecords();
		sigUSR1Count = 0;
	}
	else if (sigIntQuitCaught) {
		sigInt_sigQuit_handler(0);
		sigIntQuitCaught = 0;
	}
}

void initialise_and_execute(int argc, char* argv[]) {

	static struct sigaction act ;
	sigfillset (&( act . sa_mask ));
	act.sa_flags  = SA_RESTART;
	act . sa_handler = sigInt_sigQuit_signal;
	sigaction ( SIGQUIT , &act , NULL );
	sigaction ( SIGINT , &act , NULL );

	static struct sigaction act2 ;
	sigfillset (&( act2 . sa_mask ));
	act2.sa_handler = sigUSR1_handler;
	act2.sa_flags  = SA_RESTART;
	sigaction ( SIGUSR1 , &act2 , NULL );

	// Used by skiplist (flipCoin etc.)
	srand(time(NULL));

	// Used for saving unique citizen info
	hashTableInit();

	// Initialise variables before reading them from pipe
	bufferSize = 64;
	buffer = malloc(bufferSize* sizeof(char));
	bloomFilterByteSize = 128;
	inputDir = malloc(256 *sizeof(char));

	fdRead = open(argv[1], O_RDONLY);
	while (fdRead == -1)
		fdRead = open(argv[1], O_RDONLY);

	fdWrite = -1;
	while(fdWrite == -1) {
		fdWrite = open(argv[2], O_WRONLY);
	}

	read_parentInput_variables();

	read_save_country_directories_from_pipe();

	fill_data_structs_from_directories();

	sendBloomFilters();

	while(1) {
		parent_Command_Reader_Server();
	}



}


int main(int argc, char* argv[]) {
	
	pid = getpid();
	initialise_and_execute(argc, argv);
}


// YOU MAY FIND USEFUL

	//-> Prints bitmap 
	// insert_to_BloomFilter("776", "Covid-19");
	// for (int i = 0; i < bloomFilterByteSize * 8; i++) {

	// 	printf("%d", get_BloomFilter_Bit(search_or_append_BloomFilter("Covid-19", 0)->bitArray, i));

	// }
	// printf("\n");
	// print_vaccineStatusBloom("776", "Covid-19");

//PRINTS SKIP LIST (INCLUDING DUMMY NODES)
	//printSkipList("Rotavirus");
