#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include <time.h>
#include <semaphore.h>
#include <fcntl.h>
#include <sys/time.h>

int processId;
int t1;
int t2;
int sharedMemeoryId;
int saladMakerType;

struct ProtectedInt {
    sem_t mutex;
    int value;
};

struct SaladMakers {
    struct ProtectedInt tomatoMaker;
    struct ProtectedInt pepperMaker;
    struct ProtectedInt onionMaker;
};

struct Kitchen {
    
    struct SaladMakers saladMakers;

    sem_t chefLock;

    sem_t mutex;

    sem_t writeLogMutex;

    sem_t doneMutex;

    struct ProtectedInt remainingSalads;

};

int accessProtectedInt (struct ProtectedInt* protectedInt, int value) {

    sem_wait(&protectedInt->mutex);
    int res = protectedInt->value += value;
    sem_post(&protectedInt->mutex);


    return res;

}

void inputReader(int argc, char* argv[]) {

    if (argc != 8) {
        printf("Wrong usage: -t1 [lb] -t2 [ub] -s [shmid] -i [maker ingredient] -tom||-pep||-oni!\n");
        exit(1);
    }

    int i;
    int check = 0;

    for (i = 0; i < argc; i++) {

        if (strcmp(argv[i],"-t1") == 0) {

            
            char* eptr;
            t1 = strtod(argv[i+1], &eptr);
            check = 1;

            break;

        }
    }

    if (check == 0) {
        
        printf("Invalid row of arguments\n");
        exit(1);
    }

    check = 0;

    for (i = 0; i < argc; i++) {

        if (strcmp(argv[i],"-t2") == 0) {

            char* eptr;
            t2 = strtod(argv[i+1], &eptr);
            check = 1;

            break;

        }
    }

    if (check == 0) {
        
        printf("Invalid row of arguments\n");
        exit(1);
    }

    if (t1 > t2) {
        printf("Error, invalid t1 and t2\n");
        exit(1);
    }

    check = 0;

    for (i = 0; i < argc; i++) {

        if (strcmp(argv[i],"-s") == 0) {

            sharedMemeoryId = atoi(argv[i+1]);
            check = 1; 
            break;

        }
    }

    if (check == 0) {
        
        printf("Invalid row of arguments\n");
        exit(1);
    }


    for (i = 0; i < argc; i++) {

        if (strcmp(argv[i],"-tom") == 0) {

            saladMakerType = 0;
            return;

        }
    }

    for (i = 0; i < argc; i++) {

        if (strcmp(argv[i],"-pep") == 0) {

            saladMakerType = 1;
            return;

        }
    }

    for (i = 0; i < argc; i++) {

        if (strcmp(argv[i],"-oni") == 0) {

            saladMakerType = 2;
            return;

        }
    }

    printf("U didnt choose any saladmaker type, those are -tom,-pep,-oni\n");

}

int pickRandomTime(int lb, int ub) {

    if (lb == ub)
        return lb;

    int time = (rand() % (ub - lb + 1)) + lb;
    
    //printf("time %d\n", time);


    return time;

}


void timeStamp(char* result) {
    char timeBuffer[64];
    struct timeval tv;
    time_t t;
    long milliseconds;
    struct tm *info;

    gettimeofday(&tv, NULL);
    t = tv.tv_sec;
    info = localtime(&t);

    int ms = t % 1000;

    // Get time formatted to buffer
    strftime(timeBuffer, sizeof timeBuffer, "%H:%M:%S.", info);
    strcpy(result, timeBuffer);
    // Append milliseconds
    char msArr[4];
    snprintf(msArr, 4, "%d",ms);
    strcat(result,msArr);

    // printf("%s\n",result);

    return ;
}

void logSentense(sem_t* writeLogMutex, char* fileName, char* message, int saladMakerType) {

    char resultSentense[150];

    strcpy(resultSentense,"|");

    char getTimeStamp[100];

    timeStamp(getTimeStamp);


    strcat(resultSentense,getTimeStamp);

    strcat(resultSentense,"|");

    strcat(resultSentense," |");
    char processIdString[20];
    sprintf(processIdString,"%d", processId);

    strcat(resultSentense, processIdString);
    strcat(resultSentense,"| ");

    strcat(resultSentense,"|");

    if (saladMakerType == 0) {
        strcat(resultSentense, "TomatoSaladMaker");
    }
    if (saladMakerType == 1) {
        strcat(resultSentense, "PepperSaladMaker");
    }
    if (saladMakerType == 2) {
        strcat(resultSentense, "OnionSaladMaker");
    }

    strcat(resultSentense,"| -> ");

    strcat(resultSentense, message);

    strcat(resultSentense,"\n");

    printf("%s",resultSentense);

    sem_wait(writeLogMutex);
    FILE* fp = fopen(fileName, "a");
    fprintf(fp, "%s", resultSentense);
    fclose(fp);
    sem_post(writeLogMutex);

    if (saladMakerType == 0) {
        FILE* fp = fopen("tomatoMaker_log.txt", "a");
        fprintf(fp, "%s", resultSentense);
        fflush(stdout);
        fclose(fp);
    }
    if (saladMakerType == 1) {
        FILE* fp = fopen("pepperMaker_log.txt", "a");
        fprintf(fp, "%s", resultSentense);
        fflush(stdout);
        fclose(fp);
    }
    if (saladMakerType == 2) {
        FILE* fp = fopen("onionMaker_log.txt", "a");
        fprintf(fp, "%s", resultSentense);
        fflush(stdout);
        fclose(fp);
    }

}

void makeSalad() {

    int pickTime = pickRandomTime(t1, t2);
    printf("Making salad for %d seconds\n",pickTime);
    sleep(pickTime);
    return;
}

int main(int argc, char* argv[]) {

    processId = getpid();
    // sprintf("Process ID is %d\n",processId);
    inputReader(argc, argv);

    struct Kitchen* kitchenPtr = (struct Kitchen*) shmat(sharedMemeoryId, NULL, 0);

    int saladsMade = 0;
    while (kitchenPtr->remainingSalads.value > 0) {
        
        if (saladMakerType == 0) {
            logSentense(&kitchenPtr->writeLogMutex, "shared_log.txt", "Waiting for ingredients", saladMakerType);
            sem_wait(&kitchenPtr->saladMakers.tomatoMaker.mutex);
        }
        if (saladMakerType == 1) {
            logSentense(&kitchenPtr->writeLogMutex, "shared_log.txt", "Waiting for ingredients", saladMakerType);
            sem_wait(&kitchenPtr->saladMakers.pepperMaker.mutex);
        }
        if (saladMakerType == 2) {
            logSentense(&kitchenPtr->writeLogMutex, "shared_log.txt", "Waiting for ingredients", saladMakerType);
            sem_wait(&kitchenPtr->saladMakers.onionMaker.mutex);
        }

        if (kitchenPtr->remainingSalads.value <= 0) {

            sem_post(&kitchenPtr->chefLock);
            logSentense(&kitchenPtr->writeLogMutex, "shared_log.txt", "Aborting making salad", saladMakerType);
            break;

        }
        
        logSentense(&kitchenPtr->writeLogMutex, "shared_log.txt", "Get ingredients", saladMakerType);
        sem_post(&kitchenPtr->chefLock);

        logSentense(&kitchenPtr->writeLogMutex, "shared_log.txt", "Start making salad", saladMakerType);
        
        makeSalad();
        printf("I have made |%d| salads so far\n",++saladsMade);
        
        // Decrement remaining salads by 1
        accessProtectedInt(&kitchenPtr->remainingSalads, -1);

        if (saladMakerType == 0) {
            sem_wait(&kitchenPtr->mutex);
            kitchenPtr->saladMakers.tomatoMaker.value += 1;
            sem_post(&kitchenPtr->mutex);
        }
        if (saladMakerType == 1) {
            sem_wait(&kitchenPtr->mutex);
            kitchenPtr->saladMakers.pepperMaker.value += 1;
            sem_post(&kitchenPtr->mutex);
        }
        if (saladMakerType == 2) {
            sem_wait(&kitchenPtr->mutex);
            kitchenPtr->saladMakers.onionMaker.value += 1;
            sem_post(&kitchenPtr->mutex);
        }

        logSentense(&kitchenPtr->writeLogMutex, "shared_log.txt", "End making salad", saladMakerType);
    }
    // Wake up chef in case he is waiting for someone to pick ingredients while salads are done
    sem_post(&kitchenPtr->chefLock);
    // Increment the done mutex
    sem_post(&kitchenPtr->doneMutex);

    int detach = shmdt((void*) kitchenPtr);
    if (detach == -1)
        printf("DETACHMENT ERROR\n");
}