#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include <time.h>
#include <semaphore.h>
#include <fcntl.h>
#include <sys/time.h>

int processId;

double mantime;
int numOfSlds;
time_t t;


struct ProtectedInt {
	sem_t mutex;
	int value;
};


struct SaladMakers {
	// Three pairs of value (salads count) and an mutex, to wake up saladmakers
	struct ProtectedInt tomatoMaker;
	struct ProtectedInt pepperMaker;
	struct ProtectedInt onionMaker;
};

struct Kitchen {
	
	struct SaladMakers saladMakers;

	// Used from make chef wait for someone to pick ingredients
	sem_t chefLock;
	// Used to increment shared memory variables
	sem_t mutex;

	// Used to write on shared log
	sem_t writeLogMutex;

	// Mutex to wait every saladmaker to finish at the end
	sem_t doneMutex;
	// Mutex to keep track of the remaining salads
	struct ProtectedInt remainingSalads;

};

int accessProtectedInt (struct ProtectedInt* protectedInt, int value) {


    sem_wait(&protectedInt->mutex);
    int res = protectedInt->value += value;
    sem_post(&protectedInt->mutex);


    return res;

}

void logTimeStamp(FILE* fp) {

	time_t now = time(NULL);
	char date[30];
	strcpy(date, ctime(&now));
	
	char time[9];
	strcpy(time, date+11);
	time[8] = '\0';
	
	// printf("%s\n",time);

	fprintf(fp, "%s", time); 
	// return time;
}

void inputReader(int argc, char* argv[]) {

    if (argc != 5) {
        printf("Wrong usage: -n [numOfSlds] -m [mantime] !\n");
        exit(1);
    }

    int i;
    int check = 0;

    for (i = 0; i < argc; i++) {

        if (strcmp(argv[i],"-n") == 0) {

            numOfSlds = atoi(argv[i+1]);
            check = 1;

            break;

        }
    }

    if (check == 0) {
        
        printf("Invalid row of arguments\n");
        exit(1);
    }

    check = 0;

    for (i = 0; i < argc; i++) {

        if (strcmp(argv[i],"-m") == 0) {

            char* eptr;
            mantime = strtod(argv[i+1], &eptr);
            check = 1;

            break;

        }
    }

    if (check == 0) {
        
        printf("Invalid row of arguments\n");
        exit(1);
    }
}


int prevPick = 0;
int pickSaladMaker() {

    int currPick = rand()%3 + 1;

    while (currPick == prevPick)
        currPick = rand()%3 + 1;

    prevPick = currPick;

    return currPick;

}

void getToSleep() {
	sleep(mantime);
	return;
}


void timeStamp(char* result) {
    char timeBuffer[64];
    struct timeval tv;
    time_t t;
    long milliseconds;
    struct tm *info;

    gettimeofday(&tv, NULL);
    t = tv.tv_sec;
    info = localtime(&t);

    int ms = t % 1000;

    strftime(timeBuffer, sizeof timeBuffer, "%H:%M:%S.", info);
    strcpy(result, timeBuffer);

    char msArr[4];
    snprintf(msArr, 4, "%d",ms);
    strcat(result,msArr);

    // printf("%s\n",result);

    return ;
}
// Logs the message passes at chef_log.txt and shared_log.txt
void logSentense(sem_t* writeLogMutex, char* fileName,  char* message) {

    char resultSentense[150];

    strcpy(resultSentense,"|");

    char getTimeStamp[30];

    timeStamp(getTimeStamp);

    strcat(resultSentense,getTimeStamp);

    strcat(resultSentense,"|");

    strcat(resultSentense," |");
    char processIdString[20];
    sprintf(processIdString,"%d", processId);

    strcat(resultSentense, processIdString);
    strcat(resultSentense,"| ");

    strcat(resultSentense,"|");

    strcat(resultSentense, "Chef");

    strcat(resultSentense,"| -> ");

    strcat(resultSentense, message);

    strcat(resultSentense,"\n");

    printf("%s",resultSentense);

    sem_wait(writeLogMutex);
    FILE* fp = fopen(fileName, "a");
    FILE* fp2 = fopen("chef_log.txt", "a");
    fprintf(fp, "%s", resultSentense);
    fprintf(fp2, "%s", resultSentense);
    fclose(fp2);
    fclose(fp);
    sem_post(writeLogMutex);
}

// Finds concurrennt timings
void generateChefLog(struct Kitchen *kitchenPtr) {
	FILE* fp = fopen("shared_log.txt", "r");
    FILE* chef_fp = fopen("chef_log.txt", "a");

    printf("Total salads are |%d|\n", numOfSlds - kitchenPtr->remainingSalads.value);
	fprintf(chef_fp,"\nTotal salads are |%d|\n", numOfSlds - kitchenPtr->remainingSalads.value);

	int toamatoMakerSaladsCount = kitchenPtr->saladMakers.tomatoMaker.value;
    int pepperMakerSaladsCount = kitchenPtr->saladMakers.pepperMaker.value;
    int onionMakerSaladsCount = kitchenPtr->saladMakers.onionMaker.value;


	printf("TomatoMadeSalads |%d|\nPepperMadeSalads |%d|\nOnionMadeSalads |%d|\n", toamatoMakerSaladsCount, pepperMakerSaladsCount, onionMakerSaladsCount);
	fprintf(chef_fp, "TomatoMakerSalads |%d|\nPepperMakerSalads |%d|\nOnionMakerSalads |%d|\n\n", toamatoMakerSaladsCount, pepperMakerSaladsCount, onionMakerSaladsCount);

    char line[124];
    char timeString[20];

    int levelOfConcurrency = 0;
    char actionType[30];
    while (fgets (line, 124, fp)!=NULL) {
        sscanf(line, "%s %*s %*s %*s %s",timeString, actionType);
        if (strcmp("Start", actionType) == 0) {
            levelOfConcurrency++;
            if (levelOfConcurrency == 2) {
            	printf("%s",timeString);
                fprintf(chef_fp, "%s", timeString);
            }
        }

        if(strcmp("End", actionType) == 0) {
            levelOfConcurrency--;
            if (levelOfConcurrency == 1) {
            	printf(" - %s\n",timeString);
                fprintf(chef_fp, " - %s\n", timeString);
            }
        }

    }

    fclose(chef_fp);
    fclose(fp);

}

int main(int argc, char* argv[]) {

 	srand((unsigned) time(&t));
 	processId = getpid();

    inputReader(argc, argv);
    // Initialisation of shared memmory
	int sharedMemeoryId = shmget(IPC_PRIVATE, sizeof(struct Kitchen), 0644|IPC_CREAT); 

	printf("Shared memory id = %d\n", sharedMemeoryId);

	// Initilisation of semaphores needed
	struct Kitchen* kitchenPtr = (struct Kitchen*) shmat(sharedMemeoryId, NULL, 0);

	sem_init(&kitchenPtr->saladMakers.tomatoMaker.mutex, 1, 0);
	kitchenPtr->saladMakers.tomatoMaker.value = 0;
	
	sem_init(&kitchenPtr->saladMakers.pepperMaker.mutex, 1, 0);
	kitchenPtr->saladMakers.pepperMaker.value = 0;

	sem_init(&kitchenPtr->saladMakers.onionMaker.mutex, 1, 0);
	kitchenPtr->saladMakers.onionMaker.value = 0;

	sem_init(&kitchenPtr->chefLock, 1, 0);
	sem_init(&kitchenPtr->mutex, 1, 1);

	sem_init(&kitchenPtr->writeLogMutex, 1, 1);

	sem_init(&kitchenPtr->doneMutex, 1, 0);

	sem_init(&kitchenPtr->remainingSalads.mutex, 1, 1);
	int prevRemainingSalads = kitchenPtr->remainingSalads.value = numOfSlds;


	int i = 0;
	int madeSalads = 0;
	// While there are salads left
	while (kitchenPtr->remainingSalads.value > 0) {
		// Pick saladmaker "Ingredients"
		int pickMaker = pickSaladMaker(); // Returns 1, 2 , 3
		// printf("I picked |%d| saladmaker\n", pickMaker);
		// Give a random salad maker the command to make a salad

		// Raise semaphore of corresponding saladmaker
		switch (pickMaker) {
			case 1:
				logSentense(&kitchenPtr->writeLogMutex, "shared_log.txt", "Selecting |pepper| |onion|");
				logSentense(&kitchenPtr->writeLogMutex, "shared_log.txt", "Notify tomatoMaker");
				sem_post(&kitchenPtr->saladMakers.tomatoMaker.mutex);
				break;
			case 2:
				logSentense(&kitchenPtr->writeLogMutex, "shared_log.txt", "Selecting |tomato| |onion|");
				logSentense(&kitchenPtr->writeLogMutex, "shared_log.txt", "Notify pepperMaker");
				sem_post(&kitchenPtr->saladMakers.pepperMaker.mutex);
				break;
			case 3:
				logSentense(&kitchenPtr->writeLogMutex, "shared_log.txt", "Selecting |tomato| |pepper|");
				logSentense(&kitchenPtr->writeLogMutex, "shared_log.txt", "Notify onionMaker");
				sem_post(&kitchenPtr->saladMakers.onionMaker.mutex);
				break;
			default:
				printf("Error!\n");
				exit(1);
		}

		// Wait for the corresponding saladmaker to wake up
		sem_wait(&kitchenPtr->chefLock);
		logSentense(&kitchenPtr->writeLogMutex, "shared_log.txt", "Man time for resting");
		getToSleep();

		// Read new remaining salads
		// int curRemainingSalads = accessProtectedInt(&kitchenPtr->remainingSalads, 0);

        // int newSalads = prevRemainingSalads - curRemainingSalads;
        // madeSalads += newSalads;
        // printf("LoopCount is %d saladmakers new %d salads, %d made salads, %d remaining salads\n",++i, newSalads, madeSalads, curRemainingSalads);

        // prevRemainingSalads = curRemainingSalads;

	}
	// Wake up every saladmaker case we are done
	sem_post(&kitchenPtr->saladMakers.tomatoMaker.mutex);
	sem_post(&kitchenPtr->saladMakers.pepperMaker.mutex);
	sem_post(&kitchenPtr->saladMakers.onionMaker.mutex);

	// Wait for all saladmakers to finish
	for(int i = 0; i < 3; i++) {
		sem_wait(&kitchenPtr->doneMutex);
	}
	printf("End of saladmakers programs\n");
	printf("Genating chef log...\n");
	
	// Print output and concurrent times
	generateChefLog(kitchenPtr);

	printf("Exiting...\n");

	sem_destroy(&kitchenPtr->chefLock);
	sem_destroy(&kitchenPtr->mutex);
	sem_destroy(&kitchenPtr->writeLogMutex);
	sem_destroy(&kitchenPtr->doneMutex);

	sem_destroy(&kitchenPtr->remainingSalads.mutex);
	sem_destroy(&kitchenPtr->saladMakers.tomatoMaker.mutex);
	sem_destroy(&kitchenPtr->saladMakers.pepperMaker.mutex);
	sem_destroy(&kitchenPtr->saladMakers.onionMaker.mutex);

	// Detach memmory segment
	shmdt((void*) kitchenPtr);
	// Destroy it
	shmctl(sharedMemeoryId, IPC_RMID, NULL);

}