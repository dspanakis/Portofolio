#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/wait.h>
#include <locale.h>

// Here i am saving the destination path that would create the same hierarchy that
// exists in source folder
struct hardLinkNode {

    // Here is the possible *DESTINATION PATH* that we may link to.
    char filePath[512];

    // Here i save the stat info of the corresponding *SOURCE PATH*
    struct stat fileInfo;
    struct hardLinkNode* nextNode;

};

void insertToList(char* , struct stat);
struct hardLinkNode* findHardLink(struct stat);
int checkExists(char* ,char* , struct dirent* , int );
void fileCopy(char* , char* );
void deleteFile(char* );
void deleteDirectory(char* );
void cleanUpDest(char* , char* );
void list(char* , char* );
void destroyStruct();
