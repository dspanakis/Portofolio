#include "functions.h"

extern int enableDeleted;
extern int enablePrints;
extern int accountSoftHardLinks;

extern unsigned long long int bytesCopied;
extern unsigned long int entitiesCount;
extern unsigned long int entitiesCopied;

extern struct hardLinkNode *head;

extern char buf[BUFSIZ];

void insertToList(char* fileName, struct stat fileInfo) {


    if (head == NULL)
    {
        head = malloc(sizeof(struct hardLinkNode));
        strcpy(head->filePath, fileName);
        head->fileInfo = fileInfo;
        head->nextNode = NULL;
        return;
    }

    struct hardLinkNode* newNode = malloc(sizeof(struct hardLinkNode));

    strcpy(newNode->filePath, fileName);
    newNode->fileInfo = fileInfo;

    newNode->nextNode = head;
    head = newNode;

    return;
}

struct hardLinkNode* findHardLink(struct stat fileInfo) {

    struct hardLinkNode* curNode = head;

    while(curNode != NULL) {
        if (curNode->fileInfo.st_ino == fileInfo.st_ino) {

            return curNode;

        }
        curNode = curNode->nextNode;
    }

    return NULL;

}

int checkExists(char* newname2 ,char* nameDest, struct dirent* dirSrc, int type) {

    DIR *dp;
    struct dirent* dirDest;
    struct stat dirCheck;

    if ((dp=opendir(nameDest))== NULL ) {
        perror("opendir"); return -1;
    }
    int checkFlag = 0;

    while ((dirDest = readdir(dp)) != NULL ) {

        
        if (type == 0) {
                
            if (strcmp(dirSrc->d_name, dirDest->d_name) == 0) {

                stat(newname2, &dirCheck);

                if ((dirCheck.st_mode & S_IFMT) == S_IFDIR) {

                    checkFlag = 1;
                    break;
                }


            }
        }
        if (type == 1) {

            if (strcmp(dirSrc->d_name, dirDest->d_name) == 0) {
                stat(newname2, &dirCheck);

                if ((dirCheck.st_mode & S_IFMT) == S_IFREG) {

                    checkFlag = 1;
                    break;
                }
            }
        }

    }
    
    closedir(dp);
    return checkFlag;

}


void fileCopy(char* src, char* dest) {

    entitiesCopied++;

    FILE* fd1 = fopen(src, "r");
    FILE* fd2 = fopen(dest, "w");

    int n = 0;
    while ((n = fread(buf, 1, BUFSIZ, fd1)) > 0) {
        
        bytesCopied += fwrite(buf, 1, n, fd2);
    }

    fclose(fd1);
    fclose(fd2);

}

void deleteFile(char* dest) {

    // int pid;

    // pid = fork();

    // if ( pid == 0 ) {
    //     execlp("rm", "rm", dest, NULL);
    //     exit(1);
    // }
    // wait(NULL);
    remove(dest);

}

void deleteDirectory(char* dest) {

    struct stat curFileStat;
    DIR *dp;
    struct  dirent* dir;
    char* newPath;


    if ((dp=opendir(dest))== NULL ) {
        perror("opendir"); return;
    }

    while ((dir = readdir(dp)) != NULL) {

        if (dir->d_ino == 0 ) continue;
        if (strcmp(dir->d_name, ".") == 0)
            continue;
        if (strcmp(dir->d_name, "..") == 0)
            continue;

        newPath = (char *)malloc(strlen(dest)+strlen(dir->d_name)+2);
        strcpy(newPath, dest);
        strcat(newPath, "/");
        strcat(newPath, dir->d_name);
        
        stat(newPath, &curFileStat);

        if ((curFileStat.st_mode & S_IFMT) == S_IFDIR){
            //printf("---- DELETING SUB-DIRECTORY AT: %s -----\n", newPath);
            if(enablePrints)printf("|-d| directory -> %s\n", newPath);
            deleteDirectory(newPath);
            //printf("---- END OF DELETING SUB-DIRECTORY -----\n\n");
        }
        else {
            if(enablePrints)printf("|-d| file -> %s\n", newPath);
            //remove(newPath);
            //deleteFile(newPath);
        }
        free(newPath);
    }

    closedir(dp);

    //Removes extra directory : remove(dest);
    //printf("directory at %s doesn't exist in Source Directory\n", dest);

}

void cleanUpDest(char* name, char* name2) {

    struct stat curFileStat;

    DIR *dp2;
    DIR *dp1;
    struct  dirent *dir2;
    struct  dirent *dir1;

    char* delPath;

    if ((dp2=opendir(name2))== NULL ) {
        perror("opendir"); return;
    }

    while ((dir2 = readdir(dp2)) != NULL ) {

        if (dir2->d_ino == 0 ) continue;
        if (strcmp(dir2->d_name, ".") == 0)
            continue;
        if (strcmp(dir2->d_name, "..") == 0)
            continue;

        if ((dp1=opendir(name))== NULL ) {
            perror("opendir"); return;
        }

        int delFlag = 1;
        delPath = (char *)malloc(strlen(name2)+strlen(dir2->d_name)+2);
        strcpy(delPath, name2);
        strcat(delPath, "/");
        strcat(delPath, dir2->d_name);
        while ((dir1 = readdir(dp1)) != NULL ) {

            if (dir1->d_ino == 0 ) continue;
            if (strcmp(dir1->d_name, ".") == 0)
                continue;
            if (strcmp(dir1->d_name, "..") == 0)
                continue;

            if(strcmp(dir1->d_name, dir2->d_name) == 0 && dir1->d_type == dir2->d_type)
            {
                delFlag = 0;
                break;        
            }
        }
        if (delFlag){
            stat(delPath, &curFileStat);

            if ((curFileStat.st_mode & S_IFMT) == S_IFDIR){
                // printf("---- DELETING DIRECTORY AT: %s -----\n\n", delPath);
                deleteDirectory(delPath);
                if(enablePrints)printf("|-d| directory -> %s\n", delPath);
                // printf("---- END OF DELETING DIRECTORY ----\n\n");
            }
            else {
                //deleteFile(delPath);
                if(enablePrints)printf("|-d| file -> %s\n", delPath);
            }

        }

        free(delPath);
        closedir(dp1);
    }
    closedir(dp2);

}

void list(char *name, char* name2) {

    struct stat dirCheck1;
    struct stat dirCheck2;
    DIR     *dp;
    struct  dirent *dir;

    char* newname;
    char* newname2;

    ssize_t softLinkCheckCount = 0;
    char linkBuf[BUFSIZ];
    char linkBuf2[BUFSIZ];

    if (enableDeleted)
        cleanUpDest(name, name2);

    if ((dp=opendir(name))== NULL ) {
        perror("opendir"); return;
    }

    while ((dir = readdir(dp)) != NULL ) {
        if (dir->d_ino == 0 ) continue;

        if (strcmp(dir->d_name, ".") == 0)
            continue;
        if (strcmp(dir->d_name, "..") == 0)
            continue;

        entitiesCount++;

        // Keep track of path
        newname=(char *)malloc(strlen(name)+strlen(dir->d_name)+2);
        strcpy(newname,name);
        strcat(newname,"/");
        strcat(newname,dir->d_name);
        stat(newname, &dirCheck1);
        //printf("%s numLinks %d\n", newname, (int)dirCheck1.st_nlink);

        // Make second path similar
        newname2=(char *)malloc(strlen(name2)+strlen(dir->d_name)+2);
        strcpy(newname2,name2);
        strcat(newname2,"/");
        strcat(newname2,dir->d_name);
        //printf("%s -> %s\n", newname2, dir->d_name);
        
        //=============== CASE ITS A SOFTLINK ==============
        softLinkCheckCount = readlink(newname, linkBuf, BUFSIZ);
        
        if (softLinkCheckCount != -1)
            linkBuf[softLinkCheckCount] = '\0';

        if (softLinkCheckCount > 0) {

            if(!accountSoftHardLinks) {
                if(enablePrints)printf("|skipping| softlink %s (missing -l flag)\n", newname);
                free(newname); newname=NULL;
                free(newname2); newname2=NULL;
                continue;
            }
            else {

                softLinkCheckCount = readlink(newname2, linkBuf2, BUFSIZ);
                if (softLinkCheckCount != -1)
                    linkBuf2[softLinkCheckCount] = '\0';

                if(strcmp(linkBuf, linkBuf2) == 0) {
                    if(enablePrints)printf("|skipping| softlink %s -> %s already exists.\n", newname2, linkBuf);
                    free(newname); newname=NULL;
                    free(newname2); newname2=NULL;
                    continue;
                }

                unlink(newname2);
                int suc = symlink(linkBuf, newname2);
                if (suc) {
                    printf("PR0BLEM C0PYING SYMLINK PATH\n");
                }
                else {
                    if(enablePrints)printf("|creating| softlink %s -> %s\n", newname2, linkBuf);
                }
                free(newname); newname=NULL;
                free(newname2); newname2=NULL;
                //printf("suc iss %d\n", suc);
                continue;
            }
        }

        //==================================================

        if ((dirCheck1.st_mode & S_IFMT) == S_IFDIR) {

            int checkDirectory = checkExists(newname2, name2, dir, 0);

            if (checkDirectory == 0) {

                //printf("----- MAKING DIR ------\n");
                
                entitiesCopied++;
                if(enablePrints)printf("|copying| %s -> %s\n", newname, newname2);
                mkdir(newname2, 0777);
                
                //printf("%s\n", newname2);
                //printf("------ END -------\n\n");
            }


            list(newname, newname2);
        }
        else {

            if(accountSoftHardLinks) {
                struct hardLinkNode* findings;
                findings = findHardLink(dirCheck1);

                if (findings != NULL) {

                    if (strcmp(findings->filePath, newname2) != 0) {

                        struct stat temp1;
                        struct stat temp2;

                        stat(findings->filePath, &temp1);
                        stat(newname2, &temp2);

                        if (temp1.st_ino == temp2.st_ino) {
                             if(enablePrints)printf("|skipping| hardlink %s -> %s already exists.\n", newname2, findings->filePath);

                            free(newname); newname=NULL;
                            free(newname2); newname2=NULL;
                            continue;
                        }

                        unlink(newname2);
                        int myBool = link(findings->filePath, newname2);
                        
                        if(myBool)
                            printf("SOMETHING WENT REALLYY WRONG WITH HARDLINK BINDING\n");
                        else {

                             if(enablePrints)printf("|creating| hardlink %s -> %s\n", newname2, findings->filePath);
                        }

                        free(newname); newname=NULL;
                        free(newname2); newname2=NULL;
                        continue;
                    }

                }
            }

            int checkFile = checkExists(newname2, name2, dir, 1);

            if (checkFile) {

                stat(newname2, &dirCheck2);

                double timeModDiff = difftime( dirCheck1.st_mtime, dirCheck2.st_mtime);

                if (dirCheck1.st_size != dirCheck2.st_size || timeModDiff > 0.0) {

                    //printf("----UPDATING CHANGES TO FILE %s ---\n", newname2);

                    //printf("timeModDiff -> %lf\n", timeModDiff);
                    if(enablePrints)printf("|updating| %s -> %s\n", newname, newname2);
                    

                    fileCopy(newname, newname2);

                }

            }
            else {

                if(enablePrints)printf("|copying| %s -> %s\n", newname, newname2);
                
                fileCopy(newname, newname2);

            }

            // Add to list
            //printf("%s has %ld links\n", newname, dirCheck1.st_nlink);
            if (accountSoftHardLinks) {

                if (dirCheck1.st_nlink > 1) {
                    //printf("~~~~Inserting %s\n", newname2);
                    insertToList(newname2, dirCheck1);
                }
            
            }

        }

        //printout(newname);
        free(newname); newname=NULL;
        free(newname2); newname2=NULL;
    }
    closedir(dp);
}

void destroyStruct() {

    if (head == NULL)
        return;

    // if (head->nextNode == NULL) {

    //     free(head);
    //     return;
    // }
    struct hardLinkNode* prevNode = NULL;
    struct hardLinkNode* curNode = head;
    while (curNode != NULL)
    {

        prevNode = curNode;
        curNode = curNode->nextNode;
        free(prevNode);

    }

}