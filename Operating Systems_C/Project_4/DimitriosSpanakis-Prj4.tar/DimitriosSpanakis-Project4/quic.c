#include "functions.h"

int enableDeleted = 0;
int enablePrints = 0;
int accountSoftHardLinks = 0;

unsigned long long int bytesCopied = 0;
unsigned long int entitiesCount = 0;
unsigned long int entitiesCopied = 0;

struct hardLinkNode *head = NULL;
char buf[BUFSIZ];

int copyInside(char* sourcePath, char* destPath) {

    int res = 0;
    char sourceFullPathBuf[PATH_MAX + 2];
    char* sourceFullPath = realpath(sourcePath, sourceFullPathBuf);

    char destFullPathBuf[PATH_MAX + 2];
    char* destFullPath = realpath(destPath, destFullPathBuf);

    if (strlen(sourceFullPath) <= strlen(destFullPath)) {
        strcat(sourceFullPath, "/");
        strcat(destFullPath, "/");

        destFullPathBuf[strlen(sourceFullPath)] = '\0';
        if (strcmp(sourceFullPath, destFullPath) == 0) {
            res = 1;
        }
    }
    //free(sourceFullPath);
    //free(destFullPath);
    return res;
}


void validateInputAndExecute(int argc, char* argv[]) {


    struct stat bufSource;
    struct stat bufDestination;


    if (argc < 3) {
        printf("Invalid input, expecting ./quic (-v || -d || -l) source destination\n");
        exit(1);
    }
    int i;
    int flagsRead = 0;
    for(i = 0; i < argc; i++)
    {
        if(strcmp(argv[i],"-v") == 0)
        {
            flagsRead++;
            printf("Enabling |-v| flag...\n");
            enablePrints = 1;
            break;
        }
    }

    for(i = 0; i < argc; i++)
    {
        
        if(strcmp(argv[i],"-d") == 0)
        {
            flagsRead++;
            if(enablePrints) printf("Enabling |-d| flag...\n");
            enableDeleted = 1;
            break;
        }
    }

    for(i = 0; i < argc; i++)
    {
        
        if(strcmp(argv[i],"-l") == 0)
        {
            if(enablePrints) printf("Enabling |-l| flag...\n");
            flagsRead++;
            accountSoftHardLinks = 1;
            break;
        }
    }

    for(i = 1 + flagsRead; i < argc ; i++)
    {
        if(strcmp(argv[i],"-v") == 0 || strcmp(argv[i],"-d") == 0 || strcmp(argv[i],"-l") == 0)
        {
            printf("Invalid input, expecting ./quic (-v || -d || -l) source destination\n");
            exit(1);
        }

    }

    // Check input 1 if is directory or not
    stat(argv[1 + flagsRead], &bufSource);

    switch (bufSource.st_mode & S_IFMT) {
    
        case S_IFREG: printf("source is not a directory\n"); exit(1);
        case S_IFDIR: break;
        default: printf("source is neither file nor directory\n"); exit(1);
    
    }

    // Check if input2 is directory or not
    stat(argv[2 + flagsRead], &bufDestination);

    int delFlag = 0;
    switch (bufDestination.st_mode & S_IFMT) {
    
        case S_IFREG: 
            printf("destination is not a directory\n"); exit(1);
        case S_IFDIR: 
            break;
        default:
            delFlag = 1;
            mkdir(argv[2 + flagsRead], 0700);
            if(enablePrints) printf("created directory %s\n", argv[2 + flagsRead]);
    }

    if (!copyInside(argv[1 + flagsRead], argv[2 + flagsRead])) {
        list(argv[1+ flagsRead], argv[2+ flagsRead]);
    }
    else {
        // TODO: if dest dir created then remove dest dir
        
        if(delFlag)
            remove(argv[2 + flagsRead]);
        printf("The destination folder is subfolder of the source folder!\n");
        exit(1);
    }
}
 

int main(int argc, char* argv[]) {

    clock_t t; 
    t = clock();

    validateInputAndExecute(argc, argv);

    t = clock() - t;
    double timeTaken = ((double)t)/CLOCKS_PER_SEC;

    if(enablePrints) { 
        printf("\nthere are %ld files/directories in the hierarchy\n", entitiesCount);
        printf("number of entities copied is %ld (without hardlinks and softlinks)\n", entitiesCopied);
        //printf("Time Taken for execution was %.2lf\n", timeTaken);
        printf("copied %lld bytes (%.2lf megabytes) in %.3f sec at %.2lf bytes/sec\n", bytesCopied, (double)bytesCopied/(1024*1024),timeTaken, (double) bytesCopied / (timeTaken));
    }

    destroyStruct();
}


