#include "header_fatherchildShared.h"

struct wNode {
    pid_t pid;
    int start;
    int end;

    int numberCount;
    int runTime;
    int done;
};

struct wNode* wNodeArray = NULL;

void incrementWNodeNumberCount(int fdIndex) 
{
    wNodeArray[fdIndex].numberCount++;
}

void initialise(int n, int start, int end)
{
	int count = end - start + 1;

    int portionStart = start;
    int portionEnd = start + count/n;
    int portionPart = 1;
    int bonus = count - n*(count-1/n) + 1;


   wNodeArray = malloc(n*sizeof(struct wNode));
   for(int i = 0 ; i < n; i++)
   {
        wNodeArray[i].pid = 0;
        wNodeArray[i].start = portionStart;
        wNodeArray[i].end = portionEnd;
        wNodeArray[i].numberCount = 0;
        wNodeArray[i].runTime = 0;
        wNodeArray[i].done = 0;

        portionPart++;
        portionStart = portionEnd + 1;
        portionEnd = start + portionPart*(count/n);
        if(bonus)
        {
            bonus--;
            portionEnd++;
        }
        if(portionEnd > end)
            portionEnd = end;

   }
   wNodeArray[n-1].end = end;
}

void print(struct wNode* lNodeArray,int n)
{
    for(int i = 0; i < n ; i++)
    {
        printf("START-END: %d -> %d\n", lNodeArray[i].start, lNodeArray[i].end);
    }
}

int findMinTime(int n)
{
    int minTime = wNodeArray[0].runTime;
    for(int i = 1; i < n; i++)
    {
        if(wNodeArray[i].runTime < minTime)
        {
            minTime = wNodeArray[i].runTime;
        }
    }
    return minTime;
}

int findMaxTime(int n)
{
    int maxTime = wNodeArray[0].runTime;
    for(int i = 1; i < n; i++)
    {
        if(wNodeArray[i].runTime > maxTime)
        {
            maxTime = wNodeArray[i].runTime;
        }
    }
    return maxTime;
}

//===============SendPrimesBuffered===============//
void sendAllPrimes(int n, int* fdP)
{
    bubbleSort(primesCount);

    int primesBufferIndex = 0;

    struct primeNode primesBuffer[MSG_BUF];

    for(int i = 0 ; i < primesCount ; i++)
    {
        primesBuffer[primesBufferIndex].prime = primesArray[i].prime;
        primesBuffer[primesBufferIndex].time = primesArray[i].time;
        primesBufferIndex++;

        if(primesBufferIndex > MSG_BUF)
        {
                // Send Primes
                if(primesBufferIndex > 0)
                {
                    // Send primes in buffer
                    write(fdP[1], primesBuffer, primesBufferIndex * sizeof(struct primeNode));
                }
                primesBufferIndex = 0;
        }
    }
    if(primesBufferIndex > 0)
    {
        // Send primes in buffer
        write(fdP[1], primesBuffer, primesBufferIndex * sizeof(struct primeNode));
    }

    //Way to send one by one
    // for( int i = 0 ; i < primesCount ; i++)
    // {
    //     // printf("PrimesFound = %d\n",wNodeArray[i].numberCount);
    //     write(fdP[1], &primesArray[i], sizeof(struct primeNode));
    // }

    //Terminator to write wNodeTimes 
    struct primeNode terminator2;
    for(int i = 0 ; i < n ; i++)
    {
        terminator2.prime = 0;
        terminator2.time = wNodeArray[i].runTime;
        write(fdP[1], &terminator2, sizeof(struct primeNode));
    }

    //Write terminators -1 + minTime, -2 + maxTime
    struct primeNode terminator[2];
    terminator[0].prime = -1;
    terminator[0].time = findMinTime(n);
    terminator[1].prime = -2;
    terminator[1].time = findMaxTime(n);


    write(fdP[1], &terminator, 2*sizeof(struct primeNode));

    // free(terminator2);
}
//===============EndOfSendPrimesBuffered===============//

//==================executeParent=========================
int executeParent(int n, int* fd, int* fdP)
{
    struct pollfd fds[1];
    struct primeNode buf[MSG_BUF];
    int donecount = 0;

    // while still not completed processes (nodes)
    while(donecount < n)
    {
        // for each process
        for(int processIdx = 0 ; processIdx < n ; processIdx++)
        {
            // if process incomplete
            if (!wNodeArray[processIdx].done) {

                // printf("Work with process: %d\n", processIdx);
                /* watch stdin for input */
                fds[0].fd = fd[processIdx * 2];
                fds[0].events = POLLIN;

                int pollres = poll(&fds[0], 1, 800);
                // printf("Polres: %d\n", pollres);
                // check timeout
                if(pollres != 0) {
                    // if ready to read
                    if (fds[0].revents & POLLIN)
                    {
                        // printf("Read process: %d\n", processIdx);
                        // read bytes
                        int bytesRead = read(fd[processIdx * 2], &buf, MSG_BUF* sizeof(struct primeNode));
                        if(bytesRead > 0) {
                            // count primes read
                            int primesRead = bytesRead / sizeof(struct primeNode);
                            // printf("PrimesRead: %d\n", primesRead);
                            // for each prime
                            for(int bufIdx = 0 ; bufIdx < primesRead ; bufIdx++ )
                            {
                                // terminate
                                if(buf[bufIdx].prime == -1) {
                                    // printf("Done Node: %d\n", processIdx);
                                    donecount++;
                                    wNodeArray[processIdx].runTime = buf[bufIdx].time;
                                    wNodeArray[processIdx].done = 1;

                                    close(fd[processIdx * 2]);
                                    close(fd[processIdx * 2 + 1]);
                                    break;
                                }
                                else {
                                    addPrimeToList(buf[bufIdx]);
                                    incrementWNodeNumberCount(processIdx);
                                }
                            }
                        }
                    }
                    else{
                        // printf("Not Ready Node: %d\n", processIdx);
                    }
                }
                else
                {
                    // printf("Timeout Node: %d\n", processIdx);
                }
            }
        }
    }
    
    //======================End of Receive========================

    // printPrimes();
    // printf("L-Leaf Primes Found = %d\n", primesCount);
    //Send all primes to father
    sendAllPrimes(n,fdP);
	

    return 1;
}

void executeChild(int programPick, int n, int start, int end, int* fd, char ppid[20])
{
	char nFactor[3];
    char startPos[20];
    char endPos[20];

    itos(n, nFactor);
    itos(start,startPos);
    itos(end, endPos);

    char str_fd[3];
    str_fd[0] = fd[0];
    str_fd[1] = fd[1];
    str_fd[2] = '\0';

    int code;
    switch(programPick)
    {
    	case 0:
    		code = execl("./prime1", "./prime1", startPos, endPos, ppid, str_fd, NULL);
    	case 1:
    		code = execl("./prime2", "./prime2", startPos, endPos, ppid, str_fd,NULL);
    	case 2:
    		code = execl("./prime3", "./prime3", startPos, endPos, ppid, str_fd,NULL);
    }
    if(code == -1)
    {
    	perror("Failed to execute w1,w2... execs\n");
    }
    exit(1);
}

//Those vars are coming from fatherChildSharedFunctions.c
// struct primeNode* primesArray = NULL;
// int primesArraySize = MSG_BUF;
// int primesCount = 0;

int main(int argc, char* argv[])
{
	// printf("CHILD PROCESS\n");

	int n = myAtoi(argv[1]);
	int start = myAtoi(argv[2]);
	int end = myAtoi(argv[3]);

    int fdP[2]; //Parents fd, to send results!
    fdP[0] = argv[4][0];
    fdP[1] = argv[4][1];

    char parentOfAllId[20];
    strcpy(parentOfAllId, argv[5]);
    int fatherLoopCount = myAtoi(argv[6]);

    int* fd = malloc(2*n*sizeof(int));
    for(int i = 0 ; i < n ; i++){
        pipe(fd+2*i);
    }


	// printf("n = %d, start = %d, end = %d\n", n, start, end);

    //Defines partion for each l-leaf and stores info
    initialise(n, start, end); //Initialise lWnodes
    primeListInit(); //Initialise resList in fatherChildSharedFunctions.c

	
    // print(wNodeArray, n);

	pid_t pid;
    
    int programPick = (fatherLoopCount * n) % 3;
	for(int i=0 ; i < n; i++)
	{
		pid = fork();
		if(pid == -1)
		{
			printf("Errorr");
			exit(1);
		}
		if(pid != 1) //Parent Process
		{
			wNodeArray[i].pid = pid;
            programPick++;
            if(programPick > 2)
            {
                programPick = 0;
            }
            // wait(NULL);
		}
		if(pid == 0) //Child Process
		{
        
            // printf("Program pick = %d\n", programPick);
			executeChild(programPick, n, wNodeArray[i].start, wNodeArray[i].end, &fd[2*i], parentOfAllId);
		}
	}

	if(pid != 1) //Parent Process
	{

		executeParent(n, fd, fdP);
        free(primesArray);
        free(wNodeArray);
        free(fd);

        printf("....Terminating lLeaf with pid |%d|....\n", getpid());
        exit(1);
	}



}