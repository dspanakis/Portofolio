struct primeNode {
	int prime;
	int time; // Time as *1000
};