#include "header_msgbuf.h"
#include "header_primeNodeStruct.h"
#include "header_primeAlgorithm.h"

int prime(int n){
        int i;
        if (n==1) return(NO);
        for (i=2 ; i<n ; i++)
                if ( n % i == 0) return(NO);
        return(YES);
}

void findPrimes1(){

        int lb=0, ub=0, i=0;

        lb=start;
        ub=end;

        if ( ( lb<1 )  || ( lb > ub ) ) {
                printf("usage: prime1 lb ub \n");
                exit(1); }

        for (i=lb ; i <= ub ; i++)
                if ( prime(i)==YES ){
                        foundPrime(i);
                }

}

//Declared in primeAlgorithSharedFunctions.c
extern unsigned int start, end;
extern int fd[2]; 

int main(int argc, char* argv[])
{
    init(argc, argv); //Stores start-end and pipe in global vars + starts timer
    findPrimes1(start,end);
    terminate(); //Sends remaining primes and writes terminator
}