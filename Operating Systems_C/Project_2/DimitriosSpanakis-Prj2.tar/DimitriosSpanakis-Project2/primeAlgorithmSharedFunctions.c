#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/times.h>
#include <signal.h>
#include <string.h>
#include <math.h>
#include "header_msgbuf.h"
#include "header_primeNodeStruct.h"

int primesTotalCount = 0;

int mainProcessId;
unsigned int start, end;
int fd[2]; 

int primesBufferIndex = 0;
struct primeNode primesBuffer[MSG_BUF];

double ticspersec, t1;
struct tms tb1;

double primeStartTime;
double primeEndTime;

struct tms tb3;
struct tms tb4;

// Very First Call
void init(int argc, char* argv[])
{
    // Process Arguments
    start = atoi(argv[1]);
    end = atoi(argv[2]);
    mainProcessId = atoi(argv[3]);
    fd[0] = argv[4][0];
    fd[1] = argv[4][1];

    // printf("wnode s:%d end %d\n", start,end);
    // pid_t pid = getpid();
    // write(fd[1], &pid, sizeof(pid_t));

    // Start execution timing
    ticspersec = (double) sysconf (_SC_CLK_TCK);
    t1 = (double) times (&tb1) ;
    primeStartTime = (double) times(&tb3);
}

void sendPrimes() {

    if(primesBufferIndex > 0)
    {
        // Send primes in buffer
        write(fd[1], primesBuffer, primesBufferIndex * sizeof(struct primeNode));
    }
    primesBufferIndex = 0;
}

void foundPrime(int primeNumber)
{
    // Print prime
    // printf("%d ", primeNumber);
    primeEndTime = (double) times(&tb4);

    double resTime = 1000*((primeEndTime - primeStartTime)/ticspersec);
    
    primeStartTime = primeEndTime;

    //Increment total count
    primesTotalCount++;

    // Store prime to buffer
    primesBuffer[primesBufferIndex].prime = primeNumber;
    primesBuffer[primesBufferIndex].time = resTime;
    primesBufferIndex++;
    // Check Primes Buffer Full
    if(primesBufferIndex > MSG_BUF)
    {
        // Send Primes
        sendPrimes();
    }
}


// Very Last Call
void terminate() {

    sendPrimes();

    double t2, cpu_time;
    struct tms tb2;

    // calculate time elapsed
    t2 = (double) times (& tb2);
    // cpu_time = (double) (( tb2 . tms_utime + tb2 . tms_stime ) - ( tb1 . tms_utime + tb1 . tms_stime ));
    // printf("Run time was %lf sec ( REAL time ) although we used the CPU for %lf sec ( CPU time ).\n", (t2 - t1) / ticspersec , cpu_time / ticspersec );
    // ->TIME PROGRAM HERE AND WRITE IT FIRST
    double timeRun = 1000 * ((t2 - t1) / ticspersec);

    //Stop timer and write it in terminator
    struct primeNode terminator;
    terminator.prime = -1;
    terminator.time = timeRun;

    // printf("Time run was %f\n", timeRun);
    write(fd[1], &terminator, sizeof(struct primeNode));

    
    // Close pipes
    close(fd[0]);
    close(fd[1]);

    if(kill(mainProcessId, SIGUSR1) == -1)
    {
        perror("Signal sending Error\n");
    }

    // Exit
    printf("....Exiting wLeaf with pid |%d|....\n", getpid());
    exit(1);
}