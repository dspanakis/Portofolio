#include "header_msgbuf.h"
#include "header_primeNodeStruct.h"
#include "header_primeAlgorithm.h"

/*Prime Function */

//Made at first semester :D
void findPrimesDeterministic(int MINNUM, int MAXNUM)
{
    int isprime;       /*TRUE=1 FALSE=0 */
    unsigned int i,j;
    if(MINNUM == 1)
        MINNUM++;
    if(MINNUM == 2)
        foundPrime(2);
    if(MINNUM % 2 == 0)
        MINNUM++; //Make minum first number 
    for (i = MINNUM; i <= MAXNUM ; i=i+2)
    {
        isprime = 1;
        if(i == 3)
        {
            foundPrime(i);
            continue;
        }
        if(i == 5)
        {
            foundPrime(i);
            continue;
        }
        if(i%3!=0)
        {
        
            for (j = 5; j * j <= i ; j=j+6) 
            {  
                if ( i%j == 0 || i%(j+2) == 0)
                {   
            
                    isprime = 0;
                    break;
                
                }
            }
            
            if (isprime == 1) 
            {
                foundPrime(i);
            }
    
        }
    }
}

//Declared in primeAlgorithSharedFunctions.c
extern unsigned int start, end;
extern int fd[2]; 

// main
int main(int argc, char* argv[])
{
    init(argc, argv); //Stores start-end and pipe in global vars + starts timer
    findPrimesDeterministic(start, end);
    terminate(); //Sends remaining primes and writes terminator
}
