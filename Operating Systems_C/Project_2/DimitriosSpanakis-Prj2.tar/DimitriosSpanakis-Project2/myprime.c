#include "header_fatherchildShared.h"

struct inputStruct
{
    int branchFactor;
    int startPrime;
    int endPrime;
};
 
struct lNode {
    pid_t pid;
    int start;
    int end;

    int numberCount;
    int minRunTime;
    int maxRunTime;
    int* wNodeTimes;
    int done;
};

struct lNode* lNodeArray = NULL;


int signalCount = 0;

void sigusr1(int signo) 
{
       signalCount++;
}

void incrementLNodeNumberCount(int fdIndex) 
{
    lNodeArray[fdIndex].numberCount++;
}

void initialise(int n, int start, int end)
{
    int count = end - start + 1;

    int portionStart = start;
    int portionEnd = start + count/n;
    int portionPart = 1;
    int bonus = count - n*(count-1/n) + 1;

    lNodeArray = malloc(n*sizeof(struct lNode));
    for(int i = 0 ; i < n; i++)
    {
        lNodeArray[i].pid = 0;
        lNodeArray[i].start = portionStart;
        lNodeArray[i].end = portionEnd;
        lNodeArray[i].numberCount = 0;
        lNodeArray[i].minRunTime = 0;
        lNodeArray[i].maxRunTime = 0;

        lNodeArray[i].wNodeTimes = malloc(n*sizeof(int));

        portionPart++;
        portionStart = portionEnd + 1;
        portionEnd = start + portionPart * (count/n);
        if(bonus)
        {
            bonus--;
            portionEnd++;
        }
        if(portionEnd > end)
            portionEnd = end;
    }
    lNodeArray[n-1].end = end;

}

void print(struct lNode* lNodeArray,int n)
{
    for(int i = 0; i < n ; i++)
    {
        printf("START-END: %d -> %d\n", lNodeArray[i].start, lNodeArray[i].end);
    }
}

double findMinTime(int n)
{
    int minTime = lNodeArray[0].minRunTime;
    for(int i = 1 ; i < n ; i++)
    {
        if(lNodeArray[i].minRunTime < minTime)
        {
            minTime = lNodeArray[i].minRunTime;
        }
    }
    double res = (double)minTime/(double)1000; 
    return res;
}

double findMaxTime(int n)
{
    int maxTime = lNodeArray[0].maxRunTime;
    for(int i = 1 ; i < n ; i++)
    {
        if(lNodeArray[i].maxRunTime > maxTime)
        {
            maxTime = lNodeArray[i].maxRunTime;
        }
    }
    double res = (double)maxTime/(double)1000; 
    return res;
}

 
void printStatistics(int n)
{
    bubbleSort(primesCount);
    printPrimes();
    double MinTime = findMinTime(n);
    double MaxTime = findMaxTime(n);
    printf("\n");
    printf("----------L_Leaf_Info---------\n");
    for(int i = 0 ; i < n ; i++)
    {
        printf("L-Leaf with pid |%d| found |%d| primes\n", lNodeArray[i].pid, lNodeArray[i].numberCount);
    }
    printf("--------------END-------------\n");
    
    printf("\n");
    
    printf("----------W_Node_Info---------\n");
    printf("Min time of a W-Leaf to finish: |%.3f| seconds\n", MinTime);
    printf("Max time of a W-Leaf to finish: |%.3f| seconds\n\n", MaxTime);
    int count = 0;
    for(int i = 0 ; i < n ; i++)
    {
        for(int j = 0 ; j < n ; j++ )
        {
            double time = (double)(lNodeArray[i].wNodeTimes[j])/(double)1000;
            printf("Time for |W%d| was |%.3lf| seconds\n", count++, time);
        }
    }
    printf("--------------END-------------\n");

    printf("\n");

    printf("--------Total_Info-------\n");
    printf("Computed primes between |%d| and |%d| with branching factor |%d|\n", lNodeArray[0].start, lNodeArray[n-1].end, n);
    printf("Primes total count is |%d|\n", primesCount);
    printf("Signal Count is |%d|, while expected is: |%d|\n",signalCount, n*n);
    printf("-----------END------------\n");

    printf("\nMSG_BUF was set to %d", MSG_BUF);
    
    printf("\n");
}

int executeParent(int n, int* fd)
{
    struct pollfd fds[1];
    struct primeNode buf[MSG_BUF];
    int donecount = 0;

    int* timeIdx = calloc(n, sizeof(int)); //Used to index times of each w-node
    // while still not completed processes (nodes)
    while(donecount < n)
    {
        // for each process
        for(int processIdx = 0 ; processIdx < n ; processIdx++)
        {
            // if process incomplete
            if (!lNodeArray[processIdx].done) {

                // printf("Work with process: %d\n", processIdx);
                /* watch stdin for input */
                fds[0].fd = fd[processIdx * 2];
                fds[0].events = POLLIN;

                int pollres = poll(&fds[0], 1, 800);
                // printf("Polres: %d\n", pollres);
                // check timeout
                if(pollres != 0) {
                    // if ready to read
                    if (fds[0].revents & POLLIN)
                    {
                        // printf("Read process: %d\n", processIdx);
                        // read bytes
                        int bytesRead = read(fd[processIdx * 2], &buf, MSG_BUF* sizeof(struct primeNode));
                        if(bytesRead > 0) {
                            // count primes read
                            int primesRead = bytesRead / sizeof(struct primeNode);
                            // printf("PrimesRead: %d\n", primesRead);
                            // for each prime
                            for(int bufIdx = 0 ; bufIdx < primesRead ; bufIdx++ )
                            {
                                // terminate
                                if(buf[bufIdx].prime == 0) {
                                    lNodeArray[processIdx].wNodeTimes[timeIdx[processIdx]++] = buf[bufIdx].time;
                                    continue;
                                }
                                if(buf[bufIdx].prime == -1) {
                                    lNodeArray[processIdx].minRunTime = buf[bufIdx].time;
                                    continue;
                                }
                                if(buf[bufIdx].prime == -2)
                                {
                                    // printf("Done Node: %d\n", processIdx);
                                    lNodeArray[processIdx].maxRunTime = buf[bufIdx].time;

                                    donecount++;
                                    lNodeArray[processIdx].done = 1;
                                    close(fd[processIdx * 2]);
                                    close(fd[processIdx * 2 + 1]);
                                    break;
                                }
                                else {
                                    addPrimeToList(buf[bufIdx]);
                                    incrementLNodeNumberCount(processIdx);
                                }
                            }
                        }
                    }
                    else{
                        // printf("Not Ready Node: %d\n", processIdx);
                    }
                }
                else
                {
                    printf("Still Sending/Receiving in lNode with id: |%d|, Please wait....\n", lNodeArray[processIdx].pid);
                }
            }
        }
    }
    free(timeIdx);
    printStatistics(n);
    // sleep(2);
    return 1;
}

void executeChild(int n, int start, int end, int* fd, int ppid, int loopcount)
{
    char nFactor[3];
    char startPos[20];
    char endPos[20];
    char parentProcessId[20];
    char loopCount[5];

    itos(n, nFactor);
    itos(start,startPos);
    itos(end, endPos);
    itos(ppid, parentProcessId);
    itos(loopcount, loopCount);

    char str_fd[3];
    str_fd[0] = fd[0];
    str_fd[1] = fd[1];
    str_fd[2] = '\0';

    int code = execl("./child","./child", nFactor, startPos, endPos, str_fd, parentProcessId, loopCount,NULL);
    // int code = execl("/home/dspanakis/Ergasia/child","./child", nFactor, startPos, endPos, str_fd, NULL);
    if(code == -1)
    {
        perror("errorrr\n");
    }
    exit(1);
}

// extern struct primeNode* primesArray = NULL;
// extern int primesArraySize = MSG_BUF;
// extern int primesCount = 0;

struct inputStruct inputInit(int argc, char *argv[])
{
    int foundArgs = 0;
    struct inputStruct input;

    if(argc != 7)
    {
        printf("Wrong usage: -lb [start] -ub [end] -w [branchFactor]!\n");
        exit(1);
    }
    // Process command line arguments list
    int i;
    for(i = 0; i < argc; i++)
    {
        // if agument -c found next argument is the config file name
        if(strcmp(argv[i],"-lb") == 0)
        {
            // Read from configuration file and set global variables
            input.startPrime = myAtoi(argv[i+1]);
            foundArgs++;
            break;
        }
    }
    for(i = 0; i < argc; i++)
    {
        if(strcmp(argv[i],"-ub") == 0)
        {
            input.endPrime = myAtoi(argv[i+1]);
            foundArgs++;
            break;                          
        }
    }

    for(i = 0; i < argc; i++)
    {
        if(strcmp(argv[i],"-w") == 0)
        {
            input.branchFactor = myAtoi(argv[i+1]);
            foundArgs++;
            break;                          
        }
    }
    if(foundArgs != 3)
    {
        printf("Wrong usage: -lb [start] -ub [end] -w [branchFactor]!\n");
        exit(1);
    }
    if(input.startPrime <= 0)
    {
    	printf("Wrong usage: -lb  XX > 0!\n");
        exit(1);
    }
    if(input.endPrime < input.startPrime)
    {
        printf("Wrong usage: Lower bound is bigger than Upper bound\n");
        exit(1);
    }

    return input;
}


//Those vars are coming from fatherChildSharedFunctions.c
// struct primeNode* primesArray = NULL;
// int primesArraySize = MSG_BUF;
// int primesCount = 0;

int main(int argc, char* argv[]) 
{ 
    // printf("HEAD\n");

    struct inputStruct input = inputInit(argc,argv);

    int n = input.branchFactor; // Branching factor
    int start = input.startPrime; //Prime start
    int end = input.endPrime; //Prime end

    initialise(n, start, end); //Initialise lWnodes
    primeListInit(); //Initialise resList in fatherChildSharedFunctions.c

    // signal(SIGUSR1, signal_handler);
    struct sigaction action;

    action.sa_flags = SA_SIGINFO; 
    action.sa_handler = &sigusr1;

    if (sigaction(SIGUSR1, &action, NULL) == -1) { 
        perror("sigusr: sigaction");
        _exit(1);
    }

    

    // Create pipes for communication
    int* fd = malloc(2*n*sizeof(int));
    for(int i = 0 ; i < n ; i++)
    {
        pipe(fd+2*i);
        // if (fcntl(*(fd+2*i), F_SETFL, O_NONBLOCK) < 0) 
        //     exit(2); 
    }


    pid_t pid;
    int parentProcessId = getpid();
    for(int i = 0; i < n ; i++)
    {
        pid = fork();

        if(pid == -1)
        {
            printf("Error");
            exit(1);
        }
        if(pid != 0) // Parent Process
        {
            // wait(NULL);
            lNodeArray[i].pid = pid;
        }
        if(pid == 0) // Child Process
        {
            executeChild(n, lNodeArray[i].start, lNodeArray[i].end, &fd[2*i], parentProcessId, i);
        }
    }
    if(pid != 0)
    {
        
        executeParent(n, fd);
        // executeParent(n, lNodeArray, fd);
        free(primesArray);
        for(int i = 0 ; i < n; i++)
        {
            free(lNodeArray[i].wNodeTimes);
        }
        free(lNodeArray);
        free(fd);

        printf("Exiting program....\n");
        exit(1);
    }


}