#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "header_primeNodeStruct.h"
#include "header_msgbuf.h"

struct primeNode* primesArray = NULL;
int primesArraySize = MSG_BUF;
int primesCount = 0;

void primeListInit()
{
	primesArray = malloc(MSG_BUF*sizeof(struct primeNode));
}

void addPrimeToList(struct primeNode primeNd)
{
	primesArray[primesCount].prime = primeNd.prime;
	primesArray[primesCount].time = primeNd.time;
	primesCount++;
	
	if(primesCount == primesArraySize + 1)
	{
		// printf("must resize array with new Size = %d!\n", 2*primesArraySize);

		struct primeNode* newList = realloc(primesArray, 2*primesArraySize*sizeof(struct primeNode));
		primesArray = newList;
		primesArraySize = 2*primesArraySize;
	}
}

void swap(struct primeNode *xp, struct primeNode *yp)  
{  
    struct primeNode temp = *xp;  
    *xp = *yp;  
    *yp = temp;  
}  
  
// A function to implement bubble sort  
void bubbleSort(int primesCount)  
{  
    int i, j;  
    for (i = 0; i < primesCount-1; i++)      
      
    // Last i elements are already in place  
    for (j = 0; j < primesCount-i-1; j++)  
        if (primesArray[j].prime > primesArray[j+1].prime)  
            swap(&primesArray[j], &primesArray[j+1]);  
}  

void printPrimes()
{
	printf("-------------Print-------------\n");
	printf("Printing primes found...\n");
	for(int i = 0; i < primesCount; i++)
	{
		printf("Found |%d|", primesArray[i].prime);
		double time = ((double)primesArray[i].time/(double) 1000);
		printf("in |%.3f| seconds ", time);
		printf("\n");
	}
	printf("--------------End--------------\n");
}

void reverse(char s[])
 {
     int i, j;
     char c;

     for (i = 0, j = strlen(s)-1; i<j; i++, j--) {
         c = s[i];
         s[i] = s[j];
         s[j] = c;
     }
}  
 /* itoa:  convert n to characters in s */
void itos(int n, char s[])
{
    int i, sign;

    if ((sign = n) < 0)  /* record sign */
        n = -n;          /* make n positive */
    i = 0;
    do 
    {       /* generate digits in reverse order */
        s[i++] = n % 10 + '0';   /* get next digit */
    } 
    while ((n /= 10) > 0);     /* delete it */
    if (sign < 0)
        s[i++] = '-';
    s[i] = '\0';
    reverse(s);
} 

int myAtoi(char* str)
{
    // Initialize result
    int res = 0;
    for (int i = 0; str[i] != '\0'; ++i)
        res = res * 10 + str[i] - '0';
    return res;
}

