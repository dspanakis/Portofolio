#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <sys/stat.h> 
#include <sys/types.h> 
#include <fcntl.h>
#include <signal.h>
#include <poll.h>

#include "header_primeNodeStruct.h"
#include "header_msgbuf.h"

extern int primesCount;
extern struct primeNode* primesArray;

void bubbleSort(int );
void primeListInit();
void addPrimeToList(struct primeNode );
void printPrimes();

void reverse(char* );
void itos(int , char* );
int myAtoi(char* );