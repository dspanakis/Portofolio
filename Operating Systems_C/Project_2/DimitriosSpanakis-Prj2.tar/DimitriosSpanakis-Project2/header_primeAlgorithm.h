#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/times.h>
#include <signal.h>
#include <string.h>
#include <math.h>

#define YES 1
#define NO  0

#define TRUE 1
#define FALSE 0

extern unsigned int start, end;
extern int fd[2]; 

void init(int , char*[]);
void sendPrimes();
void foundPrime(int );
void terminate();