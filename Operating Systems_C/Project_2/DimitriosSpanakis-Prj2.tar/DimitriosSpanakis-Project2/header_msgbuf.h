// Default buffer size (in elements, not bytes)
#define MSG_BUF 256