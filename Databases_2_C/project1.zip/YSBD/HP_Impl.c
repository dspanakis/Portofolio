#include "BF.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define NULL_PTR -1
#define NULL_ID -1

typedef struct {

    int nextBlock;
    int entries;

} blockInfo;

typedef struct {

    char fileType;
    int fileDesc;
    char attrType;
    char *attrName;
    int attrLength;
    int nextBlock;

} HP_info;

typedef struct {

    int id;
    char name[15];
    char surname[25];
    char address[50];

} Record;

int HP_CreateFile(char *fileName, char attrType, char *attrName, int attrLength) {

    int fp, blockID;
    void *block;

    if (BF_CreateFile(fileName) < 0)
        return -1;

    if ((fp = BF_OpenFile(fileName)) < 0)
        return -1;

    HP_info init = {'h', fp, attrType, attrName, attrLength, NULL_PTR};
    //Create the first block having hp_info
    if (BF_AllocateBlock(fp) < 0)
        return -1;

    blockID = BF_GetBlockCounter(fp) - 1;

    if (BF_ReadBlock(fp, blockID, &block) < 0)
        return -1;

    memcpy(block, (void *) &init, sizeof(HP_info));

    if(BF_WriteBlock(fp, blockID) < 0)
        return -1;

    if (BF_CloseFile(fp) < 0)
        return -1;

    return 0;

}

HP_info *HP_OpenFile(char *fileName) {

    int fp;
    void *block;

    if ((fp = BF_OpenFile(fileName)) < 0)
        return NULL;

    if (BF_ReadBlock(fp, 0, &block) < 0)
        return NULL;

    HP_info* temp = (HP_info*) block;
    HP_info *info = (HP_info *) malloc(sizeof(HP_info));
    info->fileType = temp->fileType;
    info->fileDesc = fp;
    info->attrType = temp->attrType;
    info->attrName = temp->attrName;
    info->attrLength = temp->attrLength;
    info->nextBlock = temp->nextBlock;

    if(info->fileType != 'h') {

        free(info);

        return NULL;

    }

    return info;

}

int HP_CloseFile(HP_info* header_info) {

    if (BF_CloseFile(header_info->fileDesc) < 0)
        return -1;

    free(header_info);

    return 0;

}

int HP_FindEntry(HP_info *header_info, Record record) {

    int blockCount = BF_GetBlockCounter(header_info->fileDesc), nextBlock;
    blockInfo initInfo;
    Record *records = NULL;
    void *block;
    // If we only have one block the entry is for sure not in the heap
    if (blockCount == 1)
        return -1;

    nextBlock = header_info->nextBlock;
    // For all blocks
    while(nextBlock != NULL_PTR) {
        // Read next block
        if (BF_ReadBlock(header_info->fileDesc, nextBlock, &block) < 0)
            return -1;
        // Copy basic info of block to blockInfo
        memcpy((void *) &initInfo, block, sizeof(blockInfo));
        // Analyse basic block info
        //Loop through the block record's
        int blockSize = (BLOCK_SIZE - sizeof(blockInfo)) / sizeof(Record);
        records = (Record *) malloc(blockSize * sizeof(Record));

        memcpy((void *) records, block + sizeof(blockInfo), blockSize * sizeof(Record));

        for (int i = 0 ; i < blockSize ; i++) {

            if (records[i].id == record.id) {

                free(records);

                return nextBlock;

            }

        }
        // Go to the next block
        nextBlock = initInfo.nextBlock;

        free(records);

    }

    return -1;

}

int HP_InsertEntry(HP_info *header_info, Record record) {

    int blockCount = BF_GetBlockCounter(header_info->fileDesc), nextBlock, entries;
    blockInfo *initInfo = (blockInfo *) malloc(sizeof(blockInfo));
    Record *records = NULL;
    void *block;

    if(HP_FindEntry(header_info, record) >= 0)
         return -1;

    if (blockCount == 1) { // && ->entries == BLOCK_SIZE
        // Connect to first block (info block)
        BF_ReadBlock(header_info->fileDesc, 0, &block);
        // Allocate a new block
        if ((BF_AllocateBlock(header_info->fileDesc)) < 0)
            return -1;
        // Get id of new block
        header_info->nextBlock = BF_GetBlockCounter(header_info->fileDesc) - 1;
        // Copy id of new block to pointer
        memcpy(block, (void *) header_info, sizeof(HP_info));
        // Write changes
        if(BF_WriteBlock(header_info->fileDesc, 0) < 0)
            return -1;
        // Read the new block
        if (BF_ReadBlock(header_info->fileDesc, header_info->nextBlock, &block) < 0)
            return -1;
        // Setup and copy basic block info
        blockInfo dummyInfo = {NULL_PTR, 1};
        memcpy(block, (void *) &dummyInfo, sizeof(blockInfo));
        // Copy record to block
        memcpy(block + sizeof(blockInfo), (void *) &record, sizeof(Record));
        // Write data to block
        if(BF_WriteBlock(header_info->fileDesc, header_info->nextBlock) < 0)
            return -1;

        free(initInfo);
        // Return success
        return header_info->nextBlock;

    }

    int prevBlock;
    nextBlock = header_info->nextBlock;
    // Parse all blocks
    while(nextBlock != NULL_PTR) {
        // Read next block
        if (BF_ReadBlock(header_info->fileDesc, nextBlock, &block) < 0)
            return -1;
        // Copy basic info of block to blockInfo
        memcpy((void *) initInfo, block, sizeof(blockInfo));
        // Analyse basic block info
        entries = initInfo->entries;
        // Case where the block has empty spaces (1 more entry can fit)
        if((entries + 1) * sizeof(Record) + sizeof(blockInfo) <= BLOCK_SIZE) {
            // Get records array
            records = (Record *) malloc((entries + 1) * sizeof(Record));
            memcpy((void *) records, block + sizeof(blockInfo), (entries + 1) * sizeof(Record));
            // Parse records
            for(int i = 0 ; i < entries + 1 ; i++) {
                // If we find the empty space
                if (records[i].id == 0) {
                    // increment entries
                    initInfo->entries++;
                    // Copy changes to block
                    memcpy(block, (void *) initInfo, sizeof(blockInfo));

                    memcpy(block + i * sizeof(Record) + sizeof(blockInfo), (void *) &record, sizeof(Record));

                    free(records);
                    free(initInfo);

                    // Save changes
                    if(BF_WriteBlock(header_info->fileDesc, nextBlock) < 0)
                        return -1;

                    return nextBlock;

                }

            }

            free(records);

        }
        // Get to the next block
        prevBlock = nextBlock;
        nextBlock = initInfo->nextBlock;

    }
    // If we didnt find space to save the record
    if(BF_AllocateBlock(header_info->fileDesc) < 0)
        return -1;
    // Generate new block
    initInfo->nextBlock = BF_GetBlockCounter(header_info->fileDesc) - 1;
    //Save the initialise infos
    memcpy(block, (void*) initInfo, sizeof(blockInfo));

    if(BF_WriteBlock(header_info->fileDesc, prevBlock) < 0)
        return -1;
    // Allocate a new block
    if (BF_ReadBlock(header_info->fileDesc, initInfo->nextBlock, &block) < 0)
        return -1;
    // Setup and copy basic block info on new block
    blockInfo initInfoNew = {NULL_PTR, 1};
    memcpy(block, (void*) &initInfoNew, sizeof(blockInfo));

    memcpy(block + sizeof(blockInfo), (void *) &record, sizeof(Record));

    if(BF_WriteBlock(header_info->fileDesc, initInfo->nextBlock) < 0)
        return -1;

    free(initInfo);

    return initInfoNew.nextBlock;  // Return block ID

}

int HP_DeleteEntry(HP_info *header_info, void* value) {

    Record dummy = {*(int *) value};
    int blockID = HP_FindEntry(header_info, dummy);
    void *block;

    if(blockID == -1)
        return -1;

    if(BF_ReadBlock(header_info->fileDesc, blockID, &block) < 0)
        return -1;

    blockInfo *initInfo = malloc(sizeof(blockInfo));
    memcpy((void *) initInfo, block, sizeof(blockInfo));
    // Find block entries

    int blockSize = (BLOCK_SIZE - sizeof(blockInfo)) / sizeof(Record);
    Record *records = malloc(blockSize * sizeof(Record));
    memcpy((void *) records, block + sizeof(blockInfo), blockSize * sizeof(Record));
    // Parse all entries
    for(int i = 0 ; i < blockSize; i++) {
        // If we find what we wanted
        if (records[i].id == *(int *) value) {

            initInfo->entries--;
            memcpy(block, (void *) initInfo, sizeof(blockInfo));
            // DMark this record as deleted
            records[i].id = 0;
            strcpy(records[i].name, "\0");
            strcpy(records[i].surname, "\0");
            strcpy(records[i].address, "\0");
            //Save changes
            memcpy(block + sizeof(blockInfo), (void *) records, blockSize * sizeof(Record));

            if(BF_WriteBlock(header_info->fileDesc, blockID) < 0)
                return -1;

            free(records);
            free(initInfo);

            return 0;

        }

    }

    return -1;

}

int HP_GetAllEntries(HP_info *header_info, void* value) {

    int blockCount = BF_GetBlockCounter(header_info->fileDesc), nextBlock, counter = 0;
    blockInfo *initInfo = (blockInfo *) malloc(sizeof(blockInfo));
    Record *records;
    void *block;
    // If we only have one block the entry is for sure not in the heap
    if (blockCount == 1)
        return -1;
    nextBlock = header_info->nextBlock;
    // For all blocks
    while(nextBlock != NULL_PTR) {
        // Read next block
        if (BF_ReadBlock(header_info->fileDesc, nextBlock, &block) < 0)
            return -1;
        // Copy basic info of block to blockInfo
        memcpy((void *) initInfo, block, sizeof(blockInfo));
        // Analyse basic block info
        nextBlock = initInfo->nextBlock;
        // entries = initInfo->entries;
        //Loop through the block record's
        int blockSize = (BLOCK_SIZE - sizeof(blockInfo)) / sizeof(Record);
        records = malloc(blockSize * sizeof(Record));
        memcpy((void *) records, block + sizeof(blockInfo), blockSize * sizeof(Record));
        for (int i = 0 ; i < blockSize ; i++) {

                if (header_info->attrType == 'i') {  // value is int

                    if (records[i].id == *((int *) value))
                        printf("%d %s %s %s\n", records[i].id, records[i].name, records[i].surname, records[i].address);

                } else if (header_info->attrType == 'c') { // value is char *

                    if (records[i].id == *((int *) value))
                        printf("%d %s %s %s\n", records[i].id, records[i].name, records[i].surname, records[i].address);

                }

        }
        // Increment block counter
        counter++;

        free(records);

    }

    free(initInfo);

    return counter;

}

void inputReader(char* filename, HP_info* heapInfo) {

    FILE *fp = fopen(filename, "r");
    int i;
    char lineRead[200], *token[4];
    Record newRecord;

    while (fgets(lineRead, 200, fp) != NULL) {

        token[i = 0] = strtok(lineRead, ",{");

        while(token != NULL && i < 3)
            token[++i] = strtok(NULL, ",{}\"");

        newRecord.id = atoi(token[0]);
        strcpy(newRecord.name, token[1]);
        strcpy(newRecord.surname, token[2]);
        strcpy(newRecord.address, token[3]);

        printf("Inserting entry with data: %d, %s %s %s\n", newRecord.id, newRecord.name, newRecord.surname, newRecord.address);

        HP_InsertEntry(heapInfo, newRecord);

    }

    fclose(fp);

}

int main() {

    BF_Init();

    HP_CreateFile("HEAP", 'i', "tempHP", 60);

    HP_info *info = HP_OpenFile("HEAP");

    inputReader("records1K.txt", info);

    for (int i = 1 ; i < 1000 ; i++)
        HP_GetAllEntries(info, (void *) &i);

    printf("-- Deleting...\n");

    for (int i = 1 ; i < 1000 ; i++)
        HP_DeleteEntry(info, (void *) &i);

    printf("-- Print after delete:\n");

    for (int i = 1 ; i < 1000 ; i++)
        HP_GetAllEntries(info, (void *) &i);

    HP_CloseFile(info);

}
