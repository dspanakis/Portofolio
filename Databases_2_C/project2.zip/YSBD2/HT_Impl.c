#include "BF.h"
#include "HT_Types.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define NULL_PTR -1
#define NULL_ID -1
#include <math.h>

int h(int id, int size) { return id % size;}

int HT_CreateIndex(char *fileName, char attrType, char *attrName, int attrLength, int buckets) {

	int fp, remainingBuckets = buckets, lastHashBlockID, thisBuckets;
    int blocksNeeded = (buckets * sizeof(int)) / (BLOCK_SIZE - sizeof(HT_info)) + 1, blockBucketCount = (BLOCK_SIZE - sizeof(HT_info)) / sizeof(int), *hashTable = (int *) malloc(blockBucketCount * sizeof(int));
    void *block;

    if (BF_CreateFile(fileName) < 0)
        return -1;

    if ((fp = BF_OpenFile(fileName)) < 0)
        return -1;

    if (BF_AllocateBlock(fp) < 0)
        return -1;
    // Make hash table from blocks
    for (int i = 0 ; remainingBuckets > 0 ; i++) {

        lastHashBlockID = BF_GetBlockCounter(fp) - 1;
        // Block Generation
        if (BF_ReadBlock(fp, lastHashBlockID, &block) < 0)
            return -1;
        // Calculate this hash table block's buckets
        if(remainingBuckets > blockBucketCount)
            thisBuckets = blockBucketCount;
        else
            thisBuckets = remainingBuckets;
        // Set ht info
        HT_info init = {'t', fp, attrType, attrName, attrLength, thisBuckets, buckets, BF_GetBlockCounter(fp) - 1, NULL_PTR};
        // Decrement remaining buckets to assign
        remainingBuckets -= thisBuckets;
        //Initialise block indexes
        for(int j = 0 ; j < init.numBuckets ; j++) {
            // Allocate a block for this index
            if (BF_AllocateBlock(fp) < 0)
                return -1;
            // Assign index to block
            hashTable[j] = BF_GetBlockCounter(fp) - 1;
            // Read the block
            if (BF_ReadBlock(fp, hashTable[j], &block) < 0)
                return -1;
            // Copy info block
            int info[2] = {NULL_PTR, 0};
            memcpy(block, (void *) info, sizeof(info));
            // Write changes
            if(BF_WriteBlock(fp, hashTable[j]) < 0)
                return -1;

        }
        // Open last hash block
        if (BF_ReadBlock(fp, lastHashBlockID, &block) < 0)
            return -1;
        // Save hash table part on tblock
        memcpy(block + sizeof(HT_info), (void *) hashTable,  init.numBuckets * sizeof(int));
        // If this isn't the last loop (last hash block), link hash block pointers
        if(i != blocksNeeded - 1) {

            if (BF_AllocateBlock(fp) < 0)
                return -1;

            init.nextHashBlock = BF_GetBlockCounter(fp) - 1;

        }
        // Copy changes
        memcpy(block, (void*) &init, sizeof(init));
        // Save to disk
        if(BF_WriteBlock(fp, lastHashBlockID) < 0)
            return -1;

    }

    BF_CloseFile(fp);

    free(hashTable);

    return 0;

}

HT_info *HT_OpenIndex(char *fileName) {

    int fp;
    void *block;

    if ((fp = BF_OpenFile(fileName)) < 0)
        return NULL;

    if (BF_ReadBlock(fp, 0, &block) < 0)
        return NULL;
    // Create a new info "copy" and return
    HT_info* temp = (HT_info*) block;
    HT_info *info = (HT_info *) malloc(sizeof(HT_info));
    //Copy pointers
    info->fileType = temp->fileType;
    info->fileDesc = fp;
    info->attrType = temp->attrType;
    info->attrName = temp->attrName;
    info->attrLength = temp->attrLength;
    info->numBuckets = temp->numBuckets;
    info->totalBuckets = temp->totalBuckets;
    info->initBlockID = temp->initBlockID;
    info->nextHashBlock = temp->nextHashBlock;

    if(info->fileType != 't') {

        free(info);

		if ((fp = BF_CloseFile(fp)) < 0)
	        return NULL;

        return NULL;

    }

    return info;

}

int HT_CloseIndex(HT_info *header_info) {

    if (BF_CloseFile(header_info->fileDesc) < 0)
        return -1;
    // Free allocated space
    free(header_info);

    return 0;

}

int HT_FindEntry(HT_info *header_info, Record record) {

    int *hashTable = (int *) malloc(header_info->totalBuckets * sizeof(int));
    int hashKey = h(record.id, header_info->totalBuckets), currBlock = header_info->initBlockID, index = 0;;
    void *block;
    HT_info currHeaderInfo;
    // Parse all ht blocks to read hash table from disk
    while(currBlock != NULL_PTR) {
        // Read current block
        if(BF_ReadBlock(header_info->fileDesc, currBlock, &block) < 0)
            exit(-1);
        // Get ht info for use
        memcpy(&currHeaderInfo, block, sizeof(HT_info));
        // Copy data to ht
        memcpy(&hashTable[index], block + sizeof(HT_info), currHeaderInfo.numBuckets * sizeof(int));
        // Increment hash table index location based on number of buckets copied over
        index += currHeaderInfo.numBuckets;
        // Update currBlock to next block
        currBlock = ((HT_info *) block)->nextHashBlock;

    }
    // Find hashTagle[hashKey]
    int recordsBlockID = hashTable[hashKey];
    int blockSize = (BLOCK_SIZE - 2 * sizeof(int)) / sizeof(Record);
    // Loop through record blocks of hashIndex
    while(recordsBlockID != NULL_PTR) {

        if (BF_ReadBlock(header_info->fileDesc, recordsBlockID, &block) < 0)
            exit(-1);

        int nextRecordsBlockID;
        memcpy(&nextRecordsBlockID, block, sizeof(int));
        int recordsCount;
        memcpy(&recordsCount, block + sizeof(int), sizeof(int));
        // Check all records of current block
        for(int i = 0 ; i < blockSize ; i++) {

            if (((Record *) (block + 2 * sizeof(int) + i * sizeof(Record)))->id == record.id ) {

                if (BF_WriteBlock(header_info->fileDesc, recordsBlockID) < 0)
                    exit(-1);

                free(hashTable);

                return recordsBlockID;

            }


        }

        if (BF_WriteBlock(header_info->fileDesc, recordsBlockID) < 0)
            exit(-1);
        // Move to next block
        recordsBlockID = nextRecordsBlockID;

    }

    free(hashTable);

    return -1;

}

int HT_InsertEntry(HT_info *header_info, Record record) {
    // Check if this entry exists
    if(HT_FindEntry(header_info, record) != -1)
        return -1;

    int *hashTable = (int *) malloc(header_info->totalBuckets * sizeof(int));
    int hashKey = h(record.id, header_info->totalBuckets);
    int blockToRead = header_info->initBlockID;
    int index = 0;
    void *block;
    HT_info currHeaderInfo;
    // Load ht
    while(blockToRead != NULL_PTR) {

        if(BF_ReadBlock(header_info->fileDesc, blockToRead, &block) < 0)
            return -1;

        memcpy(&currHeaderInfo, block, sizeof(HT_info));
        memcpy(&hashTable[index], block + sizeof(HT_info), currHeaderInfo.numBuckets * sizeof(int));
        index += currHeaderInfo.numBuckets;

        blockToRead = ((HT_info *) block)->nextHashBlock;

    }

    int nextBlock;
    int prevBlock;
    int currBlock = hashTable[hashKey];
    int blockCapacity;  // How many records are currently in a block
    int blockSize = (BLOCK_SIZE - 2 * sizeof(int)) / sizeof(Record);// How many records can fit in a block
    // Parse all blocks
    while(currBlock != NULL_PTR) {
        // Read next block
        if(BF_ReadBlock(header_info->fileDesc, currBlock, &block) < 0)
            return -1;

        memcpy((void*) &nextBlock, (void *) block, sizeof(int));

        int recordsCount;
        memcpy((void *) &recordsCount, (void *) (block + sizeof(int)), sizeof(int));

        blockCapacity = recordsCount * sizeof(Record) + 2 * sizeof(int);
        // Case where the block has empty spaces
        if(blockCapacity <= BLOCK_SIZE - sizeof(Record)) {
            // Loop through records
            int i;
            for(i = 0 ; i < blockSize ; i++) {
                // If we find an empty space
                if (((Record *) (block + 2 * sizeof(int) + i * sizeof(Record)))->id == NULL_ID || ((Record *) (block + 2 * sizeof(int) + i * sizeof(Record)))->id == 0) {
                    // Up records counter and write updated info
                    recordsCount++;
                    memcpy(block + sizeof(int), (void *) &recordsCount, sizeof(int));

                    memcpy(block + 2 * sizeof(int) + i * sizeof(Record), (void *) &record, sizeof(Record));

                    if(BF_WriteBlock(header_info->fileDesc, currBlock) < 0)
                        return -1;

                    free(hashTable);

                    return currBlock;

                }

            }
            // Error
            return -1;

        }
        // Get to the next block
        prevBlock = currBlock;
        currBlock = nextBlock;

    }
    // Here we need to create a new overflow block
    if(BF_AllocateBlock(header_info->fileDesc) < 0)
        return -1;

    int newBlock = BF_GetBlockCounter(header_info->fileDesc) - 1;

    if (BF_ReadBlock(header_info->fileDesc, prevBlock, &block) < 0)
        return -1;

    memcpy(block, (void*) &newBlock, sizeof(int));

    if(BF_WriteBlock(header_info->fileDesc, prevBlock) < 0)
        return -1;
    // Allocate a new block
    if (BF_ReadBlock(header_info->fileDesc, newBlock, &block) < 0)
        return -1;
    // Setup and copy basic block info on new block
    int initInfoNew[2] = {NULL_PTR, 1};
    memcpy(block, (void*) initInfoNew, 2 * sizeof(int));

    memcpy(block + 2 * sizeof(int), (void *) &record, sizeof(Record));

    if(BF_WriteBlock(header_info->fileDesc,newBlock) < 0)
        return -1;

    free(hashTable);

    return newBlock;  // Return block ID

}

int HT_DeleteEntry(HT_info *header_info, void *value) {

    void* block;
    Record dummyRecord = {*(int*) value};
    int recordsBlockID;
    // Check if entry already exists
    if ((recordsBlockID = HT_FindEntry(header_info, dummyRecord)) == -1)
        return -1;

    if (BF_ReadBlock(header_info->fileDesc, recordsBlockID, &block) < 0)
        return -1;
    // Read block info
    int nextRecordsBlockID;
    memcpy(&nextRecordsBlockID, block, sizeof(int));
    int recordsCount;
    memcpy(&recordsCount, block + sizeof(int), sizeof(int));
    int blockSize = (BLOCK_SIZE - 2 * sizeof(int)) / sizeof(Record);
    // Find the correct record
    for(int i = 0 ; i < blockSize ; i++) {

        if (((Record *) (block + 2 * sizeof(int) + i * sizeof(Record)))->id == *(int *) value) {
            // Replace record with a deleted value one
            Record deletedRecord = {NULL_ID, "\0", "\0", "\0"};
            memcpy(block + 2 * sizeof(int) + i * sizeof(Record), (void *) &deletedRecord, sizeof(Record));
            // Decrement records counter
            recordsCount--;
            // Copy changes on block
            memcpy(block + sizeof(int), (void*) &recordsCount, sizeof(int));
            // Succesful
            return 0;

        }

    }

    if (BF_WriteBlock(header_info->fileDesc, recordsBlockID) < 0)
        return -1;

    return -1;

}

int HT_GetAllEntries( HT_info *header_info, void *value) {

    int *hashTable = (int *) malloc(header_info->totalBuckets * sizeof(int));
    int hashKey = *(int *) value % header_info->totalBuckets;
    int currBlock = header_info->initBlockID;
    int index = 0;
    HT_info currHeaderInfo;
    void *block;
    // Load the whole ht
    while(currBlock != NULL_PTR) {

        if(BF_ReadBlock(header_info->fileDesc, currBlock, &block) < 0)
            return -1;

        memcpy(&currHeaderInfo, block, sizeof(HT_info));

        memcpy(&hashTable[index], block + sizeof(HT_info), currHeaderInfo.numBuckets * sizeof(int));
        index += currHeaderInfo.numBuckets;

        if (BF_WriteBlock(header_info->fileDesc, currBlock) < 0)
            return -1;

        currBlock = currHeaderInfo.nextHashBlock;

    }
    // Get the block id fromt he hashtable
    int recordsBlockID = hashTable[hashKey], counter = 1;
    int blockSize = (BLOCK_SIZE - 2 * sizeof(int)) / sizeof(Record);
    // Parse all blocks in this bucket
    while(recordsBlockID != NULL_PTR) {

        if (BF_ReadBlock(header_info->fileDesc, recordsBlockID, &block) < 0)
            return -1;

        int nextRecordsBlockID;
        memcpy(&nextRecordsBlockID, block, sizeof(int));
        int recordsCount;
        memcpy(&recordsCount, block + sizeof(int), sizeof(int));

        for(int i = 0 ; i < blockSize ; i++) {

            if (((Record *) (block + 2 * sizeof(int) + i * sizeof(Record)))->id == *(int *) value ) {

                Record *tempRecord = (Record *) (block + 2 * sizeof(int) + i * sizeof(Record));

                printf("|ID|:%d |NAME|:%s |SURNAME|:%s |ADDRESS|:%s\n", tempRecord->id, tempRecord->name, tempRecord->surname, tempRecord->address);

                free(hashTable);
                return counter;

            }

        }

        if (BF_WriteBlock(header_info->fileDesc, recordsBlockID) < 0)
            return -1;

        recordsBlockID = nextRecordsBlockID;
        // Increment blocks read counter
        counter++;

    }

    free(hashTable);

    return -1;

}

void inputReader(char* filename, HT_info* hashTableInfo) {

    FILE *fp = fopen(filename, "r");
    int i;
    char lineRead[200], *token[4];
    Record newRecord;
    // Read each line
    while (fgets(lineRead, 200, fp) != NULL) {

        token[i = 0] = strtok(lineRead, ",{");
        // Seperate words
        while(token != NULL && i < 3)
            token[++i] = strtok(NULL, ",{}\"");
        // Insert data to a record
        newRecord.id = atoi(token[0]);
        strcpy(newRecord.name, token[1]);
        strcpy(newRecord.surname, token[2]);
        strcpy(newRecord.address, token[3]);

        printf("Inserting entry with data: %d, %s %s %s\n", newRecord.id, newRecord.name, newRecord.surname, newRecord.address);

        HT_InsertEntry(hashTableInfo, newRecord);

    }

    fclose(fp);

}

int HTStatistics(char* fileName) {

    void *block;
    HT_info *info = HT_OpenIndex(fileName);

    if (BF_ReadBlock(info->fileDesc, info->initBlockID, &block) < 0)
        return -1;

    int blocksCount = BF_GetBlockCounter(info->fileDesc);

    printf("File's total blocks are %d\n", blocksCount); // (alpha)
    // Import ht
    int *hashTable = (int *) malloc(info->totalBuckets * sizeof(int));
    int currBlock = info->initBlockID;
    int index = 0;
    HT_info currHeaderInfo;
    // Load the whole ht
    while(currBlock != NULL_PTR) {

        if(BF_ReadBlock(info->fileDesc, currBlock, &block) < 0)
            return -1;

        memcpy(&currHeaderInfo, block, sizeof(HT_info));

        memcpy(&hashTable[index], block + sizeof(HT_info), currHeaderInfo.numBuckets * sizeof(int));
        index += currHeaderInfo.numBuckets;

        if (BF_WriteBlock(info->fileDesc, currBlock) < 0)
            return -1;

        currBlock = currHeaderInfo.nextHashBlock;

    }

    int blockCounter = 0;
    int desc = info->fileDesc;
    long int totalBuckets = info->totalBuckets;
    int blocksWithOverflow = 0;
    int minRecords = 0, maxRecords = 0, totalRecords = 0, flag = 0;
    // Parse ht
    for(int i = 0 ; i < totalBuckets ; i++) {

        int currRecordsBlock = hashTable[i];
        int recordsBlockCount = 0;
        int currentSum = 0;
        // Parse ht buckets
        while(currRecordsBlock != NULL_PTR) {

            recordsBlockCount++;

            if(BF_ReadBlock(desc, currRecordsBlock, &block) < 0)
                return -1;

            int nextRecordsBlockID;
            memcpy(&nextRecordsBlockID, block, sizeof(int));
            int recordsCount;
            memcpy(&recordsCount, block + sizeof(int), sizeof(int));

            currentSum += recordsCount;

            if(BF_WriteBlock(desc, currRecordsBlock) < 0)
                return -1;

            currRecordsBlock = nextRecordsBlockID;

        }
        // Find total records
        totalRecords += currentSum;
        // Determine min max
        if(flag == 0) {

            minRecords = currentSum;
            maxRecords = currentSum;
            flag++;

        } else {

            if(currentSum > maxRecords)
                maxRecords = currentSum;
            else if(currentSum < minRecords)
                minRecords = currentSum;

        }

        blockCounter += recordsBlockCount;

        if(recordsBlockCount > 1) {

            blocksWithOverflow++;

            printf("Bucket with index |%d| has |%d| overflow blocks\n", i, recordsBlockCount - 1);  // (delta)

        }

    }

    printf("MIN: %d, MAX: %d, AVERAGE: %f\n", minRecords, maxRecords, totalRecords / (double) totalBuckets);    // (beta)

    printf("Number of buckets that have overflow blocks |%d|\n", blocksWithOverflow); // (delta)

    printf("Average number of blocks for buckets is |%.2f|\n", (double) blockCounter / totalBuckets); // (gamma)

    free(hashTable);

    HT_CloseIndex(info);

    return 0;

}

// int main(int argc, char* argv[]) {
//
//     BF_Init();
//
//     Ht_CreateIndex("HASHTABLE", 'i', NULL, 3, 200);
//
//     HT_info *info = HT_OpenIndex("HASHTABLE");
//
//     inputReader("records5K.txt", info);
//
//     for(int i = 1 ; i < 5000 ; i++)
//         HT_GetAllEntries(info, (void*) &i);
//
//     HashStatistics("HASHTABLE");
//
//     printf("-- Deleting...\n");
//
//     for (int i = 1 ; i < 5000 ; i++)
//         HT_DeleteEntry(info, (void *) &i);
//
//     printf("-- Print after delete:\n");
//
//     for (int i = 1 ; i < 5000 ; i++)
//         HT_GetAllEntries(info, (void *) &i);
//
//     HashStatistics("HASHTABLE");
//
//     HT_CloseIndex(info);
//
// }
