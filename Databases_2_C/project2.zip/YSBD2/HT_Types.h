typedef struct {

    char fileType;
    int fileDesc;
    char attrType;
    char *attrName;
    int attrLength;
    int numBuckets;

    long int totalBuckets;

    int initBlockID;
    int nextHashBlock;

} HT_info;

typedef struct {

    int id;
    char name[30];
    char surname[30];
    char address[30];

} Record;

int HT_CreateIndex(char *, char, char *, int, int);
HT_info *HT_OpenIndex(char *);
int HT_InsertEntry(HT_info *, Record);
int HT_CloseIndex(HT_info *);
int HT_GetAllEntries( HT_info *, void *);
int HTStatistics(char *);
