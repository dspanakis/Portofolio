#include "BF.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "HT_Types.h"

#define NULL_PTR -1

typedef struct {

	char fileType;
	int fileDesc;
	char *attrName;
	int attrLength;
	long int numBuckets; // Total Buckets
    char *fileName;

    int initBlockID;
    int nextHashBlock;

} SHT_info;

typedef struct {

 	Record record;
	int recordBlockID;

} SecondaryRecord;

typedef struct {

	char surname[50];
	int blockPtr;

} SecondaryBlockEntry;

int hash(char *str, int TABLESIZE) {	// Hash function for generating number from string -- taken from an old project

	int h = 0, a = 33;

	for (; *str != '\0' ; str++)
		h = (a*h + *str) % TABLESIZE;

	return h;

}
int SHT_CreateSecondaryIndex(char *sfileName, char* attrName, int attrLength, int buckets, char* fileName) {

    int fp;
    int remainingBuckets = buckets;
	int nullptr = NULL_PTR;
    void *block;
	//Create new file
    if(BF_CreateFile(sfileName) < 0)
        return -1;
	//Open new file
    if((fp = BF_OpenFile(sfileName)) < 0)
        return -1;
	// Allocate first block
    if(BF_AllocateBlock(fp) < 0)
        return -1;
	// Ititialise SHT_info
    SHT_info info = {'s', fp, attrName, attrLength, buckets, fileName, BF_GetBlockCounter(fp) - 1, NULL_PTR};
    /*
        Create ht
    */
	int *hashTable = (int *) malloc(buckets * sizeof(int));

    for(int i = 0 ; i < buckets; i++) {

        if(BF_AllocateBlock(fp) < 0)
            return -1;

        if(BF_ReadBlock(fp, BF_GetBlockCounter(fp) - 1, &block) < 0)
            return -1;

        hashTable[i] = BF_GetBlockCounter(fp) - 1;

        memcpy(block, (void *) &nullptr, sizeof(int));

        if(BF_WriteBlock(fp, BF_GetBlockCounter(fp) - 1) < 0)
            return -1;

    }
	// Read first block
    if(BF_ReadBlock(fp, info.initBlockID, &block) < 0)
        return -1;
	// Find how many indexes of HT_fit inside
    int firstBlockFit = (BLOCK_SIZE - sizeof(SHT_info)) / sizeof(int);
	// If buckets are less than fitting
    if(firstBlockFit > buckets)
        firstBlockFit = buckets;
	// Save SHT_info and first part of Hashtable
    memcpy(block + sizeof(SHT_info), (void *) hashTable, firstBlockFit * sizeof(int));
    memcpy(block, (void *) &info, sizeof(SHT_info));

    if(BF_WriteBlock(fp, info.initBlockID) < 0)
        return -1;
	// Decrement remaining buckets we have to save by firstBlockFit
	remainingBuckets -= firstBlockFit;
	// Find how many indexes fit in the next blocks after the first
    int otherBlocksFit = (BLOCK_SIZE - sizeof(int)) / sizeof(int);
	// Move index of our "local" ht that we have to save
    int curHashTableIndex = firstBlockFit;
	int prevBlock = info.initBlockID;
	int newBlock;
	// While we have to create more blocks to fit whole ht
    while(remainingBuckets > 0) {

        if(BF_AllocateBlock(fp) < 0)
            return -1;

        newBlock = BF_GetBlockCounter(fp) - 1;
		// Open prevBlock for linking
		if(BF_ReadBlock(fp, prevBlock, &block) < 0)
			return -1;
		// Change pointer to nextBlock
		if(prevBlock == info.initBlockID) {
			// Case we have to connect first with second block
			info.nextHashBlock = newBlock;
			memcpy(block, (void *) &info, sizeof(SHT_info));

		} else {
			// Case we have to connect other blocks
			memcpy(block, (void *) &newBlock, sizeof(int));

		}
		// Save chanegs to disk
		if (BF_WriteBlock(fp, prevBlock) < 0)
	        return -1;
		// Open new block
        if (BF_ReadBlock(fp, newBlock, &block) < 0)
            return -1;
		// Make its pointer to next block NULL_PTR
		memcpy(block, (void *) &nullptr, sizeof(int));
		// If remaining hashtable indexes are less than fitting ones
        if (otherBlocksFit > remainingBuckets)
            otherBlocksFit = remainingBuckets;
		// Copy this part of ht in newblock
        memcpy(block + sizeof(int), (void *) &hashTable[curHashTableIndex], otherBlocksFit * sizeof(int));
		// Save changes
		if (BF_WriteBlock(fp, newBlock) < 0)
	        return -1;
		// Shift local hashtable index
        curHashTableIndex += otherBlocksFit;
		remainingBuckets -= otherBlocksFit;
		// Move iteration to new block
		prevBlock = newBlock;

    }

    if(BF_CloseFile(fp) < 0)
    	return -1;

	free(hashTable);

	return 0;

}

SHT_info* SHT_OpenSecondaryIndex(char *sfileName) {

	int fp;
    void *block;
	// Open sfile
    if ((fp = BF_OpenFile(sfileName)) < 0)
        return NULL;

    if (BF_ReadBlock(fp, 0, &block) < 0)
        return NULL;
    // Create a new info "copy" and return
    SHT_info* temp = (SHT_info*) block;
    SHT_info *info = (SHT_info *) malloc(sizeof(SHT_info));
    //Copy pointers
    info->fileType = temp->fileType;
    info->fileDesc = fp;
    info->attrName = temp->attrName;
    info->attrLength = temp->attrLength;
    info->numBuckets = temp->numBuckets;
	info->fileName = temp->fileName;
    info->initBlockID = temp->initBlockID;
    info->nextHashBlock = temp->nextHashBlock;

    if(info->fileType != 's') {

        free(info);

		BF_CloseFile(fp);

        return NULL;

    }

    return info;

}

int SHT_CloseSecondaryIndex(SHT_info* header_info) {
	// Close file
	if (BF_CloseFile(header_info->fileDesc) < 0)
        return -1;
    // Free allocated space
    free(header_info);

    return 0;

}

int SHT_SecondaryInsertEntry(SHT_info header_info, SecondaryRecord secRecord) {
	// Make initial memory allocations
	void *block;
	int *hashTable = malloc(header_info.numBuckets * sizeof(int));
	// Read the first block (the one storing the first part of the hash table)
	if (BF_ReadBlock(header_info.fileDesc, header_info.initBlockID, &block) < 0)
		return -1;
	// Calculate how many indexes should be able to fit in that first block
	int firstBlockIndexes = (BLOCK_SIZE - sizeof(SHT_info)) / sizeof(int);
	// Modify firstBlockIndexes based on the total number of buckets (if we need to insert less)
	if (firstBlockIndexes > header_info.numBuckets)
		firstBlockIndexes = header_info.numBuckets;
	// Copy tha first block of the hashtable to memory
	memcpy((void *) hashTable, block + sizeof(SHT_info), firstBlockIndexes * sizeof(int));
	// Close the block we read/opened
	if (BF_WriteBlock(header_info.fileDesc, header_info.initBlockID) < 0)
		return -1;
	// Calculate some needed values
	int remainingBuckets = header_info.numBuckets - firstBlockIndexes;
	int hashTableCurrIndex = firstBlockIndexes;
	int nextBlock =  header_info.nextHashBlock;
	int nullptr = NULL_PTR;
	int hashTableIndexesFit = (BLOCK_SIZE - sizeof(int)) / sizeof(int);	// Indexes that should fit in every other block
	int prevBlock;
	// Cycle through all hashtable blocks to transfer the ht in memory
	while(nextBlock != NULL_PTR) {
		// Keep last block saved
		prevBlock = nextBlock;
		// Read next block
		if (BF_ReadBlock(header_info.fileDesc, nextBlock, &block) < 0)
			return -1;
		// Modify remainingBuckets value based on remaining buckets
		if (remainingBuckets < hashTableIndexesFit)
			hashTableIndexesFit = remainingBuckets;
		// Copy data from block read to hashtable and also read next block pointer
		memcpy((void *) &hashTable[hashTableCurrIndex], block + sizeof(int), hashTableIndexesFit * sizeof(int));
		memcpy((void *) &nextBlock, block, sizeof(int));
		// Up the index for next copy and also decrement the remaining buckets
		hashTableCurrIndex += hashTableIndexesFit;
		remainingBuckets -= hashTableIndexesFit;
		// Close/Write the block we read
		if (BF_WriteBlock(header_info.fileDesc, prevBlock) < 0)
			return -1;

	}

	int hashIndex = hash(secRecord.record.surname, header_info.numBuckets);
	// Next block to read is the one that the hashtable takes us to based on the hash of the index
	nextBlock = hashTable[hashIndex];
	// Free hash table allcoated memory -- we do not need this anymore
	free(hashTable);
	// Transfer block entries to an array
	int blockFit = (BLOCK_SIZE - sizeof(int)) / sizeof(SecondaryBlockEntry);
	SecondaryBlockEntry *blockArray = (SecondaryBlockEntry *) malloc(blockFit * sizeof(SecondaryBlockEntry));
	// Cycle through the bucket chain
	while(nextBlock != NULL_PTR) {
		// Keep lgo of previous block
		prevBlock = nextBlock;
		// Read the next block
		if (BF_ReadBlock(header_info.fileDesc, nextBlock, &block) < 0)
			return -1;
		// Copy the block information on our blockArray for parsing
		memcpy((void *) blockArray, block + sizeof(int), blockFit * sizeof(SecondaryBlockEntry));
		// Parse the blockArray
		for (int i = 0 ; i < blockFit ; i++) {
			// If we find an entry that counts as a duplicate (same surname, same blockid) that exists, we do not need to input this
			if(blockArray[i].blockPtr == secRecord.recordBlockID && !strcmp(blockArray[i].surname, secRecord.record.surname)) {

				free(blockArray);

				return 0;

			}

		}
		// Read next block pointer
		memcpy((void *) &nextBlock, block, sizeof(int));
		// Close/Write the block read
		if (BF_WriteBlock(header_info.fileDesc, prevBlock) < 0)
			return -1;

	}
	// Here we have reached the last block that has empty spaces (prevBlock), so we are going to insert the new entry
	if (BF_ReadBlock(header_info.fileDesc, prevBlock, &block) < 0)
		return -1;
	// Copy the new block to MM
	memcpy((void *) blockArray, block + sizeof(int), blockFit * sizeof(SecondaryBlockEntry));
	// Parse block until we find an empty space
	for (int i = 0 ; i < blockFit ; i++) {
		// If there is an empty space
		if(blockArray[i].blockPtr == 0) {
			// Put new entry to block and write changes
			SecondaryBlockEntry input;
			strcpy(input.surname, secRecord.record.surname);
			input.blockPtr = secRecord.recordBlockID;
			// Place entry to correct spot
			memcpy(block + i * sizeof(SecondaryBlockEntry) + sizeof(int), (void *) &input, sizeof(SecondaryBlockEntry));

			if (BF_WriteBlock(header_info.fileDesc, prevBlock) < 0)
				return -1;

			free(blockArray);

			return 0;

		}

	}

	free(blockArray);
	// Here, this means we have no empty space, so we extend the chain
	if (BF_AllocateBlock(header_info.fileDesc) < 0)
		return -1;
	// Read the last block to make links
	if (BF_ReadBlock(header_info.fileDesc, prevBlock, &block) < 0)
		return -1;
	// Get the newly created block id
	int nextBlockptr = BF_GetBlockCounter(header_info.fileDesc) - 1;
	// Copy links
	memcpy(block, (void *) &nextBlockptr, sizeof(int));
	// Save link to disk
	if (BF_WriteBlock(header_info.fileDesc, prevBlock) < 0)
		return -1;
	// Read the new block
	if (BF_ReadBlock(header_info.fileDesc, nextBlockptr, &block) < 0)
		return -1;
	// Create entry
	SecondaryBlockEntry input;
	strcpy(input.surname, secRecord.record.surname);
	input.blockPtr = secRecord.recordBlockID;
	// Initialize new block's link to NULL_PTR
	memcpy(block, (void *) &nullptr, sizeof(int));
	memcpy(block + sizeof(int), (void *) &input, sizeof(SecondaryBlockEntry));
	// Save changes
	if (BF_WriteBlock(header_info.fileDesc, nextBlockptr) < 0)
		return -1;
	// Return success
	return 0;

}

int SHT_SecondaryGetAllEntries(SHT_info header_info_sht, HT_info header_info_ht, void *value) {	// Similar to SHT_SecondaryInsertEntry()
	// We first pass the hashtable to main memory in order to parse it
	void *block;
	int* hashTable = malloc(header_info_sht.numBuckets * sizeof(int));
	int hashIndex = hash((char*) value, header_info_sht.numBuckets);
	int blockCounter = 0;	// Counter to return the number of blocks read until search is complete -- increment in every block read

	if (BF_ReadBlock(header_info_sht.fileDesc, header_info_sht.initBlockID, &block) < 0)
		return -1;

	blockCounter++;
	// Calculate first block indexes for passing to MM - ame logic as in SHT_SecondaryInsertEntry()
	int firstBlockIndexes = (BLOCK_SIZE - sizeof(SHT_info)) / sizeof(int);

	if (firstBlockIndexes > header_info_sht.numBuckets)
		firstBlockIndexes = header_info_sht.numBuckets;
	// Here we pass the first block of the hash table from disk to main memory
	memcpy((void *) hashTable, block + sizeof(SHT_info), firstBlockIndexes * sizeof(int));

	if (BF_WriteBlock(header_info_sht.fileDesc, header_info_sht.initBlockID) < 0)
		return -1;
	// Calculate values for passing the rest of the ht
	int remainingBuckets = header_info_sht.numBuckets - firstBlockIndexes;
	int hashTableCurrIndex = firstBlockIndexes;
	int nextBlock =  header_info_sht.nextHashBlock;
	int hashTableIndexesFit = (BLOCK_SIZE - sizeof(int)) / sizeof(int);
	int prevBlock;
	// Here we pass the rest of the hashtable's blocks data to main memory
	while(nextBlock != NULL_PTR) {

		prevBlock = nextBlock;

		if (BF_ReadBlock(header_info_sht.fileDesc, nextBlock, &block) < 0)
			return -1;

		blockCounter++;

		if (remainingBuckets < hashTableIndexesFit)
			hashTableIndexesFit = remainingBuckets;

		memcpy((void *) &hashTable[hashTableCurrIndex], block + sizeof(int), hashTableIndexesFit * sizeof(int));
		memcpy((void *) &nextBlock, block, sizeof(int));

		hashTableCurrIndex += hashTableIndexesFit;

		if (BF_WriteBlock(header_info_sht.fileDesc, prevBlock) < 0)
			return -1;

		remainingBuckets -= hashTableIndexesFit;

	}

	int targetBlock = hashTable[hashIndex];
	// Free allocated space
	free(hashTable);

	int blockFit = (BLOCK_SIZE - sizeof(int)) / sizeof(SecondaryBlockEntry);
	SecondaryBlockEntry *blockArray = (SecondaryBlockEntry *) malloc(blockFit * sizeof(SecondaryBlockEntry));
	nextBlock = targetBlock;
	// Cycle through all blocks of bucket chain
	while(nextBlock != NULL_PTR) {

		if(BF_ReadBlock(header_info_sht.fileDesc, nextBlock, &block) < 0)
			return -1;

		blockCounter++;

		if(BF_WriteBlock(header_info_sht.fileDesc, nextBlock) < 0)
				return -1;
		// Change value of nextBlock --iterate
		memcpy((void *) &nextBlock, block, sizeof(int));
		memcpy((void *) blockArray, block + sizeof(int), blockFit * sizeof(SecondaryBlockEntry));
		// Parsing every block
		for (int i = 0 ; i < blockFit ; i++) {
			// If there is an entry matchign the one we are searching for
			if(!strcmp(blockArray[i].surname, (char *) value)) {
				// Get the block id from the primary hash table and parse it to find the entries needed for printing
				int recordHTBlockID = blockArray[i].blockPtr;

				if (BF_ReadBlock(header_info_ht.fileDesc, recordHTBlockID, &block) < 0)
					return -1;

				blockCounter++;

				int blockInfo[2];

				memcpy((void *) blockInfo, block, sizeof(blockInfo));

				int blockSize = (BLOCK_SIZE - sizeof(blockInfo)) / sizeof(Record);
				// Search the whole ht block
				for(int i = 0 ; i < blockSize ; i++) {

					Record * tempRecord = (Record *) (block + sizeof(blockInfo) + i * sizeof(Record));
					// Print every matchign entry
					if (strcmp(tempRecord->surname, (char *) value) == 0)
		                printf("|ID|:%d |NAME|:%s |SURNAME|:%s |ADDRESS|:%s\n", tempRecord->id, tempRecord->name, tempRecord->surname, tempRecord->address);

		        }

				if (BF_WriteBlock(header_info_ht.fileDesc, recordHTBlockID) < 0)
					return -1;

			}

		}

	}
	// Free alocated space
	free(blockArray);

	return blockCounter;

}

int SHTStatistics(SHT_info* header_info) {

	int totalFileBlocks = 0;
	// Load HashTable
	void *block;
	int *hashTable = malloc(header_info->numBuckets * sizeof(int));
	// Read init block
	if (BF_ReadBlock(header_info->fileDesc, header_info->initBlockID, &block) < 0)
		return -1;
	// Increment totalBlocks in file
	totalFileBlocks++;
	// Find how many HT indexes fit in first block
	int firstBlockIndexes = (BLOCK_SIZE - sizeof(SHT_info)) / sizeof(int);
	// If firstBlock indexes fit are more than number of total Buckets
	if (firstBlockIndexes > header_info->numBuckets)
		firstBlockIndexes = header_info->numBuckets;
	// Load first part of the hashTable
	memcpy((void *) hashTable, block + sizeof(SHT_info), firstBlockIndexes * sizeof(int));
	// Close firstBlock
	if (BF_WriteBlock(header_info->fileDesc, header_info->initBlockID) < 0)
		return -1;
	// Decrement firstBlock indexes fit from remainingBuckets
	int remainingBuckets = header_info->numBuckets - firstBlockIndexes;
	int hashTableCurrIndex = firstBlockIndexes;
	int nextBlock = header_info->nextHashBlock;
	int hashTableIndexesFit = (BLOCK_SIZE - sizeof(int)) / sizeof(int);
	int prevBlock;
	// While nextBlock won't point to NULL_PTR
	while(nextBlock != NULL_PTR) {
		// Shift prevBlock pointer
		prevBlock = nextBlock;
		// Read nextBlock
		if (BF_ReadBlock(header_info->fileDesc, nextBlock, &block) < 0)
			return -1;
		// Increment total file blocks
		totalFileBlocks++;
		// If remainingBuckets are less thatn indexes fit in other blocks
		if (remainingBuckets < hashTableIndexesFit)
			hashTableIndexesFit = remainingBuckets;
		// Copy curPart of hashtable
		memcpy((void *) &hashTable[hashTableCurrIndex], block + sizeof(int), hashTableIndexesFit * sizeof(int));
		// Shift nextBlock to its next
		memcpy((void *) &nextBlock, block, sizeof(int));
		// Shift hashtable index
		hashTableCurrIndex += hashTableIndexesFit;
		// Decrement remainingBuckets by the ones we read
		remainingBuckets -= hashTableIndexesFit;
		// Close prevBlock opened/read
		if (BF_WriteBlock(header_info->fileDesc, prevBlock) < 0)
			return -1;

	}
	// Parse blocks until nextBlock pointer is NULL_PTR -- this means that block has one or more empty spaces
	int bucketBlocks = 0;
	int blocksWithOverflow = 0;
	// Find how many blocks fit in an HashTable index block
	int recordsFit = (BLOCK_SIZE - sizeof(int)) / sizeof(SecondaryBlockEntry);
	int *recordsCount = (int *) malloc(header_info->numBuckets * sizeof(int));
	SecondaryBlockEntry *blockArray = (SecondaryBlockEntry *) malloc(recordsFit * sizeof(SecondaryBlockEntry));
	// Cycle through the entire ht
	for(int i = 0 ; i < header_info->numBuckets ; i++) {

		recordsCount[i] = 0;
		int curBlock = hashTable[i];
		int curOverflowBlocks = -1;
		// Cycle through every block keeping track of statistics, until you reach the end
		while(curBlock != NULL_PTR) {

			bucketBlocks++;
			totalFileBlocks++;
			curOverflowBlocks++;

			if (BF_ReadBlock(header_info->fileDesc, curBlock, &block) < 0)
				return -1;
			// Change value of nextBlock --iterate
			memcpy((void *) &curBlock, block, sizeof(int));
			// Increment only if this is not the last block -- rest will be calculated manually below
			if(curBlock != NULL_PTR)
				recordsCount[i] += recordsFit;

		}
		// Parse all entries of last block
		for(int j = 0 ; j < recordsFit ; j++) {
			// Fetch each SecondaryBlockEntry
			SecondaryBlockEntry *tempSecRecord = (SecondaryBlockEntry *) (block + sizeof(int) + j * sizeof(SecondaryBlockEntry));

			if(tempSecRecord->blockPtr != 0)	// Check if its initialised
				recordsCount[i]++;		// Increment recordsCount of index i
			else	// If not, then we can stop here
				break;	// Do not need to parse any more

		}

		if(recordsCount[i] > recordsFit)
			blocksWithOverflow++;

		printf("Bucket with id %d has %d overflow blocks.\n", i, curOverflowBlocks);

	}
	// Print statistics calculated
	printf("Total file blocks: %d\n", totalFileBlocks); // (alpha)
	// Find min max and average
	int min = recordsCount[0], max = recordsCount[0];
	int totalRecords = recordsCount[0];

	for(int i = 1 ; i < header_info->numBuckets ; i++) {

		if(recordsCount[i] < min)
			min = recordsCount[i];
		else if(recordsCount[i] > max)
			max = recordsCount[i];

		totalRecords += recordsCount[i];

	}
	// Free allocated space
	free(blockArray);
	free(hashTable);
	free(recordsCount);

	double avg = totalRecords / (double) header_info->numBuckets;

	printf("Min is: %d\nMax is: %d\nAvg is: %.2f\n", min, max, avg); // (beta)

	printf("Average number of blocks per bucket is: %.2f\n", bucketBlocks / (double) header_info->numBuckets); // (gamma)

	printf("Number of buckets that have overflow blocks: %d\n", blocksWithOverflow); // (delta)

	// printf("%d~\n", totalRecords);

	return 0;

}
// Wrapper function that prints statitistics based on file type
int HashStatistics(char *fileName) {

	HT_info *htinfo;
	int returnal;
	// Case file is HT_Type
	if((htinfo = HT_OpenIndex(fileName)) != NULL) {

		printf("-- HT_Statistics:\n");
		returnal = HTStatistics(fileName);

		HT_CloseIndex(htinfo);

		return returnal;

	}
	// Case file is SHT_Type
	SHT_info *shtinf;
	if((shtinf = SHT_OpenSecondaryIndex(fileName)) != NULL) {

		printf("-- SHT_Statistics:\n");
		returnal = SHTStatistics(shtinf);

		SHT_CloseSecondaryIndex(shtinf);

		return returnal;

	}

	return -1;

}

void inputReader2(char* filename, HT_info* hashTableInfo, SHT_info* sht_myinfo) {

    FILE *fp = fopen(filename, "r");
    int i;
    char lineRead[200], *token[4];
    Record newRecord;
    // Read each line
    while (fgets(lineRead, 200, fp) != NULL) {

        token[i = 0] = strtok(lineRead, ",{");
        // Seperate words
        while(token != NULL && i < 3)
            token[++i] = strtok(NULL, ",{}\"");
        // Insert data to a record
        newRecord.id = atoi(token[0]);
        strcpy(newRecord.name, token[1]);
        strcpy(newRecord.surname, token[2]);
        strcpy(newRecord.address, token[3]);

        printf("Inserting entry with data: %d, %s %s %s\n", newRecord.id, newRecord.name, newRecord.surname, newRecord.address);

		int inputBlock = HT_InsertEntry(hashTableInfo, newRecord);

		if (inputBlock == -1)
			continue;

		SecondaryRecord sr = {newRecord, inputBlock};
		SHT_SecondaryInsertEntry(*sht_myinfo, sr);

    }

    fclose(fp);

}

int main() {

	BF_Init();

	int buckets = 200;

	HT_CreateIndex("HASHTABLE", 'i', NULL, 1, buckets);
	HT_info *htInformation = HT_OpenIndex("HASHTABLE");

	SHT_CreateSecondaryIndex("SHT", NULL, 1, buckets, "HT_FILE_NAME");
	SHT_info* shtInformation = SHT_OpenSecondaryIndex("SHT");

	inputReader2("records1K.txt", htInformation, shtInformation);

	// Record newRecord = {2, "test", "test1", "test2"};
	// int inputBlock = HT_InsertEntry(htInformation, newRecord);
	// SecondaryRecord sr = {newRecord, inputBlock};
	// SHT_SecondaryInsertEntry(*shtInformation, sr);
	// SHT_SecondaryGetAllEntries(*shtInformation, *htInformation, (void*) "test1");

	for (int i = 1 ; i < 1000 ; i++)
		HT_GetAllEntries(htInformation, (void *) &i);

	for(int i = 1 ; i < 1000 ; i++) {

		char temp[50];
		sprintf(temp, "surname_%d", i);
		printf("Searching for value: %s\n", temp);
    	SHT_SecondaryGetAllEntries(*shtInformation, *htInformation, (void*) temp);

	}

	HashStatistics("SHT");

	HT_CloseIndex(htInformation);
	SHT_CloseSecondaryIndex(shtInformation);


}
