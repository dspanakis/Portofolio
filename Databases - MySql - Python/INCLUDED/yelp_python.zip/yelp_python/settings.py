# MySQL Settings
mysql_host =  '127.0.0.1' 
mysql_port = 3306  # must be integer (this is wrong:'3306')
mysql_user = 'sasa'   #must replace with your own settings
mysql_passwd = 'sasa' #must replace with your own settings 
mysql_schema = 'yelp'

# Webserver Settings
# IMPORTANT: The port must be available.
web_port = 8080  # must be integer (this is wrong:'8080')
