# MySQL Settings
mysql_host =  'linuxvm01.di.uoa.gr'
mysql_host_Update = 'linuxvm02.di.uoa.gr'
mysql_port = 3306  # must be integer (this is wrong:'3306')
mysql_user = 'yelp'   #must replace with your own settings
mysql_passwd = 'yelp' #must replace with your own settings
mysql_schema = ''

# Webserver Settings
# IMPORTANT: The port must be available.
web_port = 8080  # must be integer (this is wrong:'8080')
