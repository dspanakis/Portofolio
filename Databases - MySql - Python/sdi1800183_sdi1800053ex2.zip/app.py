# ----- CONFIGURE YOUR EDITOR TO USE 4 SPACES PER TAB ----- #
import settings
import sys,os
sys.path.append(os.path.join(os.path.split(os.path.abspath(__file__))[0], 'lib'))
import pymysql as db
import array

def connection():
    ''' User this function to create your connections '''
    con = db.connect(
        settings.mysql_host, 
        settings.mysql_user, 
        settings.mysql_passwd, 
        settings.mysql_schema)
    
    return con


def connection2():
    ''' User this function to create your connections '''
    con = db.connect(
        settings.mysql_host_Update,
        settings.mysql_user,
        settings.mysql_passwd,
        settings.mysql_schema)

    return con

# ------------------------------------------------------------------------------
# Classify Review
# ------------------------------------------------------------------------------

def extract_ngrams(text, num):
    if num > 3 and num < 0: return "Invalid ngram num"

    wordArray = text.split()
    if num==1:
        return wordArray
    else:
        ngram = []
        for i in range(len(wordArray)-(num-1)):
            if num == 2:
                ngram.append((wordArray[i] + " " + wordArray[i+1]))
            if num == 3:
                ngram.append((wordArray[i] + " " + wordArray[i + 1] + " " + wordArray[i + 2]))
        return ngram


def reviewScore(reviewid,pos):
    con = connection()
    con.select_db("yelp")
    cur = con.cursor()
    review_query = "SELECT b.name,r.text FROM reviews r INNER JOIN business b ON b.business_id = r.business_id WHERE r.review_id = %s "
    cur.execute(review_query, reviewid)
    score = 0;

    res = cur.fetchone()

    term = "posterms"
    if pos == 0:
        term = "negterms"

    # Extract All n-grams
    n3ar = extract_ngrams(res[1], 3);
    n2ar = extract_ngrams(res[1], 2);
    n1ar = extract_ngrams(res[1], 1);

    # Extract All n-grams present in our database
    n3arFetchQuery = "SELECT * FROM %s WHERE word IN (" % (term)
    for i in range(len(n3ar)):
        n3arFetchQuery += " '" + n3ar[i] + "',";
    n3arFetchQuery = n3arFetchQuery[:-1] + ");";

    cur.execute(n3arFetchQuery)
    n3arF = cur.fetchall()

    n3_2gram = []
    # Remove all duplicates in 2-gram by generating 3->2gram!
    for i in range(len(n3arF)):
        temp = n3arF[i]
        for j in range(len(temp)):
            n3_2gram += extract_ngrams(temp[j], 2);

    n2arFetchQuery = "SELECT * FROM %s WHERE word " % (term)
    if n3_2gram:
        n2arFetchQuery += "NOT IN ("
        for i in range(len(n3_2gram)):
            n2arFetchQuery += " '" + n3_2gram[i] + "', ";
        n2arFetchQuery = n2arFetchQuery[:-2] + ") AND word ";
    n2arFetchQuery += "IN (";
    for i in range(len(n2ar)):
        n2arFetchQuery += "'" + n2ar[i] + "',";
    n2arFetchQuery = n2arFetchQuery[:-1] + ");";

    cur.execute(n2arFetchQuery)
    n2arF = cur.fetchall()

    n3_1gram = []
    # Remove all duplicates in 1-gram by generating 3->1gram and 2->1gram!
    for i in range(len(n3arF)):
        temp = n3arF[i]
        for j in range(len(temp)):
            n3_1gram += extract_ngrams(temp[j], 1);
    for i in range(len(n2arF)):
        temp = n2arF[i]
        for j in range(len(temp)):
            n3_1gram += extract_ngrams(temp[j], 1);

    n1arFetchQuery = "SELECT * FROM %s WHERE word " % (term)
    if n3_1gram:
        n1arFetchQuery += "NOT IN (";
        for i in range(len(n3_1gram)):
            n1arFetchQuery += " '" + n3_1gram[i] + "', ";
        n1arFetchQuery = n1arFetchQuery[:-2] + ") AND word ";
    n1arFetchQuery += "IN (";
    for i in range(len(n1ar)):
        n1arFetchQuery += " '" + n1ar[i] + "',";
    n1arFetchQuery = n1arFetchQuery[:-1] + ");";

    cur.execute(n1arFetchQuery)
    n1arF = cur.fetchall()

    if pos == 1:
        return 3*len(n3arF) + 2*len(n2arF) + len(n1arF)
    else:
        return -1*(3 * len(n3arF) + 2 * len(n2arF) + len(n1arF))

def classify_review(reviewid):
    con=connection()
    con.select_db("yelp")
    cur=con.cursor()

    # mVizSUtJ83AorDoFamS7zA
    review_query = "SELECT b.name,r.text,rpn.positive FROM reviews r INNER JOIN reviews_pos_neg rpn ON rpn.review_id = r.review_id INNER JOIN business b ON b.business_id = r.business_id WHERE r.review_id = %s "

    try:
        cur.execute(review_query, reviewid)

        res = cur.fetchone()

        if res == None:
            raise exc
    except Exception as exc:

        con.rollback()
        return [("Error", "Type"), ("Invalid review id", "Review doesn't exist")]

    PositiveScore = reviewScore(reviewid,1)
    NegativeScore = reviewScore(reviewid,0)

    Score = "%s" % (PositiveScore+NegativeScore)
    if res[2] == '0':
        fetchPositive = "No"
    else:
        fetchPositive = "Yes"

    return [("Business Name","Review Text","Score","Positive Score","Negative Score","DBisPositive"),(res[0],res[1],Score,PositiveScore,NegativeScore,fetchPositive) ]


# ------------------------------------------------------------------------------
# Update zipcode
# ------------------------------------------------------------------------------
def updatezipcode(business_id, zipcode):
    con = connection2()
    con.select_db("yelp")
    cur = con.cursor()

    if int(zipcode) < 0:
        return [("result","Message"),("Error","Negative zipcode")]

    check = "SELECT FOUND_ROWS() FROM business WHERE business_id = '%s'" % (business_id)
    update = "UPDATE business SET zip_code = %s WHERE business_id = '%s'" % (zipcode, business_id)
    get_update = "SELECT zip_code FROM business WHERE business_id = '%s'" % (business_id)

    try:
        cur.execute(check)

        if cur.fetchone() == None:
           raise exc

        cur.execute(update)

        con.commit()

        res = "ok"

        cur.execute(get_update)

        f_result = cur.fetchone()

        mes = "Business with id : '%s' , has its zip code updated to : %s" % (business_id, f_result[0])

    except Exception as exc:

        con.rollback()

        res = "Error"

        mes = "Invalid Business ID"

    return [("result","Message"),(res,mes)]

# ------------------------------------------------------------------------------
# End
# ------------------------------------------------------------------------------


# ------------------------------------------------------------------------------
# Return function to append each result
# ------------------------------------------------------------------------------

def return_function(res1, res2 ,list):
    temp = [(res1, res2),]
    # temp.append("business_id","numberOfreviews")
    for i in range(len(list)):
        temp.append(list[i],)

    return temp

# ------------------------------------------------------------------------------
# FindNBusinesses
# ------------------------------------------------------------------------------

def findNBusinessesQuery(category_id, n):
    return "SELECT r.business_id,COUNT(rpn.positive) AS PosReviews FROM reviews r INNER JOIN reviews_pos_neg rpn ON rpn.review_id = r.review_id WHERE rpn.positive = 1 AND business_id IN ( SELECT b.business_id FROM business b INNER JOIN business_category bc ON bc.business_id = b.business_id WHERE bc.category_id = %s ) GROUP BY r.business_id ORDER BY PosReviews DESC LIMIT %s;" %(category_id,n)


def selectTopNbusinesses(category_id, n):
    con = connection()
    con.select_db("yelp")
    cur = con.cursor()

    categoryidCheckQuery = "SELECT EXISTS(SELECT * FROM business_category bc WHERE bc.category_id = %s)"

    try:
        cur.execute(categoryidCheckQuery, category_id);
        res = cur.fetchone()

        if res[0] == 0:
            raise exc

        cur.execute(findNBusinessesQuery(category_id, n))

        results = cur.fetchall()

    except Exception as exc:

        con.rollback()
        return [("Error", "Type"), ("Invalid Category ID", "OutOfRange")]

    return return_function("business_id", "numberOfreviews", results)

# ------------------------------------------------------------------------------
# End
# ------------------------------------------------------------------------------



# ------------------------------------------------------------------------------
# DATA BASE ACCESS LAYER (DAL)
# ------------------------------------------------------------------------------

# dbGetFirstInfluences
def dbGetFirstInfluences(user_id):
    con = connection()
    con.select_db("yelp")
    cur = con.cursor()
    # initial user reviewd businesses and first review date
    cur.execute("SELECT DISTINCT r.user_id, r.business_id,MIN(r.date) AS min_review_date FROM reviews r WHERE r.user_id = '" + user_id + "' GROUP BY r.business_id;")
    result = cur.fetchall()
    return result

# dbGetNextInfluences
def dbGetNextInfluences(user_id, business_id, min_review_date):
    con = connection()
    con.select_db("yelp")
    cur = con.cursor()
    # next user reviewd businesses and first review date
    cur.execute("SELECT f.friend_id, rf.business_id, MIN(rf.date) AS min_review_date FROM friends f INNER JOIN reviews rf ON f.friend_id = rf.user_id WHERE f.user_id = '" + user_id + "'" +
        " AND rf.business_id = '" + business_id + "'" +
        " AND rf.date > '" + min_review_date + "'" +
        " GROUP BY f.friend_id, rf.business_id;")
    result = cur.fetchall()
    return result

# ------------------------------------------------------------------------------
# Recursive
# ------------------------------------------------------------------------------
def getUserInfuence4(maxDepth, userBusinesses, curDepth):

    # increase curDepth
    curDepth += 1

    totalResults = ()
    for userBusiness in userBusinesses:

        # get user / business / review date influences
        # In: userId, tuple(business_id, min_review_date)
        # Out: tuples(userId, business_id, min_review_date)
        user_id = userBusiness[0]
        business_id = userBusiness[1]
        min_review_date = userBusiness[2]
        result = dbGetNextInfluences(user_id, business_id, min_review_date)

        if result != None and len(result) > 0:
            totalResults += result

            # prevent beyond maxDepth
            if curDepth < maxDepth:
                result = getUserInfuence4(maxDepth, result, curDepth)
                totalResults += result

    return totalResults

def getUserInfuence3(maxDepth, userBusinesses):

    # prepare for recursive call
    curDepth = 0
    userBusinesses = getUserInfuence4(maxDepth, userBusinesses, curDepth)

    # WE NEED TO RETURN ONLY A LIST OF USER_ID
    return userBusinesses

# ------------------------------------------------------------------------------
# Main: traceUserInfuence
# ------------------------------------------------------------------------------
# userId: --65q1FpAL_UQtVZ2PTGew
# --0mI_q_0D1CdU4P_hoImQ
def traceUserInfuence(userId, maxDepth):

    maxDepth = int(maxDepth)
    if maxDepth <= 0:
        # error
        print("ERROR: maxDepth < = 0")
        return "ERROR: maxDepth < = 0"

    userBusinesses = dbGetFirstInfluences(userId)
    influencedUsers = getUserInfuence3(maxDepth, userBusinesses)

    res_list = []
    for row in influencedUsers:
        res_list += [row[0]]

    res_list = list(dict.fromkeys(res_list))

    res = []
    count = 0
    for r in res_list:
        count+=1
        res.append((count, userId, r))

    res.insert(0,("Row Count", "User", "InfluencedUsers"))

    return res
